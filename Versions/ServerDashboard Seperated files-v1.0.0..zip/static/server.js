const IP = location.hostname;
let countdown = 30, DATA = null, currentEditorUnit = null, currentEditorFile = null;
let browserCallback = null;

let SETTINGS = null; // already used by settings tab; keep global

function toggleEditorSvcSettings(){
  const hdr = document.getElementById('es_hdr');
  const body = document.getElementById('es_body');
  if (!hdr || !body) return;
  const open = body.classList.contains('open');
  if (open){
    body.classList.remove('open');
    hdr.classList.remove('open');
  } else {
    body.classList.add('open');
    hdr.classList.add('open');
  }
}

function _populateEditorCategorySelect(){
  const sel = document.getElementById('es_category');
  if (!sel) return;
  sel.innerHTML = '';
  const cats = (SETTINGS && SETTINGS.categories) ? SETTINGS.categories : ((DATA && DATA.categories) ? DATA.categories : {});
  const keys = Object.keys(cats || {}).sort();
  for (const k of keys){
    const meta = cats[k] || {};
    const o = document.createElement('option');
    o.value = k;
    o.textContent = `${(meta.icon||'').trim()} ${(meta.label||k)}`.trim();
    sel.appendChild(o);
  }
}

function editorLoadServiceSettings(unit){
  if (!unit) return;
  const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
  const ov = (DATA && DATA.settings && DATA.settings.services && DATA.settings.services[unit]) ? DATA.settings.services[unit] : null;

  _populateEditorCategorySelect();

  const urlModeEl = document.getElementById('es_url_mode');
  const schemeEl  = document.getElementById('es_scheme');
  const domEl     = document.getElementById('es_domain');
  const ovEl      = document.getElementById('es_override');
  const catEl     = document.getElementById('es_category');

  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const effUrlMode = ((ov && ov.url_mode) || (s && s.url_mode) || dash.default_url_mode || 'local') + '';
  const effScheme  = ((ov && ov.scheme) || (s && s.scheme) || '') + '';
  const effDomain  = ((ov && ov.domain) || (s && s.domain) || '') + '';
  const effOverride= ((ov && ov.url_override) || (s && s.url_override) || '') + '';
  const effCat     = ((ov && ov.category) || (s && s.category) || 'home') + '';

  if (urlModeEl) urlModeEl.value = effUrlMode;
  if (schemeEl) schemeEl.value = effScheme;
  if (domEl) domEl.value = effDomain;
  if (ovEl) ovEl.value = effOverride;
  if (catEl) catEl.value = effCat;

  editorUpdatePreview();
}

function editorCollectServicePatch(){
  const patch = {};
  const urlModeEl = document.getElementById('es_url_mode');
  const schemeEl  = document.getElementById('es_scheme');
  const domEl     = document.getElementById('es_domain');
  const ovEl      = document.getElementById('es_override');
  const catEl     = document.getElementById('es_category');

  if (urlModeEl) patch.url_mode = (urlModeEl.value || '').trim();
  if (schemeEl)  patch.scheme = (schemeEl.value || '').trim();
  if (domEl)     patch.domain = (domEl.value || '').trim();
  if (ovEl)      patch.url_override = (ovEl.value || '').trim();
  if (catEl)     patch.category = (catEl.value || '').trim();

  if (!patch.scheme) delete patch.scheme;
  if (!patch.domain) delete patch.domain;
  if (!patch.url_override) delete patch.url_override;

  return patch;
}

function editorUpdatePreview(){
  const unit = currentEditorUnit || '';
  if (!unit) return;
  const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
  if (!s) return;

  const patch = editorCollectServicePatch();
  const s2 = Object.assign({}, s, patch, {unit: s.unit, name: s.name});

  const url = buildServiceUrl(s2);
  const el = document.getElementById('es_preview');
  if (el) el.textContent = url;
}

async function editorSaveServiceSettings(){
  const unit = currentEditorUnit || '';
  if (!unit) { toast('No service selected', false); return; }

  // Ensure we have latest SETTINGS object (same one used by Settings tab)
  try{
    if (!SETTINGS) {
      await loadSettings();
    } else {
      _ensureSettingsShape();
    }
  }catch(e){}

  // If loadSettings didn't set it, fall back
  if (!SETTINGS) SETTINGS = (DATA && DATA.settings) ? JSON.parse(JSON.stringify(DATA.settings)) : {};
  if (!SETTINGS.services) SETTINGS.services = {};
  if (!SETTINGS.services[unit] || typeof SETTINGS.services[unit] !== 'object') SETTINGS.services[unit] = {};

  const patch = editorCollectServicePatch();
  Object.assign(SETTINGS.services[unit], patch);

  try{
    const r = await fetch('/api/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({settings: SETTINGS}) });
    const d = await r.json();
    if (!d.ok) { toast(d.message || 'Failed to save settings', false); return; }

    SETTINGS = d.settings || SETTINGS;
    DATA.settings = SETTINGS;

    // Merge into DATA.services list entry so future clicks use updated values immediately
    const i = (DATA && DATA.services) ? DATA.services.findIndex(x => x.unit === unit) : -1;
    if (i >= 0){
      const ov = (SETTINGS.services && SETTINGS.services[unit]) ? SETTINGS.services[unit] : {};
      DATA.services[i] = Object.assign({}, DATA.services[i], ov);
    }

    toast('Service settings saved', true);
    editorUpdatePreview();
  }catch(e){
    console.error(e);
    toast('Failed to save service settings', false);
  }
}

function viewerBase(){
  // Viewer base is still useful for some fallbacks
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const scheme = (dash.viewer_scheme || 'http');
  let host = (dash.viewer_host || 'auto');
  if (!host || host === 'auto') host = IP;
  return `${scheme}://${host}`;
}

function normalizePath(p){
  if (!p) return '';
  return p.startsWith('/') ? p : ('/' + p);
}

function getViewerHost(){
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const vh = (dash.viewer_host || 'auto') + '';
  if (!vh || vh === 'auto') return IP;
  return vh;
}

function buildServiceUrl(s){
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};

  // 1) Full override wins
  const override = (s.url_override || '').trim();
  if (override) return override;

  // 2) Scheme per-service, else dashboard default
  const scheme = ((s.scheme || '') + '').trim() || (dash.viewer_scheme || 'http');

  // 3) Host mode
  const urlMode = ((s.url_mode || '') + '').trim() || (dash.default_url_mode || 'local');

  let host = '';
  if (urlMode === 'domain'){
    const suffix = ((s.domain_suffix || '') + '').trim() || (dash.default_domain_suffix || '');
    const pattern = ((dash.default_domain_pattern || '') + '').trim() || '{unit}.{suffix}';
    host = ((s.domain || '') + '').trim();
    if (!host){
      host = pattern.replace('{unit}', s.unit).replace('{suffix}', suffix);
    }
  } else {
    host = ((s.host || '') + '').trim() || getViewerHost();
  }

  // Port handling: in domain mode, omit :port from URL (reverse proxy / DNS handles it)
  const portRaw = (s.port === null || s.port === undefined || s.port === '') ? '' : ('' + s.port).trim();
  const port = (urlMode === 'domain') ? '' : portRaw;
  const wp = (s.web_path === null || s.web_path === undefined) ? '' : normalizePath((s.web_path || '').trim());

  const hostPort = port ? `${host}:${port}` : host;
  return `${scheme}://${hostPort}${wp}`;
}

function openViewerUnit(unit){
  try{
    const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
    if(!s){ toast('Service data not loaded', false); return; }
    // Merge latest saved per-service URL overrides from settings so changes apply immediately
    const ov = (DATA && DATA.settings && DATA.settings.services && DATA.settings.services[unit]) ? DATA.settings.services[unit] : null;
    const s2 = (ov && typeof ov === 'object') ? Object.assign({}, s, ov, {unit: s.unit, name: s.name}) : s;
    openViewer(s.name, buildServiceUrl(s2));
  }catch(e){ console.error(e); toast('Failed to open viewer', false); }
}

// SVG icons
const ICO = {
  play: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="6" y="6" width="12" height="12"/></svg>',
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
  eye: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
  book: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  file: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>',
};

function toast(msg, ok=true) {
  const d = document.getElementById('toast');
  const el = document.createElement('div');
  el.className = 'toast-msg ' + (ok ? 'ok' : 'err');
  el.textContent = msg;
  d.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function fmtB(b) { return b > 1073741824 ? (b/1073741824).toFixed(1)+' GB' : b > 1048576 ? (b/1048576).toFixed(0)+' MB' : (b/1024).toFixed(0)+' KB'; }
function pctCls(p) { return p < 60 ? 'fg' : p < 85 ? 'fa' : 'fr'; }

function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(e => e.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  if (btn) btn.classList.add('active');
  if (tab === 'logs') buildLogList();
  if (tab === 'settings') { loadSettings(); renderSystemFiles(); }
}

function backToDashboard() {
  closeViewer();
  closeEditor();
  closeBrowser();
  // Activate dashboard tab
  document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(e => e.classList.remove('active'));
  document.getElementById('tab-dashboard').classList.add('active');
  document.querySelector('.nav-btn[data-tab="dashboard"]').classList.add('active');
}

function renderSys(s) {
  const el = document.getElementById('sys-bar');
  if (!s || !s.mem_total) {
    el.innerHTML = '<div class="sys-card"><div class="sys-val">Loading system info...</div></div>';
    return;
  }
  const mp = ((s.mem_used/s.mem_total)*100).toFixed(1);
  const dp = ((s.disk_used/(s.disk_used+s.disk_avail))*100).toFixed(1);
  const sp = s.swap_total > 0 ? ((s.swap_used/s.swap_total)*100).toFixed(1) : 0;
  el.innerHTML = `
    <div class="sys-card"><div class="sys-lbl">Host / IP</div><div class="sys-val">${s.hostname}</div><div class="sys-sub">${s.ip}</div></div>
    <div class="sys-card"><div class="sys-lbl">Uptime</div><div class="sys-val">${s.uptime||'—'}</div><div class="sys-sub">${s.os||''}</div></div>
    <div class="sys-card"><div class="sys-lbl">Load</div><div class="sys-val">${s.load||'—'}</div><div class="sys-sub">${s.cpu_temp?s.cpu_temp+'°C':''} ${s.kernel||''}</div></div>
    <div class="sys-card"><div class="sys-lbl">Memory</div><div class="sys-val">${mp}%</div><div class="sys-sub">${fmtB(s.mem_used)} / ${fmtB(s.mem_total)}</div><div class="pbar"><div class="pfill ${pctCls(mp)}" style="width:${mp}%"></div></div></div>
    <div class="sys-card"><div class="sys-lbl">Swap</div><div class="sys-val">${sp}%</div><div class="sys-sub">${fmtB(s.swap_used)} / ${fmtB(s.swap_total)}</div><div class="pbar"><div class="pfill ${pctCls(sp)}" style="width:${sp}%"></div></div></div>
    <div class="sys-card"><div class="sys-lbl">Disk</div><div class="sys-val">${dp}%</div><div class="sys-sub">${fmtB(s.disk_used)} / ${fmtB(s.disk_used+s.disk_avail)}</div><div class="pbar"><div class="pfill ${pctCls(dp)}" style="width:${dp}%"></div></div></div>`;
}

function renderSvc(services, cats) {
  const c = document.getElementById('svc-container');
  if (!services || !services.length) {
    c.innerHTML = '<div class="sys-card"><div class="sys-val">Loading services...</div></div>';
    return;
  }
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const hideStopped = !!dash.hide_stopped_services;
  const protectDash = (dash.protect_dashboard_service !== false);
  const hiddenUnits = Array.isArray(dash.hidden_units) ? dash.hidden_units : [];
  let list = services.filter(s => !hiddenUnits.includes(s.unit));
  if (hideStopped) list = list.filter(s => s.status === 'active');

  const g = {};
  list.forEach(s => { if(!g[s.category]) g[s.category]=[]; g[s.category].push(s); });
  const order = ['media','arr','downloads','tv','home','system'];
  let h = '';
  order.forEach(cat => {
    const items = g[cat]; if(!items) return;
    const m = cats[cat]||{label:cat,icon:'📦'};
    const ac = items.filter(s=>s.status==='active').length;
    h += `<div class="category"><div class="cat-hdr"><span class="cat-icon">${m.icon}</span><span class="cat-title">${m.label}</span><span class="cat-count">${ac}/${items.length}</span></div><div class="sgrid">`;
    items.forEach(s => {
      const cls = s.status==='active'?'on':s.status==='inactive'?'off':'unk';
      const rtBadge = s.runtime === 'docker'   ? '<span class="rt-badge rt-docker">docker</span>'
                    : s.runtime === 'systemd'  ? '<span class="rt-badge rt-systemd">svc</span>'
                    : s.runtime === 'external' ? '<span class="rt-badge rt-external">ext</span>'
                    : '';
      let port = '';
      if (s.port) {
        if (s.web_path !== null && s.web_path !== undefined)
          port = `<span class="sport"><a href="#" onclick="openViewerUnit('${s.unit}');return false">:${s.port}</a></span>`;
        else port = `<span class="sport">:${s.port}</span>`;
      }
      const mem = s.memory_mb ? `<span class="smem">${s.memory_mb}M</span>` : '';
      const cpu = s.cpu_pct != null ? `<span class="scpu">${s.cpu_pct}%</span>` : '';
      const isDash = (s.unit === 'server-dashboard');
      const hasView = (!isDash) && s.port && s.web_path !== null && s.web_path !== undefined;
      const hasEdit = true;
      const showStop = (!isDash);

      h += `<div class="svc ${cls}">
        <div class="sdot"></div>
        <div class="sinfo"><div class="sname">${s.name} ${rtBadge}</div><div class="sdesc">${s.description} · <code>${s.unit}</code></div></div>
        <div class="smeta">${cpu}${mem}${port}</div>
        <div class="sctrl">
          <button class="cbtn start" title="Start" onclick="svcCtrl('${s.unit}','start',this)">${ICO.play}</button>
          ${showStop?`<button class="cbtn stop" title="Stop" onclick="svcCtrl('${s.unit}','stop',this)">${ICO.stop}</button>`:''}
          <button class="cbtn restart" title="Restart" onclick="svcCtrl('${s.unit}','restart',this)">${ICO.refresh}</button>
          ${s.unit==='kiwix'?`<button class="cbtn kiwix" title="Refresh Kiwix Library" onclick="kiwixRefresh(this)">${ICO.book}</button>`:''}
          ${hasView?`<button class="cbtn view" title="Open UI" onclick="openViewerUnit('${s.unit}')">${ICO.eye}</button>`:''}
          ${hasEdit?`<button class="cbtn edit" title="Edit Config" onclick="openEditor('${s.unit}')">${ICO.edit}</button>`:''}
        </div>
      </div>`;
    });
    h += '</div></div>';
  });
  c.innerHTML = h;
}

async function svcCtrl(unit, action, btn) {
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  if (action === 'stop') {
    const protectDash = (dash.protect_dashboard_service !== false);
    if (protectDash && unit === 'server-dashboard') {
      toast('Stop is disabled for Server Dashboard', false);
      return;
    }
  }
  btn.classList.add('spinning');
  try {
    const r = await fetch('/api/control', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({unit,action}) });
    const d = await r.json();
    toast(d.message, d.ok);
    setTimeout(fetchData, 1500);
  } catch(e) { toast('Request failed', false); }
  btn.classList.remove('spinning');
}

async function kiwixRefresh(btn) {
  btn.classList.add('spinning');
  try {
    const r = await fetch('/api/kiwix/refresh', { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' });
    const d = await r.json();
    toast(d.message || 'Kiwix refresh complete', d.ok);
    if (d.details) console.log('[Kiwix refresh]\n' + d.details);
    setTimeout(fetchData, 2500);
  } catch(e) {
    toast('Kiwix refresh request failed', false);
  }
  btn.classList.remove('spinning');
}

// Settings (dashboard-only mappings)
// (SETTINGS is declared near the top of the script)

function _linesToList(v){
  return (v || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(s => !!s);
}

function _listToLines(arr){
  return Array.isArray(arr) ? arr.join('\n') : '';
}

function _svcKey(){
  const el = document.getElementById('svc_pick');
  return el ? (el.value || '') : '';
}

function _ensureSettingsShape(){
  if (!SETTINGS || typeof SETTINGS !== 'object') SETTINGS = {};
  if (!SETTINGS.dashboard || typeof SETTINGS.dashboard !== 'object') SETTINGS.dashboard = {};
  if (!SETTINGS.services || typeof SETTINGS.services !== 'object') SETTINGS.services = {};

  // New: categories + domain defaults
  if (!SETTINGS.categories || typeof SETTINGS.categories !== 'object') SETTINGS.categories = (DATA && DATA.categories) ? JSON.parse(JSON.stringify(DATA.categories)) : {};
  if (SETTINGS.dashboard.default_url_mode === undefined) SETTINGS.dashboard.default_url_mode = 'local';
  if (SETTINGS.dashboard.default_domain_suffix === undefined) SETTINGS.dashboard.default_domain_suffix = 'sidneyshelton.com';
  if (SETTINGS.dashboard.default_domain_pattern === undefined) SETTINGS.dashboard.default_domain_pattern = '{unit}.{suffix}';

  if (SETTINGS.dashboard.hide_stopped_services === undefined) SETTINGS.dashboard.hide_stopped_services = false;
  if (SETTINGS.dashboard.protect_dashboard_service === undefined) SETTINGS.dashboard.protect_dashboard_service = true;
  if (!Array.isArray(SETTINGS.dashboard.hidden_units)) SETTINGS.dashboard.hidden_units = [];
}

function _catKeys(){
  _ensureSettingsShape();
  return Object.keys(SETTINGS.categories || {}).sort();
}

function populateCategorySelect(selectEl, includeBlank){
  if (!selectEl) return;
  const prev = selectEl.value;
  selectEl.innerHTML = '';
  if (includeBlank){
    const o = document.createElement('option');
    o.value = '';
    o.textContent = '(No change / Default)';
    selectEl.appendChild(o);
  }
  for (const k of _catKeys()){
    const meta = SETTINGS.categories[k] || {};
    const o = document.createElement('option');
    o.value = k;
    o.textContent = `${meta.icon || ''} ${meta.label || k}`.trim();
    selectEl.appendChild(o);
  }
  if (prev) selectEl.value = prev;
}

function refreshCategoryPickers(){
  populateCategorySelect(document.getElementById('svc_category'), false);
  populateCategorySelect(document.getElementById('bulk_scope_category'), false);
  populateCategorySelect(document.getElementById('bulk_category'), true);
}
function populateServicePicker(){
  const pick = document.getElementById('svc_pick');
  if (!pick) return;
  const prev = pick.value;
  pick.innerHTML = '';
  const filterEl = document.getElementById('svc_rt_filter');
  const filterVal = filterEl ? filterEl.value : '';
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  let count = 0;
  for (const s of svcs){
    if (filterVal && s.runtime !== filterVal) continue;
    const opt = document.createElement('option');
    opt.value = s.unit;
    const badge = s.runtime === 'docker' ? '🐳' : s.runtime === 'systemd' ? '🐧' : '🌐';
    opt.textContent = `${badge} ${s.name}  (${s.unit})`;
    pick.appendChild(opt);
    count++;
  }
  const countEl = document.getElementById('svc_pick_count');
  if (countEl) countEl.textContent = count;
  if (prev) pick.value = prev;
  onPickService();
}

function onRuntimeChange(){
  const rt = document.getElementById('svc_runtime')?.value || 'docker';
  const dockerRow = document.getElementById('svc_docker_row');
  const hostRow   = document.getElementById('svc_host_row');
  const volRow    = document.getElementById('svc_volmap_row');
  if (dockerRow) dockerRow.style.display = rt === 'docker'   ? 'block' : 'none';
  if (volRow)    volRow.style.display    = rt === 'docker'   ? 'block' : 'none';
  if (hostRow)   hostRow.style.display   = rt === 'external' ? 'block' : 'none';
}

function onPickService(){
  _ensureSettingsShape();
  const unit = _svcKey();
  if (!unit) return;
  // Prefer live DATA for runtime so new dynamically-added services show up correctly
  const liveSvc = (DATA && DATA.services) ? DATA.services.find(s => s.unit === unit) : null;
  const entry = (SETTINGS.services && SETTINGS.services[unit]) ? SETTINGS.services[unit] : (liveSvc || {});

  const rt = entry.runtime || (liveSvc && liveSvc.runtime) || 'docker';
  const rtEl = document.getElementById('svc_runtime');
  if (rtEl) rtEl.value = rt;
  onRuntimeChange();

  const dcEl = document.getElementById('svc_docker_container');
  if (dcEl) dcEl.value = (entry.docker_container || liveSvc?.docker_container || '') + '';

  const hostEl = document.getElementById('svc_host');
  if (hostEl) hostEl.value = (entry.host || liveSvc?.host || 'localhost') + '';

  document.getElementById('svc_port').value = ((entry.port ?? liveSvc?.port) ?? '') + '';
  document.getElementById('svc_web_path').value = (entry.web_path ?? liveSvc?.web_path ?? '') + '';
  // URL + category fields
  const scEl = document.getElementById('svc_scheme');
  if (scEl) scEl.value = (entry.scheme ?? liveSvc?.scheme ?? '') + '';
  const umEl = document.getElementById('svc_url_mode');
  if (umEl) umEl.value = (entry.url_mode ?? liveSvc?.url_mode ?? '') + '';
  const domEl = document.getElementById('svc_domain');
  if (domEl) domEl.value = (entry.domain ?? liveSvc?.domain ?? '') + '';
  const ovEl = document.getElementById('svc_url_override');
  if (ovEl) ovEl.value = (entry.url_override ?? liveSvc?.url_override ?? '') + '';

  refreshCategoryPickers();
  const catEl = document.getElementById('svc_category');
  if (catEl) catEl.value = (entry.category ?? liveSvc?.category ?? 'home') + '';
  document.getElementById('svc_config_files').value = _listToLines(entry.config_files || liveSvc?.config_files || []);
  document.getElementById('svc_data_paths').value   = _listToLines(entry.data_paths   || liveSvc?.data_paths   || []);

  const vmEl = document.getElementById('svc_volume_maps');
  if (vmEl) vmEl.value = _listToLines(entry.volume_maps || liveSvc?.volume_maps || []);

  const isKiwix = unit === 'kiwix';
  document.getElementById('kiwix_extra').style.display = isKiwix ? 'block' : 'none';
  if (isKiwix){
    document.getElementById('svc_kiwix_zim_dir').value    = (entry.kiwix_zim_dir    ?? '') + '';
    document.getElementById('svc_kiwix_library_xml').value = (entry.kiwix_library_xml ?? '') + '';
  }
}

// ── Accordion ───────────────────────────────────────────────────────────
function toggleAccordion(hdr){
  hdr.classList.toggle('open');
  const body = hdr.nextElementSibling;
  if (body) body.classList.toggle('open');
}

// ── Bootstrap / Reset ───────────────────────────────────────────────────
async function doBootstrap(mode){
  const msg = mode === 'blank'
    ? 'This will WIPE all service settings and start fresh. Are you sure?'
    : 'This will rebuild settings from the embedded SERVICES list, discarding manual changes. Continue?';
  if (!confirm(msg)) return;
  try {
    const r = await fetch('/api/bootstrap', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({mode})});
    const d = await r.json();
    toast(d.message || (d.ok ? 'Done' : 'Failed'), !!d.ok);
    if (d.ok){ await fetchData(); await loadSettings(); }
  } catch(e){ toast('Request failed', false); }
}

async function saveScanPaths(){
  _ensureSettingsShape();
  const ta = document.getElementById('set_scan_paths');
  if (!ta) return;
  if (!SETTINGS.bootstrap) SETTINGS.bootstrap = {};
  SETTINGS.bootstrap.scan_paths = _linesToList(ta.value);
  await saveAllSettings();
}

// ── Add Service Wizard ──────────────────────────────────────────────────
let _SCAN_RESULTS = null;
let _SCAN_SEL     = new Map();  // rowId -> {type, data}
let _SCAN_PAYLOAD = new Map(); // rowId -> raw scanned item payload
let _wizMode      = 'scan';     // 'scan' | 'manual'
let _wizRT        = 'systemd';  // runtime tab for manual form

async function openWizard(mode){
  _wizMode = mode || 'scan';
  _SCAN_SEL.clear();
  const overlay = document.getElementById('wizard');
  const body    = document.getElementById('wiz-body');
  const footer  = document.getElementById('wiz-footer');
  const title   = document.getElementById('wiz-title');

  if (_wizMode === 'manual'){
    title.textContent = 'Add Service Manually';
    body.innerHTML    = _buildManualForm('systemd');
    footer.innerHTML  = `<button class="ebtn close" onclick="closeWizard()">Cancel</button>
                         <button class="ebtn primary" onclick="_submitManual()">Add Service</button>`;
    overlay.classList.add('open');
    document.body.classList.add('modal-open');
  } else {
    title.textContent = 'Add Service — Auto Scan';
    body.innerHTML    = `<div style="color:var(--text2);padding:20px;text-align:center;">🔍 Scanning for services…</div>`;
    footer.innerHTML  = `<button class="ebtn close" onclick="closeWizard()">Cancel</button>
                         <button class="ebtn" onclick="openWizard('manual')">Manual entry instead</button>`;
    overlay.classList.add('open');
    document.body.classList.add('modal-open');
    try {
      const r = await fetch('/api/scan');
      const d = await r.json();
      _SCAN_RESULTS = d.results || {};
      _renderScanResults(body, footer);
    } catch(e){
      body.innerHTML = `<div style="padding:20px;color:var(--red);">Scan failed: ${e.message}</div>`;
    }
  }
}

function _catOpts(selectedVal) {
  const CATS = [
    {val:'media',     label:'🎬 Media'},
    {val:'arr',       label:'📡 Arr Stack'},
    {val:'downloads', label:'⬇️ Downloads'},
    {val:'tv',        label:'📺 TV / DVR'},
    {val:'home',      label:'🏠 Home & Apps'},
    {val:'system',    label:'⚙️ System'},
  ];
  return CATS.map(c => `<option value="${c.val}" ${c.val===selectedVal?'selected':''}>${c.label}</option>`).join('');
}

function _buildManualForm(rt){
  return `
  <div class="wiz-tabs">
    <button class="wiz-tab svc ${rt==='systemd'?'active':''}" onclick="_switchWizTab('systemd',this)">🐧 systemd</button>
    <button class="wiz-tab dkr ${rt==='docker'?'active':''}"  onclick="_switchWizTab('docker',this)">🐳 docker</button>
    <button class="wiz-tab ext ${rt==='external'?'active':''}" onclick="_switchWizTab('external',this)">🌐 external</button>
  </div>

  <!-- systemd panel -->
  <div class="wiz-panel ${rt==='systemd'?'active':''}" id="wt-systemd">
    <div class="wiz-row">
      <div class="wiz-field"><label>Display name</label><input id="wm_name" class="wiz-input" placeholder="e.g. My App"/></div>
      <div class="wiz-field"><label>Unit name</label><input id="wm_unit" class="wiz-input" placeholder="e.g. myapp (no .service)"/></div>
    </div>
    <div class="wiz-row">
      <div class="wiz-field"><label>Port</label><input id="wm_port" class="wiz-input" type="number" placeholder="8080"/></div>
      <div class="wiz-field"><label>Web path</label><input id="wm_webpath" class="wiz-input" placeholder="/ or /web"/></div>
    </div>
    <div class="wiz-field">
      <label>Section / Category</label>
      <select id="wm_cat" class="wiz-input">${_catOpts('home')}</select>
    </div>
    <div class="wiz-field"><label>Description</label><input id="wm_desc" class="wiz-input" placeholder="Brief description"/></div>
    <div class="wiz-hint">Controlled via <code>sudo systemctl start/stop/restart &lt;unit&gt;</code>.</div>
  </div>

  <!-- docker panel -->
  <div class="wiz-panel ${rt==='docker'?'active':''}" id="wt-docker">
    <div class="wiz-row">
      <div class="wiz-field"><label>Display name</label><input id="wm_dname" class="wiz-input" placeholder="e.g. Radarr B"/></div>
      <div class="wiz-field"><label>Container name</label><input id="wm_dcontainer" class="wiz-input" placeholder="e.g. radarr-b"/></div>
    </div>
    <div class="wiz-row">
      <div class="wiz-field"><label>Port</label><input id="wm_dport" class="wiz-input" type="number" placeholder="7878"/></div>
      <div class="wiz-field"><label>Web path</label><input id="wm_dwebpath" class="wiz-input" placeholder="/ or /web"/></div>
    </div>
    <div class="wiz-field">
      <label>Section / Category</label>
      <select id="wm_dcat" class="wiz-input">${_catOpts('home')}</select>
    </div>
    <div class="wiz-field"><label>Description</label><input id="wm_ddesc" class="wiz-input" placeholder="Brief description"/></div>
    <div class="wiz-hint">Controlled via <code>docker start/stop/restart &lt;container&gt;</code>.</div>
  </div>

  <!-- external panel -->
  <div class="wiz-panel ${rt==='external'?'active':''}" id="wt-external">
    <div class="wiz-row">
      <div class="wiz-field"><label>Display name</label><input id="wm_ename" class="wiz-input" placeholder="e.g. Windows Plex"/></div>
      <div class="wiz-field"><label>Host / IP</label><input id="wm_ehost" class="wiz-input" placeholder="192.168.0.50"/></div>
    </div>
    <div class="wiz-row">
      <div class="wiz-field"><label>Port</label><input id="wm_eport" class="wiz-input" type="number" placeholder="32400"/></div>
      <div class="wiz-field"><label>Web path</label><input id="wm_ewebpath" class="wiz-input" placeholder="/"/></div>
    </div>
    <div class="wiz-field">
      <label>Section / Category</label>
      <select id="wm_ecat" class="wiz-input">${_catOpts('home')}</select>
    </div>
    <div class="wiz-field"><label>Description</label><input id="wm_edesc" class="wiz-input" placeholder="e.g. Windows VM Plex"/></div>
    <div class="wiz-hint">No start/stop control — View link only. Great for Plex on another VM, NAS, Windows services, etc.</div>
  </div>`;
}

function _switchWizTab(rt, btn){
  document.querySelectorAll('.wiz-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.wiz-panel').forEach(p => p.classList.remove('active'));
  const panel = document.getElementById('wt-' + rt);
  if (panel) panel.classList.add('active');
  _wizRT = rt;
}

async function _submitManual(){
  let srv = {};
  if (_wizRT === 'systemd'){
    const name = (document.getElementById('wm_name')?.value||'').trim();
    const unit = (document.getElementById('wm_unit')?.value||'').trim().replace(/\.service$/,'');
    if (!name||!unit){ toast('Name and unit are required', false); return; }
    srv = {name, unit, runtime:'systemd', host:'localhost',
      port:        parseInt(document.getElementById('wm_port')?.value)||null,
      web_path:    (document.getElementById('wm_webpath')?.value||'').trim(),
      category:    document.getElementById('wm_cat')?.value||'home',
      description: (document.getElementById('wm_desc')?.value||'').trim()};
  } else if (_wizRT === 'docker'){
    const name      = (document.getElementById('wm_dname')?.value||'').trim();
    const container = (document.getElementById('wm_dcontainer')?.value||'').trim();
    if (!name||!container){ toast('Name and container name required', false); return; }
    srv = {name, unit:container, runtime:'docker', docker_container:container, host:'localhost',
      port:        parseInt(document.getElementById('wm_dport')?.value)||null,
      web_path:    (document.getElementById('wm_dwebpath')?.value||'').trim(),
      category:    document.getElementById('wm_dcat')?.value||'home',
      description: (document.getElementById('wm_ddesc')?.value||'').trim()};
  } else {
    const name = (document.getElementById('wm_ename')?.value||'').trim();
    const host = (document.getElementById('wm_ehost')?.value||'').trim();
    if (!name||!host){ toast('Name and host are required', false); return; }
    srv = {name, unit:name.toLowerCase().replace(/\s+/g,'-'), runtime:'external',
      host, port: parseInt(document.getElementById('wm_eport')?.value)||null,
      web_path:    (document.getElementById('wm_ewebpath')?.value||'').trim(),
      category:    document.getElementById('wm_ecat')?.value||'home',
      description: (document.getElementById('wm_edesc')?.value||'').trim()};
  }
  try {
    const r = await fetch('/api/servers/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({servers:[srv]})});
    const d = await r.json();
    toast(d.message||(d.ok?'Added':'Failed'), !!d.ok);
    if (d.ok){ closeWizard(); await fetchData(); await loadSettings(); }
  } catch(e){ toast('Request failed', false); }
}

function _renderScanResults(body, footer){
  _SCAN_PAYLOAD.clear();
  _SCAN_SEL.clear();
  const r   = _SCAN_RESULTS || {};
  const sys = (r.systemd || []).slice().sort((a,b) => a.unit.localeCompare(b.unit));
  const doc = (r.docker  || []).slice().sort((a,b) => a.container.localeCompare(b.container));
  const pts = (r.ports   || []).slice().sort((a,b) => a.port - b.port);

  const total = sys.length + doc.length + pts.length;
  const esc = s => String(s||'').replace(/[<>&"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));

  function catSel(idSuffix, defaultVal){
    return `<select class="wiz-input scan-cat-sel" id="scat_${idSuffix}" style="font-size:10px;padding:3px 6px;min-width:130px;" onclick="event.stopPropagation()">
      <option value="media"     ${defaultVal==='media'    ?'selected':''}>🎬 Media</option>
      <option value="arr"       ${defaultVal==='arr'      ?'selected':''}>📡 Arr Stack</option>
      <option value="downloads" ${defaultVal==='downloads'?'selected':''}>⬇️ Downloads</option>
      <option value="tv"        ${defaultVal==='tv'       ?'selected':''}>📺 TV / DVR</option>
      <option value="home"      ${defaultVal==='home'     ?'selected':''}>🏠 Home & Apps</option>
      <option value="system"    ${defaultVal==='system'   ?'selected':''}>⚙️ System</option>
    </select>`;
  }

  // Guess category from known service names / image names
  function guessCategory(name, image){
    const n = (name + ' ' + (image||'')).toLowerCase();
    if (/plex|jellyfin|emby|kodi|navidrome|airsonic|kiwix/.test(n))    return 'media';
    if (/sonarr|radarr|lidarr|readarr|prowlarr|bazarr|whisparr|arr/.test(n)) return 'arr';
    if (/qbittorrent|deluge|transmission|sabnzbd|nzbget|jdownloader/.test(n)) return 'downloads';
    if (/tvheadend|channels|hdhomerun|dizquetv|xteve/.test(n))          return 'tv';
    if (/homeassistant|home.assistant|ha |node.red|nodered|vaultwarden|bitwarden|uptime|dasherr|homer|flame|organizr/.test(n)) return 'home';
    if (/portainer|grafana|prometheus|netdata|dozzle|watchtower|nginx|traefik|caddy|docker|pihole|unbound/.test(n)) return 'system';
    return 'home';
  }

  let h = '';

  if (sys.length){
    h += `<div class="scan-section"><div class="scan-section-title">🐧 systemd services <span style="color:var(--text3);font-weight:400;">${sys.length} found</span></div>`;
    sys.forEach((item, i) => {
      const id  = `scan_sys_${i}`;
      const cat = guessCategory(item.unit, '');
      _SCAN_PAYLOAD.set(id, { type:'systemd', data:item });
      h += `<div class="scan-item" id="${id}" onclick="_toggleScanItemById('${id}')">
        <div class="scan-check">✓</div>
        <div class="scan-item-info">
          <div class="scan-item-name">${esc(item.unit)}</div>
          <div class="scan-item-sub">${esc(item.description||'')} · ${esc(item.active||'active')}</div>
        </div>
        ${catSel(id, cat)}
        <span class="scan-badge systemd">systemd</span>
      </div>`;
    });
    h += '</div>';
  }

  if (doc.length){
    h += `<div class="scan-section"><div class="scan-section-title">🐳 docker containers <span style="color:var(--text3);font-weight:400;">${doc.length} found</span></div>`;
    doc.forEach((item, i) => {
      const id  = `scan_dkr_${i}`;
      const cat = guessCategory(item.container, item.image);
      _SCAN_PAYLOAD.set(id, { type:'docker', data:item });
      h += `<div class="scan-item" id="${id}" onclick="_toggleScanItemById('${id}')">
        <div class="scan-check">✓</div>
        <div class="scan-item-info">
          <div class="scan-item-name">${esc(item.container)}</div>
          <div class="scan-item-sub">${esc(item.image||'')}${item.suggested_port ? ' · :'+item.suggested_port : ''} · ${esc(item.status||'')}</div>
        </div>
        ${catSel(id, cat)}
        <span class="scan-badge docker">docker</span>
      </div>`;
    });
    h += '</div>';
  }

  if (pts.length){
    h += `<div class="scan-section"><div class="scan-section-title">🔌 open ports <span style="color:var(--text3);font-weight:400;">${pts.length} found</span></div>`;
    pts.forEach((item, i) => {
      const id  = `scan_prt_${i}`;
      const cat = item.category || guessCategory(item.name, '');
      _SCAN_PAYLOAD.set(id, { type:'port', data:item });
      h += `<div class="scan-item" id="${id}" onclick="_toggleScanItemById('${id}')">
        <div class="scan-check">✓</div>
        <div class="scan-item-info">
          <div class="scan-item-name">${esc(item.name)} <span style="color:var(--cyan);font-family:var(--mono);">:${item.port}</span></div>
          <div class="scan-item-sub">${esc(item.description||'')}</div>
        </div>
        ${catSel(id, cat)}
        <span class="scan-badge port">port</span>
      </div>`;
    });
    h += '</div>';
  }

  if (!h) h = `<div class="scan-empty">No new services found. Everything may already be in the dashboard, or docker/systemd returned nothing.<br><br><b>Try Manual entry</b> to add a service by hand.</div>`;

  const selCount = () => _SCAN_SEL.size;
  body.innerHTML = h;
  footer.innerHTML = `<button class="ebtn close" onclick="closeWizard()">Cancel</button>
    <button class="ebtn" onclick="openWizard('manual')">✏️ Manual entry</button>
    <button class="ebtn primary" onclick="_addScanSelected()">Add Selected (<span id="wiz-sel-count">0</span>)</button>`;
}
function _toggleScanItemById(id){
  const payload = _SCAN_PAYLOAD.get(id);
  if (!payload) return;
  _toggleScanItem(id, payload.type, payload.data);
}

function _toggleScanItem(id, type, data){
  const el = document.getElementById(id);
  if (!el) return;
  if (_SCAN_SEL.has(id)){
    _SCAN_SEL.delete(id);
    el.classList.remove('sel');
  } else {
    _SCAN_SEL.set(id, {type, data});
    el.classList.add('sel');
  }
  const cnt = document.getElementById('wiz-sel-count');
  if (cnt) cnt.textContent = _SCAN_SEL.size;
}

async function _addScanSelected(){
  if (!_SCAN_SEL.size){ toast('Select at least one service', false); return; }
  const servers = [];
  _SCAN_SEL.forEach(({type, data}, id) => {
    // Read the per-item category dropdown if present
    const catEl = document.getElementById('scat_' + id);
    const cat   = catEl ? catEl.value : (data.category || 'home');
    if (type === 'systemd')
      servers.push({name:data.unit, unit:data.unit, runtime:'systemd', host:'localhost',
        port:data.suggested_port||null, category:cat, description:data.description||'', web_path:''});
    else if (type === 'docker')
      servers.push({name:data.container, unit:data.container, runtime:'docker',
        docker_container:data.container, host:'localhost',
        port:data.suggested_port||null, web_path:'', category:cat, description:''});
    else if (type === 'port')
      servers.push({name:data.name, unit:data.name.toLowerCase().replace(/\s+/g,'-'),
        runtime:'external', host:'localhost',
        port:data.port, category:cat, description:data.description||'', web_path:data.web_path||''});
  });
  try {
    const r = await fetch('/api/servers/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({servers})});
    const d = await r.json();
    toast(d.message||(d.ok?'Added':'Failed'), !!d.ok);
    if (d.ok){ closeWizard(); await fetchData(); await loadSettings(); }
  } catch(e){ toast('Request failed', false); }
}

function closeWizard(){
  document.getElementById('wizard').classList.remove('open');
  document.body.classList.remove('modal-open');
}

// Browse helper: add a file path to the config_files textarea
function openBrowserForConfigFiles(){
  const unit = _svcKey();
  const svc = DATA ? DATA.services.find(s => s.unit === unit) : null;
  let startPath = svc && svc.data_paths && svc.data_paths.length ? svc.data_paths[0] : '/opt/appdata';
  browserCallback = function(filepath){
    const ta = document.getElementById('svc_config_files');
    if (!ta) return;
    const lines = _linesToList(ta.value);
    if (!lines.includes(filepath)){ lines.push(filepath); }
    ta.value = lines.join('\n');
  };
  openBrowser(startPath);
}

function populateHiddenPicker(){
  const pick = document.getElementById('set_hidden_pick');
  if (!pick) return;
  pick.innerHTML = '';
  const hidden = new Set((SETTINGS && SETTINGS.dashboard && Array.isArray(SETTINGS.dashboard.hidden_units)) ? SETTINGS.dashboard.hidden_units : []);
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  for (const s of svcs){
    const opt = document.createElement('option');
    opt.value = s.unit;
    opt.textContent = `${s.name}  (${s.unit})`;
    if (hidden.has(s.unit)) opt.selected = true;
    pick.appendChild(opt);
  }
}

function _getHiddenSet(){
  const t = document.getElementById('set_hidden_units');
  const lines = (t && t.value != null) ? t.value.split(/\r?\n/) : [];
  const set = new Set();
  for (const raw of lines){
    const u = (raw || '').trim();
    if (u) set.add(u);
  }
  return set;
}

function _writeHiddenSetToUI(hidden){
  const t = document.getElementById('set_hidden_units');
  if (t) t.value = Array.from(hidden).sort().join('\n');
}

function populateHiddenPicker(){
  const visPick = document.getElementById('set_unhidden_pick');
  const hidPick = document.getElementById('set_hidden_pick');
  if (!visPick || !hidPick) return;

  visPick.innerHTML = '';
  hidPick.innerHTML = '';

  const hidden = _getHiddenSet();
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  const sorted = svcs.slice().sort((a,b) => (a.name||'').localeCompare(b.name||''));

  for (const s of sorted){
    const opt = document.createElement('option');
    opt.value = s.unit;
    opt.textContent = `${s.name}  (${s.unit})`;
    if (hidden.has(s.unit)) hidPick.appendChild(opt);
    else visPick.appendChild(opt);
  }
}

function hideSelectedUnits(){
  const visPick = document.getElementById('set_unhidden_pick');
  if (!visPick) return;
  const hidden = _getHiddenSet();
  const selected = Array.from(visPick.selectedOptions || []).map(o => o.value);
  for (const u of selected) hidden.add(u);
  _writeHiddenSetToUI(hidden);
  populateHiddenPicker();
  toast(`Hidden ${selected.length} service(s)`, true);
}

function unhideSelectedUnits(){
  const hidPick = document.getElementById('set_hidden_pick');
  if (!hidPick) return;
  const hidden = _getHiddenSet();
  const selected = Array.from(hidPick.selectedOptions || []).map(o => o.value);
  for (const u of selected) hidden.delete(u);
  _writeHiddenSetToUI(hidden);
  populateHiddenPicker();
  toast(`Unhidden ${selected.length} service(s)`, true);
}

function clearHiddenUnits(){
  if (!confirm('Clear ALL hidden services?')) return;
  _writeHiddenSetToUI(new Set());
  populateHiddenPicker();
  toast('Hidden services cleared', true);
}

async function loadSettings() {
  try {
    const r = await fetch('/api/settings', { method:'GET' });
    const d = await r.json();
    if (!d.ok) { toast(d.error || 'Failed to load settings', false); return; }
    SETTINGS = d.settings || {};
    _ensureSettingsShape();

    document.getElementById('set_viewer_host').value = (SETTINGS.dashboard.viewer_host ?? 'auto') + '';
    document.getElementById('set_viewer_scheme').value = (SETTINGS.dashboard.viewer_scheme ?? 'http') + '';

    document.getElementById('set_default_url_mode').value = (SETTINGS.dashboard.default_url_mode ?? 'local') + '';
    document.getElementById('set_default_domain_suffix').value = (SETTINGS.dashboard.default_domain_suffix ?? 'sidneyshelton.com') + '';
    document.getElementById('set_default_domain_pattern').value = (SETTINGS.dashboard.default_domain_pattern ?? '{unit}.{suffix}') + '';

    refreshCategoryPickers();

    // Dashboard filters & safety
    const hs = document.getElementById('set_hide_stopped');
    const pd = document.getElementById('set_protect_dashboard');
    const hu = document.getElementById('set_hidden_units');
    if (hs) hs.checked = !!SETTINGS.dashboard.hide_stopped_services;
    if (pd) pd.checked = !!SETTINGS.dashboard.protect_dashboard_service;
    if (hu) hu.value = _listToLines(SETTINGS.dashboard.hidden_units);

    populateHiddenPicker();
    populateServicePicker();
    if (DATA && DATA.services && DATA.services.length){
      const pick = document.getElementById('svc_pick');
      if (pick && !pick.value) pick.value = DATA.services[0].unit;
    }
    onPickService();

    // Populate scan paths
    const spEl = document.getElementById('set_scan_paths');
    if (spEl && DATA && DATA.scan_paths){
      spEl.value = DATA.scan_paths.join('\n');
    }
  } catch(e) {
    toast('Settings request failed', false);
  }
}

function _applyUiToSettings(){
  _ensureSettingsShape();

  SETTINGS.dashboard.viewer_host = (document.getElementById('set_viewer_host').value || '').trim() || 'auto';
  SETTINGS.dashboard.viewer_scheme = (document.getElementById('set_viewer_scheme').value || 'http').trim();

  SETTINGS.dashboard.default_url_mode = (document.getElementById('set_default_url_mode')?.value || 'local').trim();
  SETTINGS.dashboard.default_domain_suffix = (document.getElementById('set_default_domain_suffix')?.value || 'sidneyshelton.com').trim();
  SETTINGS.dashboard.default_domain_pattern = (document.getElementById('set_default_domain_pattern')?.value || '{unit}.{suffix}').trim();

  // categories are edited in-memory; keep them in settings
  if (!SETTINGS.categories || typeof SETTINGS.categories !== 'object') SETTINGS.categories = {};

  // Dashboard filters & safety
  const hs = document.getElementById('set_hide_stopped');
  const pd = document.getElementById('set_protect_dashboard');
  const huText = document.getElementById('set_hidden_units');
  SETTINGS.dashboard.hide_stopped_services = hs ? !!hs.checked : false;
  SETTINGS.dashboard.protect_dashboard_service = pd ? !!pd.checked : true;
  // Prefer textarea (manual) if present; fall back to picker selection
  let hu = [];
  if (huText && huText.value != null) {
    hu = _linesToList(huText.value);
  } else {
    const pick = document.getElementById('set_hidden_pick');
    if (pick) hu = Array.from(pick.selectedOptions || []).map(o => o.value);
  }
  SETTINGS.dashboard.hidden_units = hu;


  const unit = _svcKey();
  if (!unit) return;

  if (!SETTINGS.services[unit] || typeof SETTINGS.services[unit] !== 'object') SETTINGS.services[unit] = {};
  const entry = SETTINGS.services[unit];

  entry.runtime          = (document.getElementById('svc_runtime')?.value || 'docker').trim();
  entry.docker_container = (document.getElementById('svc_docker_container')?.value || '').trim() || unit;
  entry.host             = (document.getElementById('svc_host')?.value || 'localhost').trim() || 'localhost';

  const portRaw = (document.getElementById('svc_port').value || '').trim();
  entry.port = portRaw ? parseInt(portRaw, 10) : null;

  const wp = (document.getElementById('svc_web_path').value || '').trim();
  entry.web_path = wp;

  // URL + category per service
  entry.scheme = (document.getElementById('svc_scheme')?.value || '').trim();
  entry.url_mode = (document.getElementById('svc_url_mode')?.value || '').trim();
  entry.domain = (document.getElementById('svc_domain')?.value || '').trim();
  entry.url_override = (document.getElementById('svc_url_override')?.value || '').trim();
  entry.category = (document.getElementById('svc_category')?.value || entry.category || '').trim() || entry.category || 'home';

  entry.config_files = _linesToList(document.getElementById('svc_config_files').value);
  entry.data_paths   = _linesToList(document.getElementById('svc_data_paths').value);
  entry.volume_maps  = _linesToList(document.getElementById('svc_volume_maps')?.value || '');

  if (unit === 'kiwix'){
    entry.kiwix_zim_dir    = (document.getElementById('svc_kiwix_zim_dir').value || '').trim();
    entry.kiwix_library_xml = (document.getElementById('svc_kiwix_library_xml').value || '').trim();
  }
}

async function saveAllSettings() {
  try {
    _applyUiToSettings();
    const payload = { settings: SETTINGS };
    const r = await fetch('/api/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await r.json();
    toast(d.message || (d.ok ? 'Saved' : 'Save failed'), !!d.ok);
    if (d.ok) {
      SETTINGS = d.settings || SETTINGS;
      await loadSettings();
    }
  } catch(e) {
    toast('Save request failed', false);
  }
}

async function autoDetectSelected() {
  try {
    const unit = _svcKey();
    if (!unit) { toast('Select a service first', false); return; }
    const r = await fetch('/api/settings/autodetect', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ unit, apply: true }) });
    const d = await r.json();
    toast(d.ok ? 'Auto-detect applied' : (d.message || 'Auto-detect failed'), !!d.ok);
    if (d.ok) await loadSettings();
  } catch(e) {
    toast('Auto-detect request failed', false);
  }
}

async function autoDetectAll() {
  try {
    const r = await fetch('/api/settings/autodetect', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ all: true, apply: true }) });
    const d = await r.json();
    toast(d.ok ? 'Auto-detect applied to all' : (d.message || 'Auto-detect failed'), !!d.ok);
    if (d.ok) await loadSettings();
  } catch(e) {
    toast('Auto-detect request failed', false);
  }
}

// ── System Files (Settings > General System Files panel) ─────────────────
function renderSystemFiles() {
  const grid = document.getElementById('sysfiles-grid');
  if (!grid) return;
  const files = (DATA && DATA.system_files) ? DATA.system_files : [];
  if (!files.length) {
    grid.innerHTML = '<span style="color:var(--text2);font-size:12px;">No system files configured.</span>';
    return;
  }
  grid.innerHTML = files.map(f => `
    <button class="sysfile-btn" onclick="openSystemFileEditor('${f.path}', '${f.label}')">
      <span class="sysfile-icon">📄</span>
      <span><span class="sysfile-label">${f.label}</span><span class="sysfile-path">${f.path}</span></span>
    </button>`).join('');
}

function openSystemFileEditor(filepath, label) {
  currentEditorUnit = '__system__';
  document.getElementById('etitle').textContent = label || filepath.split('/').pop();
  const filesDiv = document.getElementById('efiles');
  filesDiv.innerHTML = `<button class="file-tab active" onclick="loadFile('${filepath}',this)">${filepath.split('/').pop()}</button>
    <button class="file-tab browse" onclick="openBrowserForSysFile()">📁 Browse /etc…</button>`;
  document.getElementById('editor').classList.add('open');
  _syncModalClass();
  loadFile(filepath, filesDiv.querySelector('.file-tab'));
}

function openBrowserForSysFile() {
  browserCallback = function(filepath) {
    const label = filepath.split('/').pop();
    openSystemFileEditor(filepath, label);
  };
  openBrowser('/etc');
}

// ── End System Files ──────────────────────────────────────────────────────

// Viewer
function _syncModalClass(){
  const v = document.getElementById('viewer');
  const e = document.getElementById('editor');
  const b = document.getElementById('browser');
  const open = (v && v.classList.contains('open')) || (e && e.classList.contains('open')) || (b && b.classList.contains('open'));
  document.body.classList.toggle('modal-open', !!open);
}
function _viewerSetBlocked(isBlocked, reason, url){
  const fr = document.getElementById('vframe');
  const blk = document.getElementById('vblocked');
  const r = document.getElementById('vblocked_reason');
  const o = document.getElementById('vblocked_open');
  if(!fr || !blk) return;
  if(isBlocked){
    try{ fr.src = ''; }catch(e){}
    fr.style.display = 'none';
    blk.style.display = 'block';
    if(r) r.textContent = reason || 'This site blocks iframe embedding (X-Frame-Options / Content-Security-Policy).';
    if(o && url){ o.href = url; }
  }else{
    blk.style.display = 'none';
    fr.style.display = 'block';
  }
}

async function _viewerCheckEmbeddable(url){
  try{
    const res = await fetch('/api/embed_check?url=' + encodeURIComponent(url));
    if(!res.ok) return {embeddable: true};
    return await res.json();
  }catch(e){
    return {embeddable: true};
  }
}

let _lastViewer = {name:'', url:''};

async function openViewer(name, url) {
  _lastViewer = {name, url};

  // IMPORTANT:
  // To avoid popup blockers, pre-open a tab synchronously (user click) and only use it
  // if embedding is blocked. If embedding is allowed, we immediately close it.
  let pop = null;
  try { pop = window.open('about:blank', '_blank'); } catch(e) { pop = null; }
  const popOk = !!pop;

  document.getElementById('vtitle').textContent = name;
  document.getElementById('vurl').textContent = url;
  document.getElementById('vext').href = url;

  // default: try embed
  _viewerSetBlocked(false, '', url);
  const fr = document.getElementById('vframe');
  if(fr){
    fr.src = url;
  }

  document.getElementById('viewer').classList.add('open');
  _syncModalClass();

  // Option A: if server says it can't be embedded, auto-open in a new tab
  const chk = await _viewerCheckEmbeddable(url);
  if(chk && chk.embeddable === false){
    // If we were able to open a pop-up, use it; otherwise show the fallback panel with a manual button.
    if(popOk){
      try { pop.location = url; } catch(e){}
      try { toast('This service blocks embedding — opened in a new tab.', true); } catch(e){}
      closeViewer();
      return;
    } else {
      _viewerSetBlocked(true, chk.reason || 'Embedding blocked by the service.', url);
      return;
    }
  }

  // Embedding is allowed: close the pre-opened tab if it exists
  if(popOk){
    try { pop.close(); } catch(e){}
  }
}

function retryViewerEmbed(){
  if(!_lastViewer || !_lastViewer.url) return;
  // force another attempt
  const url = _lastViewer.url;
  _viewerSetBlocked(false, '', url);
  const fr = document.getElementById('vframe');
  if(fr){ fr.src = url; }
}

function closeViewer() {
  document.getElementById('viewer').classList.remove('open');
  _syncModalClass();
  const fr = document.getElementById('vframe');
  if(fr) fr.src = '';
  _viewerSetBlocked(false, '', '');
}

function closeViewer() {
  document.getElementById('viewer').classList.remove('open');
  _syncModalClass();
  document.getElementById('vframe').src = '';
}

// Editor
async function openEditor(unit) {
  const svc = DATA.services.find(s => s.unit === unit);
  if (!svc) { toast('Service not found', false); return; }
  
  currentEditorUnit = unit;
  document.getElementById('etitle').textContent = svc.name + ' Config';
  const filesDiv = document.getElementById('efiles');
  
  // Check if we have config files defined
  if (!svc.config_files || svc.config_files.length === 0) {
    // No config files - show browser button
    filesDiv.innerHTML = `
      <span style="color:var(--text2);font-size:11px;">No config files defined.</span>
      <button class="file-tab browse" onclick="openBrowserForEditor('${unit}')">📁 Browse for file...</button>
    `;
    document.getElementById('etext').value = '';
    document.getElementById('epath').textContent = 'No file selected';
    document.getElementById('estatus').textContent = 'Use Browse to find a config file, or add paths in Settings.';
    document.getElementById('editor').classList.add('open');
    _syncModalClass();
    return;
  }
  
  // Build file tabs with browse option
  let tabsHtml = svc.config_files.map((f,i) =>
    `<button class="file-tab ${i===0?'active':''}" onclick="loadFile('${f}',this)">${f.split('/').pop()}</button>`
  ).join('');
  tabsHtml += `<button class="file-tab browse" onclick="openBrowserForEditor('${unit}')">📁 Browse...</button>`;
  filesDiv.innerHTML = tabsHtml;
  
  document.getElementById('editor').classList.add('open');
    _syncModalClass();
  await loadFile(svc.config_files[0], filesDiv.querySelector('.file-tab'));
}

async function loadFile(filepath, tabEl) {
  currentEditorFile = filepath;
  document.querySelectorAll('.file-tab').forEach(e => e.classList.remove('active'));
  if (tabEl) tabEl.classList.add('active');
  document.getElementById('epath').textContent = filepath;
  document.getElementById('estatus').textContent = 'Loading...';
  try {
    const r = await fetch('/api/config?path=' + encodeURIComponent(filepath));
    const d = await r.json();
    if (d.ok) {
      document.getElementById('etext').value = d.content;
      updateLineCount();
      document.getElementById('estatus').textContent = 'Loaded';
    } else {
      document.getElementById('etext').value = '';
      document.getElementById('estatus').innerHTML = `<span class="error">${d.error}</span>`;
    }
  } catch(e) {
    document.getElementById('estatus').innerHTML = '<span class="error">Failed to load</span>';
  }
}

async function saveFile() {
  if (!currentEditorFile) { toast('No file selected', false); return; }
  const content = document.getElementById('etext').value;
  document.getElementById('estatus').textContent = 'Saving...';
  try {
    const r = await fetch('/api/config', { method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:currentEditorFile, content}) });
    const d = await r.json();
    if (d.ok) {
      document.getElementById('estatus').innerHTML = '<span class="saved">✓ Saved (backup created)</span>';
      toast('File saved', true);
    } else {
      document.getElementById('estatus').innerHTML = `<span class="error">${d.error}</span>`;
      toast(d.error, false);
    }
  } catch(e) { toast('Save failed', false); }
}

function closeEditor() {
  document.getElementById('editor').classList.remove('open');
  _syncModalClass();
  currentEditorFile = null; currentEditorUnit = null;
}

function updateLineCount() {
  const t = document.getElementById('etext');
  const lines = t.value.split('\n').length;
  document.getElementById('elines').textContent = lines + ' lines';
}

// File Browser
function openBrowserForEditor(unit) {
  // Start browser in the service's own appdata dir if it exists, else /opt/appdata
  const svc = DATA ? DATA.services.find(s => s.unit === unit) : null;
  let startPath = '/opt/appdata';
  if (svc && svc.data_paths && svc.data_paths.length > 0) {
    startPath = svc.data_paths[0];
  }
  browserCallback = function(filepath) {
    // Add the file to the config and load it
    loadFile(filepath, null);
    // Also add a new tab for it
    const filesDiv = document.getElementById('efiles');
    const filename = filepath.split('/').pop();
    const newTab = document.createElement('button');
    newTab.className = 'file-tab active';
    newTab.textContent = filename;
    newTab.onclick = function() { loadFile(filepath, newTab); };
    // Insert before browse button
    const browseBtn = filesDiv.querySelector('.browse');
    filesDiv.insertBefore(newTab, browseBtn);
  };
  openBrowser(startPath);
}

async function openBrowser(startPath) {
  document.getElementById('browser').classList.add('open');
  _syncModalClass();
  document.getElementById('binput').value = startPath || '/opt';
  await loadBrowserDir(startPath || '/opt');
}

async function loadBrowserDir(path) {
  document.getElementById('bpath').textContent = path;
  document.getElementById('binput').value = path;
  document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--text2);">Loading...</div>';
  
  try {
    const r = await fetch('/api/browse?path=' + encodeURIComponent(path));
    const d = await r.json();
    if (!d.ok) {
      document.getElementById('blist').innerHTML = `<div style="padding:20px;color:var(--red);">${d.error}</div>`;
      return;
    }
    
    const items = d.data.items || [];
    if (items.length === 0) {
      document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--text2);">Empty directory</div>';
      return;
    }
    
    let html = '';
    items.forEach(item => {
      if (item.type === 'dir') {
        html += `<div class="browser-item dir" onclick="loadBrowserDir('${item.path}')">${ICO.folder} ${item.name}</div>`;
      } else {
        html += `<div class="browser-item file" onclick="selectBrowserFile('${item.path}')">${ICO.file} ${item.name}</div>`;
      }
    });
    document.getElementById('blist').innerHTML = html;
  } catch(e) {
    document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--red);">Failed to load directory</div>';
  }
}

function selectBrowserFile(filepath) {
  document.getElementById('binput').value = filepath;
  selectBrowserPath();
}

function selectBrowserPath() {
  const path = document.getElementById('binput').value.trim();
  if (!path) { toast('Enter a path', false); return; }
  closeBrowser();
  if (browserCallback) {
    browserCallback(path);
    browserCallback = null;
  }
}

function closeBrowser() {
  document.getElementById('browser').classList.remove('open');
  _syncModalClass();
}

// Logs
function buildLogList() {
  if (!DATA) return;
  const el = document.getElementById('jlist');
  const svcs = DATA.services.filter(s => s.status === 'active');
  if (svcs.length === 0) {
    el.innerHTML = '<div style="color:var(--text2);padding:8px;">No active services</div>';
    return;
  }
  el.innerHTML = svcs.map(s => `<button class="jbtn" onclick="fetchLog('${s.unit}',this)">${s.name}</button>`).join('');
}

async function fetchLog(unit, btn) {
  document.querySelectorAll('.jbtn').forEach(e => e.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById('jout').textContent = 'Loading...';
  try {
    const r = await fetch('/api/logs?unit=' + encodeURIComponent(unit));
    const d = await r.json();
    document.getElementById('jout').textContent = d.logs || 'No logs available';
  } catch(e) { document.getElementById('jout').textContent = 'Failed to fetch logs'; }
}

// Data
async function fetchData() {
  try {
    const r = await fetch('/api/status');
    DATA = await r.json();
    renderSys(DATA.system);
    renderSvc(DATA.services, DATA.categories);
    renderSystemFiles();
    if (DATA.app && DATA.app.version) {
      const vEl = document.getElementById('appver');
      if (vEl) vEl.textContent = 'v' + DATA.app.version;
    }
    const total = DATA.services.length, active = DATA.services.filter(s=>s.status==='active').length;
    const tmem = DATA.services.reduce((a,s) => a+(s.memory_mb||0), 0);
    document.getElementById('fsum').textContent = `${active}/${total} services active · ${tmem.toFixed(0)} MB total`;
    document.getElementById('fupd').textContent = 'Updated: ' + new Date(DATA.timestamp).toLocaleTimeString();
  } catch(e) { 
    console.error('Fetch error:', e);
    document.getElementById('fsum').textContent = 'Error loading data';
  }
}

function tick() {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString();
  countdown--;
  if (countdown <= 0) { countdown = 30; fetchData(); }
  document.getElementById('rtimer').textContent = countdown + 's';
}

// Escape key closes overlays
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeViewer(); closeEditor(); closeBrowser(); }
});

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('etext').addEventListener('input', updateLineCount);
  // Tab key support in editor
  document.getElementById('etext').addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = this.selectionStart, end = this.selectionEnd;
      this.value = this.value.substring(0,s) + '    ' + this.value.substring(end);
      this.selectionStart = this.selectionEnd = s + 4;
    }
  });
});

fetchData();
tick();
setInterval(tick, 1000);

async function applyBulkEdits(){
  _ensureSettingsShape();
  refreshCategoryPickers();

  const scope = document.getElementById('bulk_scope')?.value || 'all';
  const scopeCat = document.getElementById('bulk_scope_category')?.value || '';
  const scheme = (document.getElementById('bulk_scheme')?.value || '').trim();
  const urlMode = (document.getElementById('bulk_url_mode')?.value || '').trim();
  const newCat = (document.getElementById('bulk_category')?.value || '').trim();

  // Optional: update dashboard defaults from bulk inputs (common use-case)
  const ds = (document.getElementById('bulk_domain_suffix')?.value || '').trim();
  const dp = (document.getElementById('bulk_domain_pattern')?.value || '').trim();
  if (ds) SETTINGS.dashboard.default_domain_suffix = ds;
  if (dp) SETTINGS.dashboard.default_domain_pattern = dp;

  let changed = 0;
  for (const unit of Object.keys(SETTINGS.services || {})){
    const entry = SETTINGS.services[unit];
    if (!entry || typeof entry !== 'object') continue;
    if (scope === 'category' && scopeCat && (entry.category || '') !== scopeCat) continue;

    if (scheme !== '') entry.scheme = scheme;
    if (urlMode !== '') entry.url_mode = urlMode;
    if (newCat !== '') entry.category = newCat;

    changed++;
  }
  toast(`Bulk edits applied to ${changed} service entries (click Save).`, true);
  onPickService();
}

async function addCategory(){
  _ensureSettingsShape();
  const key = (document.getElementById('cat_key')?.value || '').trim();
  const label = (document.getElementById('cat_label')?.value || '').trim();
  const icon = (document.getElementById('cat_icon')?.value || '').trim();

  if (!key){
    toast('Category key is required (e.g. books)', false);
    return;
  }
  if (!SETTINGS.categories || typeof SETTINGS.categories !== 'object') SETTINGS.categories = {};
  SETTINGS.categories[key] = { label: label || key, icon: icon || '🧩' };
  refreshCategoryPickers();

  toast(`Category '${key}' added/updated (click Save).`, true);
}
