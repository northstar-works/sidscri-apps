#!/usr/bin/env python3
"""
SidscriServer Dashboard v2.2.1
- Real-time system & Docker container monitoring
- Start / Stop / Restart buttons (via docker CLI)
- Built-in iframe service viewer
- Config file editor GUI with browse fallback
- Kiwix library refresh
Runs on port 8029
"""

import subprocess
import json
import os
import re
import urllib.parse
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
import shutil
import time

# ─── Service Definitions ───
# (name, unit, port, category, description, web_path, config_files)
# web_path=None means no web UI, web_path="" means root
SERVICES = [
    # Media
    # config_files = service-specific app config + its own systemd unit file only.
    # System-wide /etc files (fstab, smb.conf, etc) live in Settings > System Files.
    ("Plex", "plexmediaserver", 32400, "media", "Media Server", "/web", [
        "/etc/systemd/system/plexmediaserver.service",
    ]),
    ("Navidrome", "navidrome", 4533, "media", "Music Streaming", "", [
        "/opt/appdata/navidrome/navidrome.toml",
        "/etc/systemd/system/navidrome.service",
    ]),
    ("Kiwix", "kiwix", 8090, "media", "Offline Wikipedia", "", [
        "/etc/systemd/system/kiwix.service",
    ]),
    ("MPD Local", "mpd", 6600, "media", "Music Player (Local)", None, [
        "/etc/mpd.conf",
        "/etc/systemd/system/mpd.service",
    ]),
    ("MPD Stream", "mpd-stream", 6601, "media", "Music Player (HTTP Stream)", None, [
        "/etc/mpd-stream.conf",
        "/etc/systemd/system/mpd-stream.service",
    ]),
    ("ympd Local", "ympd-local", 8586, "media", "MPD Web UI (Local)", "", [
        "/etc/systemd/system/ympd-local.service",
    ]),
    ("ympd Stream", "ympd-stream", 8587, "media", "MPD Web UI (Stream)", "", [
        "/etc/systemd/system/ympd-stream.service",
    ]),

    # *arr Stack
    ("Sonarr A", "sonarr-a", 8989, "arr", "TV Shows (A)", "", [
        "/opt/appdata/sonarr-a/config/config.xml",
        "/etc/systemd/system/sonarr-a.service",
    ]),
    ("Sonarr B", "sonarr-b", 8990, "arr", "TV Shows (B)", "", [
        "/opt/appdata/sonarr-b/config/config.xml",
        "/etc/systemd/system/sonarr-b.service",
    ]),
    ("Radarr A", "radarr-a", 7878, "arr", "Movies (A)", "", [
        "/opt/appdata/radarr-a/config/config.xml",
        "/etc/systemd/system/radarr-a.service",
    ]),
    ("Radarr B", "radarr-b", 7879, "arr", "Movies (B)", "", [
        "/opt/appdata/radarr-b/config/config.xml",
        "/etc/systemd/system/radarr-b.service",
    ]),
    ("Lidarr B", "lidarr-b", 8687, "arr", "Music (B)", "", [
        "/opt/appdata/lidarr-b/config/config.xml",
        "/etc/systemd/system/lidarr-b.service",
    ]),
    ("Readarr A", "readarr-a", 8787, "arr", "Books (A)", "", [
        "/opt/appdata/readarr-a/config/config.xml",
        "/etc/systemd/system/readarr-a.service",
    ]),
    ("Readarr B", "readarr-b", 8788, "arr", "Books (B)", "", [
        "/opt/appdata/readarr-b/config/config.xml",
        "/etc/systemd/system/readarr-b.service",
    ]),
    ("Readarr Audiobooks A", "readarr-audiobooks-a", 8789, "arr", "Audiobooks (A)", "", [
        "/opt/appdata/readarr-audiobooks-a/config/config.xml",
        "/etc/systemd/system/readarr-audiobooks-a.service",
    ]),
    ("Readarr Audiobooks B", "readarr-audiobooks-b", 8790, "arr", "Audiobooks (B)", "", [
        "/opt/appdata/readarr-audiobooks-b/config/config.xml",
        "/etc/systemd/system/readarr-audiobooks-b.service",
    ]),
    ("Prowlarr A", "prowlarr-a", 9696, "arr", "Indexer Manager (A)", "", [
        "/opt/appdata/prowlarr-a/config/config.xml",
        "/etc/systemd/system/prowlarr-a.service",
    ]),
    ("Prowlarr B", "prowlarr-b", 9697, "arr", "Indexer Manager (B)", "", [
        "/opt/appdata/prowlarr-b/config/config.xml",
        "/etc/systemd/system/prowlarr-b.service",
    ]),

    # Downloads
    ("Deluge Daemon", "deluged", 58846, "downloads", "Torrent Daemon", None, [
        "/etc/systemd/system/deluged.service",
    ]),
    ("Deluge Web", "deluge-web", 8112, "downloads", "Torrent Web UI", "", [
        "/etc/systemd/system/deluge-web.service",
    ]),
    ("SABnzbd", "sabnzbd", 8095, "downloads", "Usenet Downloader", "", [
        "/etc/systemd/system/sabnzbd.service",
    ]),

    # TV / DVR
    ("xTeVe A", "xteve-a", 34400, "tv", "IPTV Proxy (A)", "/web", [
        "/etc/systemd/system/xteve-a.service",
    ]),
    ("xTeVe B", "xteve-b", 34401, "tv", "IPTV Proxy (B)", "/web", [
        "/etc/systemd/system/xteve-b.service",
    ]),

    # Home & Apps
    ("Home Assistant", "homeassistant", 8123, "home", "Home Automation", "", [
        "/opt/appdata/homeassistant/config/configuration.yaml",
        "/etc/systemd/system/homeassistant.service",
    ]),
    ("Adv. Flashcards", "advanced-flashcards", 8009, "home", "Flashcards Web Server", "", [
        "/etc/systemd/system/advanced-flashcards.service",
    ]),

    # System — service-specific configs only; smb.conf is in Settings > System Files
    ("SSH", "ssh", 22, "system", "Secure Shell", None, [
        "/etc/ssh/sshd_config",
        "/etc/systemd/system/ssh.service",
    ]),
    ("Samba", "smbd", 445, "system", "File Sharing", None, [
        # smb.conf is a system-wide file → Settings > System Files
        "/etc/systemd/system/smbd.service",
    ]),
    ("xRDP", "xrdp", 3389, "system", "Remote Desktop", None, [
        "/etc/xrdp/xrdp.ini",
        "/etc/systemd/system/xrdp.service",
    ]),
    ("CUPS", "cups", 631, "system", "Printing", "", [
        "/etc/systemd/system/cups.service",
    ]),
    ("Bluetooth", "bluetooth", None, "system", "Bluetooth Service", None, [
        "/etc/bluetooth/main.conf",
        "/etc/systemd/system/bluetooth.service",
    ]),
    ("Server Dashboard", "server-dashboard", 8029, "system", "This Dashboard", "", [
        "/opt/app/server-dashboard/server.py",
        "/etc/systemd/system/server-dashboard.service",
    ]),
]

CATEGORY_META = {
    "media":     {"label": "Media", "icon": "🎬"},
    "arr":       {"label": "Arr Stack", "icon": "📡"},
    "downloads": {"label": "Downloads", "icon": "⬇️"},
    "tv":        {"label": "TV / DVR", "icon": "📺"},
    "home":      {"label": "Home & Apps", "icon": "🏠"},
    "system":    {"label": "System", "icon": "⚙️"},
}

# Safety: only allow editing files under these paths
ALLOWED_EDIT_PATHS = [
    "/opt/appdata/", "/etc/mpd", "/etc/samba/", "/etc/ssh/",
    "/etc/bluetooth/", "/etc/xrdp/", "/opt/server-dashboard/",
    "/opt/appdata/homeassistant/", "/opt/appdata/navidrome/",
    "/opt/", "/etc/", "/home/",
]

# System-wide files accessible from Settings > System Files panel
# These are intentionally NOT listed in any service's config_files.
SYSTEM_FILES = [
    {"label": "smb.conf",              "path": "/etc/samba/smb.conf"},
    {"label": "fstab",                 "path": "/etc/fstab"},
    {"label": "hosts",                 "path": "/etc/hosts"},
    {"label": "hostname",              "path": "/etc/hostname"},
    {"label": "host.conf",             "path": "/etc/host.conf"},
    {"label": "adduser.conf",          "path": "/etc/adduser.conf"},
    {"label": "deluser.conf",          "path": "/etc/deluser.conf"},
    {"label": "ca-certificates.conf",  "path": "/etc/ca-certificates.conf"},
    {"label": "debconf.conf",          "path": "/etc/debconf.conf"},
    {"label": "gai.conf",              "path": "/etc/gai.conf"},
    {"label": "ld.so.conf",            "path": "/etc/ld.so.conf"},
    {"label": "libaudit.conf",         "path": "/etc/libaudit.conf"},
    {"label": "ssh/sshd_config",       "path": "/etc/ssh/sshd_config"},
    {"label": "crontab",               "path": "/etc/crontab"},
    {"label": "network/interfaces",    "path": "/etc/network/interfaces"},
]


# ─── Dashboard Settings (dashboard-only mappings) ───
SETTINGS_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "settings.json")


def _minimal_settings_template():
    # schema_version bump is safe; older fields are still honored.
    return {
        "schema_version": 3,
        "dashboard": {
            "viewer_host": "auto",
            "viewer_scheme": "http",

            # New: defaults for per-service URLs
            "default_url_mode": "local",               # local | domain
            "default_domain_suffix": "sidneyshelton.com",
            "default_domain_pattern": "{unit}.{suffix}",

            "hide_stopped_services": False,
            "protect_dashboard_service": True,
            "hidden_units": []
        },

        # New: categories are now configurable in settings
        "categories": CATEGORY_META,

        "services": {
            "server-dashboard": {
                "display_name": "Server Dashboard",
                "unit": "server-dashboard",
                "runtime": "docker",
                "docker_container": "server-dashboard",
                "host": "localhost",
                "port": 8029,
                "web_path": "",
                "category": "system",
                "description": "",
                "config_files": [],
                "data_paths": [],
                "volume_maps": [],

                # Optional URL overrides
                "url_mode": "local",
                "scheme": "http",
                "domain": "",
                "url_override": ""
            }
        },
        "auto_detect": {"enabled": False, "write_back_missing": False},
        "bootstrap": {"mode": "blank", "scan_paths": ["/opt/appdata:/config", "/opt/app:/app"]}
    }

def _write_minimal_settings_file(path=SETTINGS_PATH):
    s = _minimal_settings_template()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except Exception:
        pass
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2)
    os.replace(tmp, path)
    return s

SETTINGS_SCHEMA_VERSION = 2

def _default_service_map():
    svc = {}
    for name, unit, port, cat, desc, web_path, configs in SERVICES:
        guessed_data = []
        guessed_data.append(f"/opt/appdata/{unit}")
        for cf in (configs or []):
            try:
                d = os.path.dirname(cf)
                if d and d not in guessed_data:
                    guessed_data.append(d)
            except Exception:
                pass

        entry = {
            "display_name": name,
            "unit": unit,
            "runtime": "docker",        # docker | systemd | external
            "host": "localhost",         # IP or hostname; used for external and view URL
            "docker_container": unit,   # docker container name (may differ from unit)
            "volume_maps": [],           # ["host_path:container_path", ...]
            "port": port,
            "web_path": web_path,
            "category": cat,
            "description": desc,
            "config_files": list(configs or []),
            "data_paths": guessed_data,
        }

        if unit == "kiwix":
            entry["kiwix_zim_dir"] = "/opt/appdata/kiwix/data/zims"
            entry["kiwix_library_xml"] = "/opt/appdata/kiwix/data/library.xml"

        svc[unit] = entry
    return svc

def default_settings():
    return {
        "schema_version": SETTINGS_SCHEMA_VERSION,
        "dashboard": {
            "viewer_host": "auto",
            "viewer_scheme": "http",
            "hide_stopped_services": False,
            "protect_dashboard_service": True,
            "hidden_units": [],
        },
        "services": _default_service_map(),
        "auto_detect": {
            "enabled": True,
            "write_back_missing": True,
        },
        "bootstrap": {
            "mode": "embedded",          # "embedded" = use SERVICES list; "blank" = start fresh
            "scan_paths": [              # host:container path overrides for docker-inspect scan
                "/opt/appdata:/config",
                "/opt/app:/app",
            ],
        },
    }

def _migrate_old_settings(obj):
    """Migrate very old settings.json (kiwix_* keys at root) to schema v2."""
    s = default_settings()
    if isinstance(obj, dict):
        kz = obj.get("kiwix_zim_dir")
        kx = obj.get("kiwix_library_xml")
        if kz:
            s["services"]["kiwix"]["kiwix_zim_dir"] = str(kz)
        if kx:
            s["services"]["kiwix"]["kiwix_library_xml"] = str(kx)
        vh = obj.get("viewer_host") or obj.get("dashboard_host")
        if vh:
            s["dashboard"]["viewer_host"] = str(vh)
    return s

def _autodetect_service(unit, current_entry):
    """Best-effort discovery: docker mounts, config files (.conf/.xml/.db/.json etc)."""
    entry = dict(current_entry or {})
    entry.setdefault("unit", unit)
    runtime = str(entry.get("runtime", "docker")).strip()

    # ── Docker: read actual bind-mount paths ──────────────────────────────
    if runtime in ("docker", ""):
        try:
            mounts_out, rc = run_cmd(
                f"docker inspect --format='{{{{range .Mounts}}}}{{{{.Source}}}}:{{{{.Destination}}}} {{{{end}}}}' {unit} 2>/dev/null",
                timeout=4
            )
            if rc == 0 and mounts_out.strip():
                for pair in mounts_out.strip().split():
                    src = pair.split(":")[0] if ":" in pair else pair
                    if src.startswith("/") and src not in entry.get("data_paths", []):
                        entry.setdefault("data_paths", []).append(src)
                    vm = pair if ":" in pair else None
                    if vm and vm not in entry.get("volume_maps", []):
                        entry.setdefault("volume_maps", []).append(vm)
        except Exception:
            pass

    # ── Candidate directories to scan ─────────────────────────────────────
    common_dirs = [
        f"/opt/appdata/{unit}/config",
        f"/opt/appdata/{unit}",
        f"/opt/app/{unit}",
        f"/etc/{unit}",
        "/etc",
    ]
    for dp in entry.get("data_paths", []):
        if dp not in common_dirs:
            common_dirs.append(dp)

    # ── Config + DB file discovery ─────────────────────────────────────────
    CONFIG_EXTS = (".conf", ".ini", ".toml", ".xml", ".yaml", ".yml", ".json", ".cfg", ".env")
    DB_EXTS     = (".db", ".sqlite", ".sqlite3")
    KNOWN_NAMES = {"config.xml", "config.ini", "settings.json", "app.db", "library.db",
                   "nzbdrone.db", "logs.db", "main.db", "tautulli.db"}

    cfgs = entry.get("config_files") or []
    cfgs_existing = [c for c in cfgs if isinstance(c, str) and c.startswith("/") and os.path.isfile(c)]

    if not cfgs_existing:
        candidates = []
        for d in common_dirs:
            if os.path.isdir(d):
                try:
                    for fn in sorted(os.listdir(d)):
                        fp = os.path.join(d, fn)
                        if not os.path.isfile(fp):
                            continue
                        fl = fn.lower()
                        if (any(fl.endswith(ext) for ext in CONFIG_EXTS + DB_EXTS)
                                or fl in KNOWN_NAMES):
                            candidates.append(fp)
                except Exception:
                    pass
        if candidates:
            entry["config_files"] = sorted(list(dict.fromkeys(candidates)))[:12]

    # ── Clean data_paths ──────────────────────────────────────────────────
    dps = []
    for p in entry.get("data_paths", []):
        p = str(p).strip()
        if p.startswith("/") and p not in dps:
            dps.append(p)
    entry["data_paths"] = dps
    return entry

def load_settings():
    # JSON-only source of truth. If missing/invalid, auto-recover to minimal file.
    try:
        if not os.path.exists(SETTINGS_PATH):
            return _write_minimal_settings_file()

        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)

        if not isinstance(s, dict):
            raise ValueError("settings.json root must be object")

        if not isinstance(s.get("dashboard"), dict):
            s["dashboard"] = _minimal_settings_template()["dashboard"]
        # Ensure new dashboard defaults exist (backwards compatible)
        s["dashboard"].setdefault("default_url_mode", "local")
        s["dashboard"].setdefault("default_domain_suffix", "sidneyshelton.com")
        s["dashboard"].setdefault("default_domain_pattern", "{unit}.{suffix}")

        if not isinstance(s.get("services"), dict):
            s["services"] = {}
        if not isinstance(s.get("categories"), dict):
            s["categories"] = CATEGORY_META

        if not isinstance(s.get("auto_detect"), dict):
            s["auto_detect"] = _minimal_settings_template()["auto_detect"]
        if not isinstance(s.get("bootstrap"), dict):
            s["bootstrap"] = _minimal_settings_template()["bootstrap"]

        if "server-dashboard" not in s["services"]:
            s["services"]["server-dashboard"] = _minimal_settings_template()["services"]["server-dashboard"]

        return s

    except Exception:
        try:
            if os.path.exists(SETTINGS_PATH):
                bad = SETTINGS_PATH + ".bad-" + datetime.now().strftime("%Y%m%d_%H%M%S")
                shutil.copy2(SETTINGS_PATH, bad)
        except Exception:
            pass
        try:
            return _write_minimal_settings_file()
        except Exception:
            return _minimal_settings_template()


def _validate_settings(s):
    """
    Minimal validator fallback for patched builds.
    Returns (ok: bool, msg: str)
    """
    try:
        if not isinstance(s, dict):
            return False, "Settings root must be an object"

        if "dashboard" in s and not isinstance(s.get("dashboard"), dict):
            return False, "dashboard must be an object"

        if "services" in s and not isinstance(s.get("services"), dict):
            return False, "services must be an object"

        # Light per-service checks only (don't block on missing optional fields)
        for unit, svc in (s.get("services") or {}).items():
            if not isinstance(svc, dict):
                return False, f"service '{unit}' must be an object"
            if not unit or not isinstance(unit, str):
                return False, "service key must be a non-empty string"

        return True, ""
    except Exception as e:
        return False, str(e)


def save_settings(s):
    ok, msg = _validate_settings(s)
    if not ok:
        return False, msg

    tmp = SETTINGS_PATH + ".tmp"
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(tmp, "w") as f:
            json.dump(s, f, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True, "Settings saved"
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False, str(e)


def run_cmd(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or '').strip()
        err = (r.stderr or '').strip()
        if r.returncode != 0 and err:
            return ((out + ('\n' if out else '') + err).strip()), r.returncode
        return out, r.returncode
    except Exception as e:
        return str(e), 1


def _docker_target_for_unit(unit):
    try:
        s = load_settings()
        entry = ((s.get('services', {}) or {}).get(unit, {}) if isinstance(s, dict) else {})
        if isinstance(entry, dict):
            target = str(entry.get('docker_container', unit)).strip()
            if target:
                return target
    except Exception:
        pass
    return unit


def get_service_status(unit, runtime="docker"):
    if runtime == "systemd":
        out, rc = run_cmd(f"systemctl is-active {unit} 2>/dev/null")
        s = out.strip()
        return "active" if s == "active" else ("inactive" if s in ("inactive","failed") else "unknown")
    elif runtime == "external":
        return "unknown"
    else:  # docker
        target = _docker_target_for_unit(unit)
        out, rc = run_cmd(f"docker inspect --format='{{{{.State.Status}}}}' {target} 2>/dev/null")
        status = out.strip().strip("'")
        if status == "running": return "active"
        if status in ("exited","dead","removing"): return "inactive"
        if status in ("paused","restarting","created"): return status
        return "unknown"


def get_service_memory(unit, runtime="docker"):
    if runtime != "docker": return None
    target = _docker_target_for_unit(unit)
    out, rc = run_cmd(f"docker stats --no-stream --format '{{{{.MemUsage}}}}' {target} 2>/dev/null")
    try:
        used = out.strip().split("/")[0].strip()
        val = float(''.join(c for c in used if c.isdigit() or c == '.'))
        u = used.upper()
        if "GIB" in u or "GB" in u: return val * 1024
        if "KIB" in u or "KB" in u: return val / 1024
        return val
    except Exception: pass
    return None


def get_service_cpu(unit, runtime="docker"):
    if runtime != "docker": return None
    target = _docker_target_for_unit(unit)
    out, rc = run_cmd(f"docker stats --no-stream --format '{{{{.CPUPerc}}}}' {target} 2>/dev/null")
    try:
        pct = out.strip().replace("%", "")
        return float(pct) if pct else None
    except Exception: pass
    return None


def service_control(unit, action):
    if action not in ('start', 'stop', 'restart'):
        return False, "Invalid action"
    s = load_settings()
    svc_map = s.get("services", {})
    all_units = set(svc_map.keys()) | {sv[1] for sv in SERVICES}
    if unit not in all_units:
        return False, "Unknown service"
    try:
        dash = s.get("dashboard", {})
        if action == "stop" and unit == "server-dashboard":
            if bool(dash.get("protect_dashboard_service", True)):
                return False, "Stop is disabled for Server Dashboard (Settings)"
    except Exception:
        pass
    entry  = svc_map.get(unit, {})
    runtime = str(entry.get("runtime", "docker")).strip()
    if runtime == "systemd":
        out, rc = run_cmd(f"sudo systemctl {action} {unit}", timeout=15)
    elif runtime == "external":
        return False, "External services cannot be controlled from this dashboard"
    else:
        container = str(entry.get("docker_container", unit)).strip() or unit

        # Special case: restarting the dashboard's own container can drop the HTTP connection
        # before the browser receives the JSON response. Do a delayed restart in the background.
        if unit == "server-dashboard" and action == "restart":
            try:
                subprocess.Popen(["sh", "-c", f"sleep 1; docker restart {container} >/dev/null 2>&1 || true"])
                return True, f"restarting {unit}"
            except Exception:
                pass

        out, rc   = run_cmd(f"docker {action} {container}", timeout=15)
    if rc == 0: return True, f"{action}ed {unit}"
    return False, out or f"Failed to {action} {unit}"


# ── Scan helpers ───────────────────────────────────────────────────────────
def _scan_docker():
    out, rc = run_cmd("docker ps -a --format '{{.Names}}|{{.Image}}|{{.Ports}}|{{.Status}}' 2>/dev/null", timeout=8)
    results = []
    if rc != 0 or not out.strip():
        return results

    s = load_settings()
    svc_map = (s.get("services", {}) or {}) if isinstance(s, dict) else {}
    existing_units = set(svc_map.keys())
    existing_docker_names = set()
    for _, entry in svc_map.items():
        if isinstance(entry, dict) and str(entry.get("runtime", "docker")).strip() == "docker":
            existing_docker_names.add(str(entry.get("docker_container", "")).strip())

    for line in out.strip().splitlines():
        parts = line.split("|")
        if len(parts) < 4:
            continue
        name, image, ports, status = parts[0], parts[1], parts[2], parts[3]

        if name == "services-server-dashboard-service-1":
            continue
        if name in existing_units or name in existing_docker_names:
            continue

        suggested = None
        pm = re.search(r':(\d+)->', ports)
        if pm:
            try:
                suggested = int(pm.group(1))
            except Exception:
                suggested = None

        results.append({
            "container": name,
            "image": image,
            "ports": ports,
            "status": status,
            "suggested_port": suggested
        })
    return results

def _scan_systemd():
    out, rc = run_cmd(
        "systemctl list-units --type=service --state=active --no-pager --no-legend 2>/dev/null", timeout=8)
    results = []
    if rc != 0 or not out.strip(): return results
    known = {s[1] for s in SERVICES}
    for line in out.strip().splitlines():
        parts = line.split(None, 4)
        if not parts: continue
        unit_name = parts[0].replace(".service", "")
        if unit_name in known: continue
        results.append({"unit": unit_name, "active": parts[2] if len(parts) > 2 else "active",
                        "description": parts[4].strip() if len(parts) > 4 else "", "suggested_port": None})
    return results[:30]

def _scan_ports():
    out, rc = run_cmd("ss -tlnp 2>/dev/null | awk 'NR>1 {print $4}' | grep -oP '(?<=:)\\d+' | sort -un", timeout=6)
    results = []
    if rc != 0: return results
    known_ports = {s[2] for s in SERVICES if s[2]}
    WK = {3000:("Grafana","/","home"), 3001:("Web App","/","home"), 5000:("Flask App","/","home"),
          8080:("Web UI","/","home"), 8443:("Secure Web","/","home"), 9000:("Portainer","/","system"),
          9090:("Prometheus","/","system"), 9100:("Node Exporter","/","system")}
    for line in out.strip().splitlines():
        try: port = int(line.strip())
        except: continue
        if port in known_ports or port < 1024: continue
        info = WK.get(port, (f"Service :{port}", "/", "home"))
        results.append({"port": port, "name": info[0], "description": f"Open port {port}",
                        "web_path": info[1], "category": info[2]})
    return results[:20]

def add_services_to_settings(servers_list):
    s = load_settings()
    added = []
    for srv in servers_list:
        unit = str(srv.get("unit","")).strip().lower().replace(" ","-")
        if not unit: continue
        name = str(srv.get("name", unit)).strip()
        runtime = str(srv.get("runtime","docker")).strip()
        host    = str(srv.get("host","localhost")).strip()
        cat     = str(srv.get("category","home")).strip()
        desc    = str(srv.get("description","")).strip()
        wp      = str(srv.get("web_path","")) if srv.get("web_path") is not None else ""
        dc      = str(srv.get("docker_container", unit)).strip() if runtime == "docker" else unit
        port    = None
        try: port = int(srv["port"]) if srv.get("port") else None
        except: pass
        entry = {
            "display_name": name, "unit": unit,
            "runtime": runtime, "host": host, "docker_container": dc,
            "volume_maps": list(srv.get("volume_maps", [])),
            "port": port, "web_path": wp, "category": cat, "description": desc,
            "config_files": [], "data_paths": [],
        }
        s["services"][unit] = entry
        added.append(unit)
    if added:
        ok, msg = save_settings(s)
        if not ok: return []
    return added

def bootstrap_settings(mode):
    """Reset settings.json. mode='embedded' rebuilds from SERVICES; mode='blank' starts empty."""
    if mode == "blank":
        s = {"schema_version": SETTINGS_SCHEMA_VERSION,
             "dashboard": {"viewer_host": "auto", "viewer_scheme": "http",
                           "hide_stopped_services": False, "protect_dashboard_service": True,
                           "hidden_units": []},
             "services": {},
             "auto_detect": {"enabled": False, "write_back_missing": False},
             "bootstrap": {"mode": "blank", "scan_paths": ["/opt/appdata:/config", "/opt/app:/app"]}}
    else:
        s = default_settings()
        s["bootstrap"]["mode"] = "embedded"
    tmp = SETTINGS_PATH + ".tmp"
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(tmp, "w") as f: json.dump(s, f, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True, f"Settings reset to [{mode}] mode"
    except Exception as e:
        return False, str(e)



def get_system_info():
    info = {}
    info["hostname"], _ = run_cmd("hostname")
    ip_out, _ = run_cmd("hostname -I")
    info["ip"] = ip_out.split()[0] if ip_out else "unknown"

    uptime_raw, _ = run_cmd("cat /proc/uptime")
    if uptime_raw:
        secs = float(uptime_raw.split()[0])
        d, h, m = int(secs // 86400), int((secs % 86400) // 3600), int((secs % 3600) // 60)
        info["uptime"] = f"{d}d {h}h {m}m"

    load_out, _ = run_cmd("cat /proc/loadavg")
    if load_out:
        p = load_out.split()
        info["load"] = f"{p[0]} / {p[1]} / {p[2]}"

    temp, _ = run_cmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null")
    if temp:
        try: info["cpu_temp"] = round(int(temp) / 1000, 1)
        except: pass

    mem_out, _ = run_cmd("free -b")
    if mem_out:
        lines = mem_out.split("\n")
        mp = lines[1].split()
        info["mem_total"] = int(mp[1])
        info["mem_used"] = int(mp[2])
        info["mem_available"] = int(mp[6]) if len(mp) > 6 else int(mp[1]) - int(mp[2])
        sp = lines[2].split()
        info["swap_total"] = int(sp[1])
        info["swap_used"] = int(sp[2])

    disk_out, _ = run_cmd("df -B1 /")
    if disk_out:
        dp = disk_out.split("\n")[1].split()
        info["disk_total"] = int(dp[1])
        info["disk_used"] = int(dp[2])
        info["disk_avail"] = int(dp[3])

    info["os"], _ = run_cmd("cat /etc/os-release | grep PRETTY_NAME | cut -d'\"' -f2")
    info["kernel"], _ = run_cmd("uname -r")
    return info


def get_service_data(settings=None):
    if settings is None:
        settings = load_settings()
    svc_map   = (settings or {}).get("services", {}) if isinstance(settings, dict) else {}
    bootstrap = (settings or {}).get("bootstrap", {}) if isinstance(settings, dict) else {}
    mode      = str(bootstrap.get("mode", "embedded")).strip()

    services = []

    if mode == "embedded":
        # Seed from the hardcoded SERVICES list, applying any saved overrides
        seen = set()
        for name, unit, port, cat, desc, web_path, configs in SERVICES:
            seen.add(unit)
            ov       = svc_map.get(unit, {}) if isinstance(svc_map, dict) else {}
            runtime  = str(ov.get("runtime", "docker"))
            host     = str(ov.get("host", "localhost"))
            eff_port = ov.get("port", port)
            eff_wp   = ov.get("web_path", web_path)
            eff_cfg  = ov.get("config_files", configs)
            eff_dp   = ov.get("data_paths", [])
            eff_vm   = ov.get("volume_maps", [])
            status   = get_service_status(unit, runtime)
            mem      = get_service_memory(unit, runtime)
            cpu      = get_service_cpu(unit, runtime)
            svc = {"name": name, "unit": unit, "port": eff_port, "category": ov.get("category", cat) if isinstance(ov, dict) else cat,
                   "description": desc, "status": status,
                   "memory_mb": round(mem,1) if mem else None,
                   "cpu_pct": round(cpu,1) if cpu else None,
                   "web_path": eff_wp, "config_files": eff_cfg,
                   "data_paths": eff_dp, "volume_maps": eff_vm,
                   "runtime": runtime, "host": host, "url_mode": (ov.get("url_mode") if isinstance(ov, dict) else None), "scheme": (ov.get("scheme") if isinstance(ov, dict) else None), "domain": (ov.get("domain") if isinstance(ov, dict) else None), "url_override": (ov.get("url_override") if isinstance(ov, dict) else None)}
            if unit == "kiwix" and isinstance(ov, dict):
                if "kiwix_zim_dir" in ov:    svc["kiwix_zim_dir"] = ov["kiwix_zim_dir"]
                if "kiwix_library_xml" in ov: svc["kiwix_library_xml"] = ov["kiwix_library_xml"]
            services.append(svc)

        # Also include any dynamically-added services saved in settings
        for unit, ov in svc_map.items():
            if unit in seen or not isinstance(ov, dict): continue
            runtime = str(ov.get("runtime","docker"))
            host    = str(ov.get("host","localhost"))
            status  = get_service_status(unit, runtime)
            mem     = get_service_memory(unit, runtime)
            cpu     = get_service_cpu(unit, runtime)
            services.append({
                "name":         ov.get("display_name", unit),
                "unit":         unit,
                "port":         ov.get("port"),
                "category":     ov.get("category","home"),
                "description":  ov.get("description",""),
                "status":       status,
                "memory_mb":    round(mem,1) if mem else None,
                "cpu_pct":      round(cpu,1) if cpu else None,
                "web_path":     ov.get("web_path",""),
                "config_files": ov.get("config_files",[]),
                "data_paths":   ov.get("data_paths",[]),
                "volume_maps":  ov.get("volume_maps",[]),
                "runtime":      runtime,
                "host":         host,
                "url_mode":     ov.get("url_mode"),
                "scheme":       ov.get("scheme"),
                "domain":       ov.get("domain"),
                "url_override": ov.get("url_override"),
            })
    else:
        # Blank mode: ONLY render what is explicitly saved in settings — never touch SERVICES
        for unit, ov in svc_map.items():
            if not isinstance(ov, dict): continue
            runtime = str(ov.get("runtime","docker"))
            host    = str(ov.get("host","localhost"))
            status  = get_service_status(unit, runtime)
            mem     = get_service_memory(unit, runtime)
            cpu     = get_service_cpu(unit, runtime)
            services.append({
                "name":         ov.get("display_name", unit),
                "unit":         unit,
                "port":         ov.get("port"),
                "category":     ov.get("category","home"),
                "description":  ov.get("description",""),
                "status":       status,
                "memory_mb":    round(mem,1) if mem else None,
                "cpu_pct":      round(cpu,1) if cpu else None,
                "web_path":     ov.get("web_path",""),
                "config_files": ov.get("config_files",[]),
                "data_paths":   ov.get("data_paths",[]),
                "volume_maps":  ov.get("volume_maps",[]),
                "runtime":      runtime,
                "host":         host,
            })

    return services


def is_path_allowed(filepath):
    filepath = os.path.realpath(filepath)
    return any(filepath.startswith(p) for p in ALLOWED_EDIT_PATHS)


def read_config_file(filepath):
    filepath = os.path.realpath(filepath)
    if not is_path_allowed(filepath):
        return None, "Path not allowed"
    if not os.path.isfile(filepath):
        return None, "File not found"
    try:
        with open(filepath, 'r') as f:
            return f.read(), None
    except PermissionError:
        out, rc = run_cmd(f"sudo cat '{filepath}'")
        if rc == 0:
            return out, None
        return None, "Permission denied"


def write_config_file(filepath, content):
    filepath = os.path.realpath(filepath)
    if not is_path_allowed(filepath):
        return False, "Path not allowed"
    run_cmd(f"sudo cp '{filepath}' '{filepath}.bak.$(date +%Y%m%d%H%M%S)' 2>/dev/null")
    try:
        with open(filepath, 'w') as f:
            f.write(content)
        return True, "Saved"
    except PermissionError:
        import tempfile
        tmp = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.tmp')
        tmp.write(content)
        tmp.close()
        _, rc = run_cmd(f"sudo cp '{tmp.name}' '{filepath}'")
        os.unlink(tmp.name)
        if rc == 0:
            return True, "Saved (via sudo)"
        return False, "Permission denied"


def browse_directory(path, show_files=True):
    """List contents of a directory for the file browser."""
    try:
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            return None, "Not a directory"
        
        items = []
        # Add parent directory option
        parent = os.path.dirname(path)
        if parent and parent != path:
            items.append({"name": "..", "path": parent, "type": "dir"})
        
        for name in sorted(os.listdir(path)):
            if name.startswith('.'):
                continue
            full_path = os.path.join(path, name)
            try:
                if os.path.isdir(full_path):
                    items.append({"name": name + "/", "path": full_path, "type": "dir"})
                elif show_files and os.path.isfile(full_path):
                    ext = name.lower().split('.')[-1] if '.' in name else ''
                    if ext in ('conf', 'ini', 'toml', 'xml', 'yaml', 'yml', 'json',
                               'cfg', 'config', 'py', 'sh', 'service',
                               'db', 'sqlite', 'sqlite3', 'env', 'properties'):
                        items.append({"name": name, "path": full_path, "type": "file"})
            except PermissionError:
                continue
        
        return {"path": path, "items": items}, None
    except Exception as e:
        return None, str(e)


def refresh_kiwix_library():
    """Rebuild Kiwix library.xml from the dashboard settings and restart Kiwix."""
    s = load_settings()
    svc = (s.get("services", {}) or {}).get("kiwix", {})
    zim_dir = str(svc.get("kiwix_zim_dir", "/opt/appdata/kiwix/data/zims")).strip()
    lib_xml = str(svc.get("kiwix_library_xml", "/opt/appdata/kiwix/data/library.xml")).strip()

    if not zim_dir.startswith("/") or not lib_xml.startswith("/"):
        return False, "Kiwix paths must be absolute in Settings", ""

    try:
        os.makedirs(zim_dir, exist_ok=True)
        os.makedirs(os.path.dirname(lib_xml), exist_ok=True)
    except Exception as e:
        return False, f"Unable to create directories: {e}", ""

    zims = []
    try:
        for fn in sorted(os.listdir(zim_dir)):
            low = fn.lower()
            if low.endswith(".zim") or low.endswith(".zimaa"):
                p = os.path.join(zim_dir, fn)
                if os.path.isfile(p):
                    zims.append(p)
    except Exception as e:
        return False, f"Unable to scan ZIM directory: {e}", ""

    if not zims:
        return False, f"No ZIM files found in {zim_dir}", ""

    if shutil.which("kiwix-manage") is None:
        script = "/usr/local/bin/kiwix-refresh-library.sh"
        if os.path.exists(script):
            out, rc = run_cmd(f"sudo {script}", timeout=180)
            if rc == 0:
                return True, "Kiwix library refreshed (script)", out or ""
            return False, "Kiwix refresh failed (script)", out or ""
        return False, "kiwix-manage not found and helper script missing", ""

    try:
        if os.path.exists(lib_xml):
            os.remove(lib_xml)
    except Exception:
        pass

    details = []
    for f in zims:
        p = subprocess.run(
            ["kiwix-manage", lib_xml, "add", f],
            capture_output=True, text=True
        )
        if p.returncode != 0:
            err = (p.stderr or p.stdout or "").strip()
            return False, f"kiwix-manage failed adding {os.path.basename(f)}", err
        details.append(f"Added: {os.path.basename(f)}")

    out, rc = run_cmd(f"docker restart kiwix 2>/dev/null || true", timeout=20)
    msg = f"Kiwix library refreshed · {len(zims)} file(s)"
    return True, msg, "\n".join(details) + ("\n" + out if out else "")



def read_app_version():
    """Read version.json next to this script (best-effort)."""
    try:
        here = os.path.dirname(os.path.realpath(__file__))
        vp = os.path.join(here, "version.json")
        if os.path.isfile(vp):
            with open(vp, "r", encoding="utf-8") as f:
                v = json.load(f)
            if isinstance(v, dict):
                return {
                    "version": str(v.get("version", "")).strip(),
                    "release_date": str(v.get("release_date", "")).strip(),
                    "codename": str(v.get("codename", "")).strip(),
                }
    except Exception:
        pass
    return {"version": "", "release_date": "", "codename": ""}


def build_api_response():
    s = load_settings()
    categories = s.get("categories") if isinstance(s.get("categories"), dict) else CATEGORY_META
    return json.dumps({
        "app": read_app_version(),
        "system": get_system_info(),
        "services": get_service_data(s),
        "categories": categories,
        "settings": s,
        "system_files": SYSTEM_FILES,
        "scan_paths": s.get("bootstrap", {}).get("scan_paths", []),
        "timestamp": datetime.now().isoformat(),
    })


# ─────────────────────────────────────────────
# HTML
# ─────────────────────────────────────────────
HTML_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SidscriServer Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #0a0c10; --bg-card: #12151c; --bg-card-hover: #181c25;
  --bg-overlay: rgba(10,12,16,0.85); --bg-panel: #0f1118;
  --border: #1e2330; --border-glow: #2a3040;
  --text: #e2e8f0; --text2: #7a8599; --text3: #4a5568;
  --green: #22c55e; --green-d: rgba(34,197,94,0.12);
  --red: #ef4444; --red-d: rgba(239,68,68,0.12);
  --amber: #f59e0b; --amber-d: rgba(245,158,11,0.12);
  --blue: #3b82f6; --blue-d: rgba(59,130,246,0.12);
  --purple: #a855f7; --purple-d: rgba(168,85,247,0.12);
  --cyan: #06b6d4; --cyan-d: rgba(6,182,212,0.12);
  --font: 'Outfit', sans-serif; --mono: 'JetBrains Mono', monospace;
  --radius: 10px;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg); color:var(--text); font-family:var(--font); min-height:100vh; }
body.modal-open { overflow:hidden; }
body::before { content:''; position:fixed; inset:0; background-image:
  linear-gradient(rgba(30,35,48,0.3) 1px,transparent 1px),
  linear-gradient(90deg,rgba(30,35,48,0.3) 1px,transparent 1px);
  background-size:60px 60px; z-index:0; pointer-events:none; }
.container { position:relative; z-index:1; max-width:1440px; margin:0 auto; padding:20px 24px; }

/* Header */
.header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:1px solid var(--border); }
.header-left { display:flex; align-items:center; gap:14px; }
.logo { width:42px; height:42px; border-radius:12px; background:linear-gradient(135deg,var(--blue),var(--purple));
  display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:700; color:white;
  box-shadow:0 4px 20px rgba(59,130,246,0.25); }
.header h1 { font-size:21px; font-weight:700; letter-spacing:-0.5px; }
.header h1 span { color:var(--blue); }
.appver { font-family:var(--mono); font-size:12px; color:var(--text2); font-weight:600; margin-left:8px; }
.header-right { display:flex; align-items:center; gap:16px; font-family:var(--mono); font-size:12px; color:var(--text2); }
.pulse-dot { width:8px; height:8px; border-radius:50%; background:var(--green); animation:pulse 2s ease-in-out infinite; display:inline-block; margin-right:5px; }
@keyframes pulse { 0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(34,197,94,0.4)} 50%{opacity:0.7;box-shadow:0 0 0 6px rgba(34,197,94,0)} }

/* Nav Tabs */
.nav { display:flex; gap:4px; margin-bottom:20px; background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:4px; width:fit-content; }
.nav-btn { padding:8px 18px; border-radius:8px; border:none; background:transparent; color:var(--text2);
  font-family:var(--font); font-size:13px; font-weight:600; cursor:pointer; transition:all 0.2s; }
.nav-btn:hover { color:var(--text); background:var(--bg-card-hover); }
.nav-btn.active { background:var(--blue-d); color:var(--blue); }
.tab-content { display:none; }
.tab-content.active { display:block; }

/* System Bar */
.sys-bar { display:grid; grid-template-columns:repeat(auto-fit,minmax(195px,1fr)); gap:10px; margin-bottom:24px; }
.sys-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:14px 16px; transition:border-color 0.2s; }
.sys-card:hover { border-color:var(--border-glow); }
.sys-lbl { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:var(--text3); font-weight:600; margin-bottom:4px; font-family:var(--mono); }
.sys-val { font-size:19px; font-weight:700; letter-spacing:-0.5px; }
.sys-sub { font-size:10px; color:var(--text2); margin-top:3px; font-family:var(--mono); }
.pbar { height:4px; background:var(--border); border-radius:2px; margin-top:6px; overflow:hidden; }
.pfill { height:100%; border-radius:2px; transition:width 0.6s; }
.fg { background:var(--green); } .fa { background:var(--amber); } .fr { background:var(--red); }

/* Category */
.category { margin-bottom:20px; }
.cat-hdr { display:flex; align-items:center; gap:10px; margin-bottom:10px; padding-left:2px; }
.cat-icon { font-size:15px; }
.cat-title { font-size:13px; font-weight:600; text-transform:uppercase; letter-spacing:1.5px; color:var(--text2); }
.cat-count { font-family:var(--mono); font-size:10px; color:var(--text3); background:var(--bg-card); padding:2px 7px; border-radius:10px; border:1px solid var(--border); }

/* Service Row */
.sgrid { display:grid; grid-template-columns:repeat(auto-fill,minmax(520px,1fr)); gap:10px; }
.svc { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:12px 14px;
  display:flex; align-items:flex-start; gap:10px; transition:all 0.15s; position:relative; overflow:hidden; min-height:72px; }
.svc::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; border-radius:3px 0 0 3px; }
.svc.on::before { background:var(--green); } .svc.off::before { background:var(--red); } .svc.unk::before { background:var(--amber); }
.svc:hover { border-color:var(--border-glow); background:var(--bg-card-hover); }
.sdot { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
.svc.on .sdot { background:var(--green); box-shadow:0 0 8px rgba(34,197,94,0.5); }
.svc.off .sdot { background:var(--red); box-shadow:0 0 8px rgba(239,68,68,0.5); }
.svc.unk .sdot { background:var(--amber); }
.sinfo { flex:1; min-width:0; }
.sname { font-size:13px; font-weight:600; white-space:normal; overflow:hidden; text-overflow:ellipsis; line-height:1.2; word-break:break-word; }
.sdesc { font-size:10px; color:var(--text2); margin-top:1px; }
.smeta { display:flex; align-items:center; gap:6px; flex-shrink:0; font-family:var(--mono); font-size:10px; flex-wrap:wrap; justify-content:flex-end; }
.sport { color:var(--cyan); background:var(--cyan-d); padding:2px 7px; border-radius:6px; font-weight:500; }
.sport a { color:var(--cyan); text-decoration:none; } .sport a:hover { text-decoration:underline; }
.smem { color:var(--purple); } .scpu { color:var(--amber); }

/* Control Buttons */
.sctrl { display:flex; gap:3px; flex-shrink:0; }
.cbtn { width:26px; height:26px; border-radius:6px; border:1px solid var(--border); background:var(--bg-card);
  color:var(--text2); cursor:pointer; display:flex; align-items:center; justify-content:center;
  font-size:12px; transition:all 0.15s; }
.cbtn:hover { border-color:var(--border-glow); background:var(--bg-card-hover); }
.cbtn.start:hover { color:var(--green); border-color:var(--green); background:var(--green-d); }
.cbtn.stop:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.cbtn.restart:hover { color:var(--amber); border-color:var(--amber); background:var(--amber-d); }
.cbtn.view:hover { color:var(--blue); border-color:var(--blue); background:var(--blue-d); }
.cbtn.edit:hover { color:var(--purple); border-color:var(--purple); background:var(--purple-d); }
.cbtn.kiwix:hover { color:var(--cyan); border-color:var(--cyan); background:var(--cyan-d); }
.cbtn.spinning svg { animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* Viewer Panel */
.viewer-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:100; backdrop-filter:blur(4px); }
.viewer-overlay.open { display:flex; align-items:stretch; justify-content:center; padding:20px; }
.viewer-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px; width:100%; max-width:1300px;
  display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5);
  height:100%; max-height:calc(100vh - 40px); min-height:0; }
.viewer-bar { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border);
  background:var(--bg-card); flex-shrink:0; }
.viewer-title { font-weight:600; font-size:15px; }
.viewer-url { font-family:var(--mono); font-size:11px; color:var(--text2); background:var(--bg); padding:4px 10px;
  border-radius:6px; border:1px solid var(--border); margin:0 12px; flex:1; text-align:center; }
.viewer-close { width:32px; height:32px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card);
  color:var(--text2); cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:16px; transition:all 0.15s; }
.viewer-close:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.viewer-frame { flex:1; border:none; background:#000; width:100%; min-height:0; }

/* Editor Panel */
.editor-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:100; backdrop-filter:blur(4px); }
.editor-overlay.open { display:flex; align-items:stretch; justify-content:center; padding:20px; }
.editor-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px; width:100%; max-width:900px;
  display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5);
  height:100%; max-height:calc(100vh - 40px); min-height:0; }
.editor-bar { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border);
  background:var(--bg-card); flex-shrink:0; gap:8px; }
.editor-title { font-weight:600; font-size:14px; flex-shrink:0; }
.editor-path { font-family:var(--mono); font-size:11px; color:var(--cyan); flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.editor-btns { display:flex; gap:6px; flex-shrink:0; }
.ebtn { padding:6px 14px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card);
  color:var(--text2); cursor:pointer; font-family:var(--font); font-size:12px; font-weight:600; transition:all 0.15s; }
.ebtn:hover { border-color:var(--border-glow); }
.ebtn.save { color:var(--green); } .ebtn.save:hover { border-color:var(--green); background:var(--green-d); }
.ebtn.close { color:var(--text2); } .ebtn.close:hover { color:var(--red); border-color:var(--red); background:var(--red-d); }
.ebtn.back { color:var(--blue); } .ebtn.back:hover { border-color:var(--blue); background:var(--blue-d); }
.editor-select { display:flex; gap:4px; padding:8px 18px; border-bottom:1px solid var(--border); background:var(--bg); flex-wrap:wrap; align-items:center; }
.file-tab { padding:4px 10px; border-radius:6px; border:1px solid var(--border); background:var(--bg-card); color:var(--text2);
  font-family:var(--mono); font-size:11px; cursor:pointer; transition:all 0.15s; }
.file-tab:hover { border-color:var(--border-glow); color:var(--text); }
.file-tab.active { border-color:var(--cyan); color:var(--cyan); background:var(--cyan-d); }
.file-tab.browse { border-color:var(--purple); color:var(--purple); }
.file-tab.browse:hover { background:var(--purple-d); }
.editor-area { flex:1; display:flex; }
.editor-area textarea { flex:1; background:var(--bg); color:var(--text); border:none; padding:16px 20px;
  font-family:var(--mono); font-size:12px; line-height:1.6; resize:none; outline:none; tab-size:4; }
.editor-status { padding:8px 18px; border-top:1px solid var(--border); font-family:var(--mono); font-size:11px; color:var(--text3);
  display:flex; justify-content:space-between; background:var(--bg-card); }
.editor-status .saved { color:var(--green); }
.editor-status .error { color:var(--red); }

/* File Browser */
.browser-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:150; backdrop-filter:blur(4px); }
.browser-overlay.open { display:flex; align-items:center; justify-content:center; padding:20px; }
.browser-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px; width:100%; max-width:600px;
  max-height:calc(100vh - 40px); display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5); min-height:0; }
.browser-bar { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; border-bottom:1px solid var(--border);
  background:var(--bg-card); flex-shrink:0; }
.browser-title { font-weight:600; font-size:14px; }
.browser-path { font-family:var(--mono); font-size:11px; color:var(--cyan); padding:8px 18px; border-bottom:1px solid var(--border); 
  background:var(--bg); word-break:break-all; }
.browser-list { flex:1; overflow-y:auto; padding:8px; }
.browser-item { padding:8px 12px; border-radius:6px; cursor:pointer; display:flex; align-items:center; gap:8px;
  font-family:var(--mono); font-size:12px; transition:all 0.15s; }
.browser-item:hover { background:var(--bg-card-hover); }
.browser-item.dir { color:var(--blue); }
.browser-item.file { color:var(--text); }
.browser-item.file:hover { background:var(--cyan-d); color:var(--cyan); }
.browser-actions { display:flex; gap:8px; padding:12px 18px; border-top:1px solid var(--border); background:var(--bg-card); }
.browser-input { flex:1; padding:8px 12px; border-radius:6px; border:1px solid var(--border); background:var(--bg);
  color:var(--text); font-family:var(--mono); font-size:12px; }

/* Toast */
.toast { position:fixed; bottom:24px; right:24px; z-index:200; display:flex; flex-direction:column; gap:6px; }
.toast-msg { padding:10px 16px; border-radius:8px; font-size:13px; font-weight:500; animation:slideIn 0.3s ease;
  border:1px solid var(--border); background:var(--bg-card); color:var(--text); box-shadow:0 8px 30px rgba(0,0,0,0.3); }
.toast-msg.ok { border-color:var(--green); color:var(--green); }
.toast-msg.err { border-color:var(--red); color:var(--red); }
@keyframes slideIn { from{transform:translateX(30px);opacity:0} to{transform:translateX(0);opacity:1} }

/* Footer */
.footer { margin-top:24px; padding-top:14px; border-top:1px solid var(--border); display:flex; justify-content:space-between;
  font-family:var(--mono); font-size:11px; color:var(--text3); }

/* Journal Tab */
.journal-wrap { display:flex; gap:12px; }
.journal-list { width:220px; flex-shrink:0; display:flex; flex-direction:column; gap:4px; max-height:70vh; overflow-y:auto; }
.jbtn { padding:8px 12px; border-radius:8px; border:1px solid var(--border); background:var(--bg-card); color:var(--text2);
  font-size:12px; cursor:pointer; text-align:left; transition:all 0.15s; font-family:var(--font); }
.jbtn:hover { border-color:var(--border-glow); color:var(--text); }
.jbtn.active { border-color:var(--blue); color:var(--blue); background:var(--blue-d); }
.journal-output { flex:1; background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius);
  padding:14px; font-family:var(--mono); font-size:11px; line-height:1.5; color:var(--text2);
  max-height:70vh; overflow-y:auto; white-space:pre-wrap; word-break:break-all; }

@media (max-width:768px) {
  .container { padding:14px; }
  .sys-bar { grid-template-columns:repeat(2,1fr); }
  .sgrid { grid-template-columns:1fr; }
  .header { flex-direction:column; align-items:flex-start; gap:10px; }
  .journal-wrap { flex-direction:column; }
  .journal-list { width:100%; max-height:200px; flex-direction:row; flex-wrap:wrap; }
  /* Modal panels on small screens */
  .viewer-overlay.open, .editor-overlay.open, .browser-overlay.open { padding:8px; }
  .viewer-panel, .editor-panel, .browser-panel { max-height:calc(100vh - 16px); width:100%; max-width:100%; border-radius:12px; }
  .viewer-bar { flex-wrap:wrap; gap:8px; }
  .viewer-url { flex-basis:100%; margin:0; order:3; }

}

/* Settings */
.settings-wrap { display:flex; gap:16px; flex-wrap:wrap; margin-top:8px; }
.settings-card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius);
  padding:16px; min-width:320px; flex:1; }
.settings-title { font-weight:800; letter-spacing:0.2px; margin-bottom:10px; }
.settings-row { margin-bottom:12px; }
.settings-row label { display:block; font-size:12px; color:var(--text2); margin-bottom:6px; }
.settings-input { width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--border);
  background:var(--bg-panel); color:var(--text); font-family:var(--mono); font-size:12px; outline:none; }
.settings-input:focus { border-color:var(--border-glow); }
.settings-textarea { width:100%; padding:10px 12px; border-radius:10px; border:1px solid var(--border);
  background:var(--bg-panel); color:var(--text); font-family:var(--mono); font-size:12px; outline:none;
  min-height:96px; resize:vertical; }
.settings-textarea:focus { border-color:var(--border-glow); }
.settings-hint { font-size:12px; color:var(--text2); line-height:1.35; }
.settings-actions { display:flex; gap:10px; margin-top:10px; }

/* System Files Panel */
.sysfiles-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:6px; margin-top:4px; }
.sysfile-btn { display:flex; align-items:center; gap:8px; padding:9px 12px; border-radius:8px;
  border:1px solid var(--border); background:var(--bg-panel); color:var(--text2);
  font-family:var(--mono); font-size:11px; cursor:pointer; transition:all 0.15s; text-align:left; width:100%; }
.sysfile-btn:hover { border-color:var(--purple); color:var(--purple); background:var(--purple-d); }
.sysfile-btn .sysfile-icon { font-size:13px; flex-shrink:0; }
.sysfile-btn .sysfile-label { font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.sysfile-btn .sysfile-path { font-size:9px; color:var(--text3); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; display:block; }
.sysfiles-browse-row { margin-top:10px; display:flex; gap:8px; align-items:center; }

/* Accordion */
.accordion-hdr { display:flex; align-items:center; justify-content:space-between; cursor:pointer;
  padding:8px 0; border-bottom:1px solid var(--border); user-select:none; }
.accordion-hdr:hover .acc-title { color:var(--text); }
.acc-title { font-weight:800; letter-spacing:0.2px; color:var(--text2); transition:color 0.15s; font-size:14px; }
.acc-arrow { font-size:11px; color:var(--text3); transition:transform 0.2s; }
.accordion-hdr.open .acc-arrow { transform:rotate(180deg); }
.accordion-body { display:none; padding-top:12px; }
.accordion-body.open { display:block; }

/* Runtime badges */
.rt-badge { font-size:9px; font-weight:700; text-transform:uppercase; padding:2px 6px; border-radius:4px; font-family:var(--mono); }
.rt-docker   { background:var(--cyan-d);   color:var(--cyan); }
.rt-systemd  { background:var(--green-d);  color:var(--green); }
.rt-external { background:var(--purple-d); color:var(--purple); }

/* ebtn variants */
.ebtn.primary { color:var(--blue);  border-color:var(--blue);  background:var(--blue-d); }
.ebtn.primary:hover { background:rgba(59,130,246,0.22); }
.ebtn.danger  { color:var(--red);   border-color:var(--red);   background:var(--red-d); }
.ebtn.danger:hover  { background:rgba(239,68,68,0.22); }

/* Wizard overlay */
.wizard-overlay { display:none; position:fixed; inset:0; background:var(--bg-overlay); z-index:100;
  backdrop-filter:blur(4px); align-items:center; justify-content:center; padding:20px; }
.wizard-overlay.open { display:flex; }
.wizard-panel { background:var(--bg-panel); border:1px solid var(--border); border-radius:14px;
  width:100%; max-width:640px; max-height:calc(100vh - 40px); display:flex; flex-direction:column;
  overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.5); }
.wizard-bar { display:flex; align-items:center; justify-content:space-between; padding:14px 18px;
  border-bottom:1px solid var(--border); background:var(--bg-card); flex-shrink:0; }
.wizard-title { font-weight:700; font-size:15px; }
.wizard-body { flex:1; overflow-y:auto; padding:18px; min-height:0; }
.wizard-footer { display:flex; gap:8px; justify-content:flex-end; padding:12px 18px;
  border-top:1px solid var(--border); background:var(--bg-card); flex-shrink:0; }
.wiz-tabs { display:flex; gap:4px; margin-bottom:16px; }
.wiz-tab { padding:7px 14px; border-radius:8px; border:1px solid var(--border);
  background:var(--bg-card); color:var(--text2); font-size:12px; font-weight:600; cursor:pointer; transition:all 0.15s; }
.wiz-tab:hover { border-color:var(--border-glow); color:var(--text); }
.wiz-tab.svc.active  { border-color:var(--green);  color:var(--green);  background:var(--green-d); }
.wiz-tab.dkr.active  { border-color:var(--cyan);   color:var(--cyan);   background:var(--cyan-d); }
.wiz-tab.ext.active  { border-color:var(--purple); color:var(--purple); background:var(--purple-d); }
.wiz-panel { display:none; } .wiz-panel.active { display:block; }
.wiz-field { margin-bottom:12px; }
.wiz-field label { display:block; font-size:11px; color:var(--text2); margin-bottom:5px;
  font-weight:600; text-transform:uppercase; letter-spacing:0.5px; }
.wiz-input { width:100%; padding:9px 12px; border-radius:8px; border:1px solid var(--border);
  background:var(--bg); color:var(--text); font-family:var(--mono); font-size:12px; outline:none; }
.wiz-input:focus { border-color:var(--border-glow); }
.wiz-row { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.wiz-hint { font-size:11px; color:var(--text3); margin-top:4px; }
/* Scan results */
.scan-section { margin-bottom:14px; }
.scan-section-title { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1px;
  color:var(--text2); padding:6px 0; border-bottom:1px solid var(--border); margin-bottom:6px; }
.scan-item { display:grid; grid-template-columns:20px minmax(0,1fr) minmax(150px,330px) auto; align-items:center; gap:10px; padding:10px 12px; border-radius:8px;
  border:1px solid var(--border); background:var(--bg-card); cursor:pointer; transition:all 0.15s; margin-bottom:6px; }
.scan-item:hover { border-color:var(--border-glow); background:var(--bg-card-hover); }
.scan-item.sel { border-color:var(--blue); background:var(--blue-d); }
.scan-check { width:16px; height:16px; border-radius:4px; border:1px solid var(--border);
  display:flex; align-items:center; justify-content:center; font-size:11px; color:transparent; flex-shrink:0; }
.scan-item.sel .scan-check { border-color:var(--blue); color:var(--blue); }
.scan-item-info { min-width:0; }
.scan-item-name { font-size:12px; font-weight:600; line-height:1.2; word-break:break-word; }
.scan-item-sub  { font-size:10px; color:var(--text2); font-family:var(--mono); white-space:normal; overflow-wrap:anywhere; line-height:1.35; margin-top:2px; }
.scan-badge { font-size:9px; font-weight:700; text-transform:uppercase; padding:2px 6px; border-radius:4px; flex-shrink:0; }
.scan-badge.docker  { background:var(--cyan-d);  color:var(--cyan); }
.scan-badge.systemd { background:var(--green-d); color:var(--green); }
.scan-badge.port    { background:var(--amber-d); color:var(--amber); }
.scan-empty { color:var(--text2); font-size:13px; padding:20px; text-align:center; }
.scan-cat-sel { background:var(--bg); border:1px solid var(--border); border-radius:6px;
  color:var(--text2); cursor:pointer; font-size:10px; width:100%; max-width:330px; min-width:150px; }
.scan-cat-sel:focus { outline:none; border-color:var(--border-glow); }
.scan-item.sel .scan-cat-sel { border-color:var(--blue); }
@media (max-width:768px) {
  .scan-item { grid-template-columns:20px minmax(0,1fr); }
  .scan-cat-sel { grid-column:2; max-width:none; }
  .scan-badge { justify-self:start; grid-column:2; }
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="header-left"><div class="logo">S</div><h1>Sidscri<span>Server</span> <span id="appver" class="appver"></span></h1></div>
    <div class="header-right"><span><span class="pulse-dot"></span>LIVE</span><span id="clock"></span><span id="rtimer">30s</span></div>
  </div>
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
    <div class="nav">
      <button class="nav-btn active" data-tab="dashboard" onclick="switchTab('dashboard', this)">Dashboard</button>
      <button class="nav-btn" data-tab="logs" onclick="switchTab('logs', this)">Logs</button>
      <button class="nav-btn" data-tab="settings" onclick="switchTab('settings', this)">Settings</button>
    </div>
    <button class="ebtn primary" style="font-size:12px;padding:7px 14px;" onclick="openWizard('scan')">＋ Add Service</button>
  </div>

  <div id="tab-dashboard" class="tab-content active">
    <div class="sys-bar" id="sys-bar"></div>
    <div id="svc-container"></div>
  </div>

  <div id="tab-logs" class="tab-content">
    <div class="journal-wrap">
      <div class="journal-list" id="jlist"></div>
      <pre class="journal-output" id="jout">Select a service to view its logs.</pre>
    </div>
  </div>

  <div id="tab-settings" class="tab-content">
    <div class="settings-wrap">

      <!-- Dashboard Viewer card -->
      <div class="settings-card">
        <div class="settings-title">Dashboard Viewer</div>
        <div class="settings-row">
          <label for="set_viewer_scheme">Viewer scheme</label>
          <select id="set_viewer_scheme" class="settings-input">
            <option value="http">http</option>
            <option value="https">https</option>
          </select>
        </div>
        <div class="settings-row">
          <label for="set_viewer_host">Viewer host</label>
          <input id="set_viewer_host" class="settings-input" spellcheck="false" />
          <div class="settings-hint">Use <code>auto</code> to follow the dashboard address. Set an IP/hostname only if the service UI is hosted elsewhere.</div>
        </div>

        <div class="settings-divider"></div>
        <div class="settings-title" style="margin-top:10px;">Domain Defaults</div>

        <div class="settings-row">
          <label for="set_default_url_mode">Default URL mode</label>
          <select id="set_default_url_mode" class="settings-input">
            <option value="local">Local host/IP</option>
            <option value="domain">Domain</option>
          </select>
          <div class="settings-hint">Used when a service does not specify its own URL mode.</div>
        </div>

        <div class="settings-row">
          <label for="set_default_domain_suffix">Default domain suffix</label>
          <input id="set_default_domain_suffix" class="settings-input" spellcheck="false" placeholder="sidneyshelton.com" />
          <div class="settings-hint">Used when URL mode is <b>Domain</b> and the service doesn't specify a domain.</div>
        </div>

        <div class="settings-row">
          <label for="set_default_domain_pattern">Default domain pattern</label>
          <input id="set_default_domain_pattern" class="settings-input" spellcheck="false" placeholder="{unit}.{suffix}" />
          <div class="settings-hint">Template used to auto-build domains. Variables: <code>{unit}</code> and <code>{suffix}</code>.</div>
        </div>
        <div class="settings-actions">
          <button class="ebtn" onclick="loadSettings()">Reload</button>
          <button class="ebtn" onclick="saveAllSettings()">Save</button>
          <button class="ebtn" onclick="autoDetectAll()">Auto-detect all</button>
        </div>
      </div>

      <!-- Filters & Safety card -->
      <div class="settings-card">
        <div class="settings-title">Dashboard Filters &amp; Safety</div>
        <div class="settings-row">
          <label>Display</label>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2);">
              <input type="checkbox" id="set_hide_stopped" />
              Hide stopped services on the Dashboard
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2);">
              <input type="checkbox" id="set_protect_dashboard" />
              Protect Server Dashboard service (always block Stop for <code>server-dashboard</code>)
            </label>
          </div>
        </div>
        <div class="settings-row" style="display:none;">
          <label for="set_hidden_units">Hidden services (unit names, one per line)</label>
          <textarea id="set_hidden_units" class="settings-textarea" spellcheck="false" placeholder="e.g. deluge-web&#10;prowlarr"></textarea>
        </div>
        <div class="settings-row">
          <label>Hide / Unhide services</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <div>
              <label for="set_unhidden_pick" style="font-size:12px;color:var(--text2);margin-bottom:6px;display:block;">Visible (not hidden)</label>
              <select id="set_unhidden_pick" class="settings-input" multiple style="height:180px;"></select>
              <div class="settings-actions" style="margin-top:8px;">
                <button class="ebtn" onclick="hideSelectedUnits()">Hide →</button>
              </div>
            </div>
            <div>
              <label for="set_hidden_pick" style="font-size:12px;color:var(--text2);margin-bottom:6px;display:block;">Hidden</label>
              <select id="set_hidden_pick" class="settings-input" multiple style="height:180px;"></select>
              <div class="settings-actions" style="margin-top:8px;">
                <button class="ebtn" onclick="unhideSelectedUnits()">← Remove from Hidden</button>
                <button class="ebtn close" onclick="clearHiddenUnits()">Clear Hidden</button>
              </div>
            </div>
          </div>
          <div class="settings-hint" style="margin-top:8px;">
            Hidden services are dashboard-only. This does not stop Docker or systemd.
          </div>
        </div>
        <div class="settings-actions">
          <button class="ebtn" onclick="saveAllSettings()">Save</button>
        </div>
      </div>

      <!-- Service Mappings card -->
      <div class="settings-card" style="min-width:360px;flex:2;">
        <div class="settings-title">Service Mappings</div>

        <!-- Filter + Add -->
        <div class="settings-row" style="display:flex;gap:8px;align-items:flex-end;">
          <div style="flex:1;">
            <label for="svc_rt_filter">Filter by runtime</label>
            <select id="svc_rt_filter" class="settings-input" onchange="populateServicePicker()">
              <option value="">All</option>
              <option value="docker">docker</option>
              <option value="systemd">systemd</option>
              <option value="external">external</option>
            </select>
          </div>
          <button class="ebtn primary" style="font-size:11px;padding:8px 12px;white-space:nowrap;" onclick="openWizard('scan')">＋ Add Service</button>
        </div>

        <div class="settings-row">
          <label for="svc_pick">Select service</label>
          <select id="svc_pick" class="settings-input" onchange="onPickService()"></select>
          <div class="settings-hint">Showing <span id="svc_pick_count" style="color:var(--cyan);">0</span> services. Edit how the dashboard connects to and monitors this service.</div>
        </div>

        <!-- Runtime type -->
        <div class="settings-row">
          <label for="svc_runtime">Runtime type</label>
          <select id="svc_runtime" class="settings-input" onchange="onRuntimeChange()">
            <option value="docker">🐳 docker — managed via docker CLI</option>
            <option value="systemd">🐧 systemd — Linux service unit (non-Docker)</option>
            <option value="external">🌐 external — another machine (Windows VM, NAS, etc.)</option>
          </select>
          <div class="settings-hint">Controls how Start/Stop/Restart work and how the View URL is built.</div>
        </div>

        <!-- Docker-only: container name -->
        <div class="settings-row" id="svc_docker_row">
          <label for="svc_docker_container">Docker container name</label>
          <input id="svc_docker_container" class="settings-input" spellcheck="false" placeholder="Same as unit name if blank" />
          <div class="settings-hint">Only needed if the container name differs from the unit/service name.</div>
        </div>

        <!-- External/all: host -->
        <div class="settings-row" id="svc_host_row">
          <label for="svc_host">Host / IP address</label>
          <input id="svc_host" class="settings-input" spellcheck="false" placeholder="e.g. 192.168.0.50 or localhost" />
          <div class="settings-hint">For <b>external</b> enter the remote machine IP. For docker/systemd use <code>localhost</code> or the Pi's IP.</div>
        </div>

        <!-- Port + Web path -->
        <div class="settings-row">
          <div class="wiz-row" style="margin-bottom:0;">
            <div>
              <label for="svc_port">Port</label>
              <input id="svc_port" class="settings-input" spellcheck="false" placeholder="e.g. 8989" />
            </div>
            <div>
              <label for="svc_web_path">Web path</label>
              <input id="svc_web_path" class="settings-input" spellcheck="false" placeholder="/web or blank" />
            </div>
          </div>
        </div>

        <!-- URL controls -->
        <div class="settings-row">
          <div class="wiz-row" style="margin-bottom:0;">
            <div>
              <label for="svc_scheme">Scheme</label>
              <select id="svc_scheme" class="settings-input">
                <option value="">(Default)</option>
                <option value="http">http</option>
                <option value="https">https</option>
              </select>
              <div class="settings-hint">Use <b>https</b> for services like Calibre that require a secure connection.</div>
            </div>
            <div>
              <label for="svc_url_mode">URL mode</label>
              <select id="svc_url_mode" class="settings-input">
                <option value="">(Default)</option>
                <option value="local">Local host/IP</option>
                <option value="domain">Domain</option>
              </select>
              <div class="settings-hint">Choose whether this service opens via IP/host or a domain name.</div>
            </div>
          </div>
        </div>

        <div class="settings-row">
          <label for="svc_domain">Domain (optional)</label>
          <input id="svc_domain" class="settings-input" spellcheck="false" placeholder="e.g. calibre.sidneyshelton.com" />
          <div class="settings-hint">Used when URL mode is <b>Domain</b>. If blank, it will auto-build using the dashboard pattern.</div>
        </div>

        <div class="settings-row">
          <label for="svc_url_override">Full URL override (optional)</label>
          <input id="svc_url_override" class="settings-input" spellcheck="false" placeholder="e.g. https://calibre.sidneyshelton.com" />
          <div class="settings-hint">If set, the dashboard will open <b>exactly</b> this URL for View/Open.</div>
        </div>

        <div class="settings-row">
          <label for="svc_category">Service type (category)</label>
          <select id="svc_category" class="settings-input"></select>
          <div class="settings-hint">Changes which section and icon this service appears under.</div>
        </div>

        <!-- Mapped files (config_files) -->
        <div class="settings-row">
          <label for="svc_config_files">
            Mapped config/DB files <span style="color:var(--text3);font-weight:400;">(one per line — absolute host paths)</span>
          </label>
          <textarea id="svc_config_files" class="settings-textarea" spellcheck="false"
            placeholder="/opt/appdata/radarr-b/config/config.xml&#10;/opt/appdata/radarr-b/config/radarr.db&#10;/opt/appdata/tautulli/config/tautulli.db"></textarea>
          <div class="settings-hint">All config, settings, database (.db), and library files the service reads/writes. These appear as tabs in the Config Editor.</div>
          <div style="margin-top:6px;">
            <button class="ebtn" style="font-size:11px;" onclick="openBrowserForConfigFiles()">📁 Browse to add file…</button>
          </div>
        </div>

        <!-- Data/folder paths -->
        <div class="settings-row">
          <label for="svc_data_paths">Data folders <span style="color:var(--text3);font-weight:400;">(one per line)</span></label>
          <textarea id="svc_data_paths" class="settings-textarea" spellcheck="false"
            placeholder="/opt/appdata/radarr-b&#10;/opt/appdata/radarr-b/config"></textarea>
          <div class="settings-hint">Host directories the service owns. Used by auto-detect and future shortcuts.</div>
        </div>

        <!-- Volume maps (docker-only) -->
        <div class="settings-row" id="svc_volmap_row">
          <label for="svc_volume_maps">Volume maps <span style="color:var(--text3);font-weight:400;">(host_path:container_path, one per line)</span></label>
          <textarea id="svc_volume_maps" class="settings-textarea" spellcheck="false"
            placeholder="/opt/appdata/radarr-b/config:/config&#10;/opt/appdata/radarr-b/data:/data"></textarea>
          <div class="settings-hint">Populated automatically by Auto-detect (docker inspect). Override here if needed.</div>
        </div>

        <!-- Kiwix extras -->
        <div id="kiwix_extra" style="display:none;">
          <div class="settings-row">
            <label for="svc_kiwix_zim_dir">Kiwix ZIM directory</label>
            <input id="svc_kiwix_zim_dir" class="settings-input" spellcheck="false" />
          </div>
          <div class="settings-row">
            <label for="svc_kiwix_library_xml">Kiwix library.xml path</label>
            <input id="svc_kiwix_library_xml" class="settings-input" spellcheck="false" />
          </div>
        </div>

        <div class="settings-divider"></div>
        <div class="settings-title" style="margin-top:10px;">Bulk Edit</div>

        <div class="settings-row">
          <label>Apply to</label>
          <div class="wiz-row" style="margin-bottom:0;">
            <div>
              <label for="bulk_scope">Scope</label>
              <select id="bulk_scope" class="settings-input">
                <option value="all">All services</option>
                <option value="category">Only a category</option>
              </select>
            </div>
            <div>
              <label for="bulk_scope_category">Category</label>
              <select id="bulk_scope_category" class="settings-input"></select>
            </div>
          </div>
          <div class="settings-hint">Bulk edits change the saved mapping for many services at once.</div>
        </div>

        <div class="settings-row">
          <div class="wiz-row" style="margin-bottom:0;">
            <div>
              <label for="bulk_scheme">Scheme</label>
              <select id="bulk_scheme" class="settings-input">
                <option value="">(Leave unchanged)</option>
                <option value="http">http</option>
                <option value="https">https</option>
              </select>
            </div>
            <div>
              <label for="bulk_url_mode">URL mode</label>
              <select id="bulk_url_mode" class="settings-input">
                <option value="">(Leave unchanged)</option>
                <option value="local">Local host/IP</option>
                <option value="domain">Domain</option>
              </select>
            </div>
          </div>
        </div>

        <div class="settings-row">
          <label for="bulk_category">Set category</label>
          <select id="bulk_category" class="settings-input"></select>
          <div class="settings-hint">Optional. Leave blank to keep each service's current category.</div>
        </div>

        <div class="settings-row">
          <div class="wiz-row" style="margin-bottom:0;">
            <div>
              <label for="bulk_domain_suffix">Domain suffix</label>
              <input id="bulk_domain_suffix" class="settings-input" spellcheck="false" placeholder="sidneyshelton.com" />
            </div>
            <div>
              <label for="bulk_domain_pattern">Domain pattern</label>
              <input id="bulk_domain_pattern" class="settings-input" spellcheck="false" placeholder="{unit}.{suffix}" />
            </div>
          </div>
          <div class="settings-hint">Optional. Applies to dashboard defaults (not per-service), unless you override per service.</div>
        </div>

        <div class="settings-actions" style="margin-bottom:12px;">
          <button class="ebtn primary" onclick="applyBulkEdits()">Apply bulk edits to settings (then Save)</button>
        </div>

        <div class="settings-divider"></div>
        <div class="settings-title" style="margin-top:10px;">Categories (Service Types)</div>

        <div class="settings-row">
          <div class="wiz-row" style="margin-bottom:0;">
            <div>
              <label for="cat_key">New key</label>
              <input id="cat_key" class="settings-input" spellcheck="false" placeholder="books" />
            </div>
            <div>
              <label for="cat_label">Label</label>
              <input id="cat_label" class="settings-input" spellcheck="false" placeholder="Books" />
            </div>
            <div>
              <label for="cat_icon">Icon</label>
              <input id="cat_icon" class="settings-input" spellcheck="false" placeholder="📚" />
            </div>
          </div>
          <div class="settings-actions" style="margin-top:10px;">
            <button class="ebtn" onclick="addCategory()">Add / Update category</button>
          </div>
          <div class="settings-hint">After adding a category, you can assign it to services using the Service type dropdown.</div>
        </div>

        <div class="settings-actions">
          <button class="ebtn" onclick="autoDetectSelected()">🔍 Auto-detect this service</button>
          <button class="ebtn" onclick="saveAllSettings()">Save</button>
        </div>
      </div>

    </div><!-- /settings-wrap row 1 -->

    <!-- Bootstrap / Reset card — full width -->
    <div class="settings-wrap" style="margin-top:12px;">
      <div class="settings-card" style="min-width:100%;flex-basis:100%;">
        <div class="accordion-hdr" onclick="toggleAccordion(this)">
          <span class="acc-title">⚙️ Bootstrap / Reset Settings</span>
          <span class="acc-arrow">▼</span>
        </div>
        <div class="accordion-body">
          <div class="settings-hint" style="margin-bottom:12px;">
            Choose how the dashboard builds its initial service list. <b>Embedded</b> seeds from the Python <code>SERVICES</code> list (your current setup).
            <b>Blank</b> clears everything so you can add services manually or via auto-scan from scratch.
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button class="ebtn" onclick="doBootstrap('embedded')">🔄 Reset to Embedded (rebuild from SERVICES list)</button>
            <button class="ebtn danger" onclick="doBootstrap('blank')">🗑 Reset to Blank (wipe &amp; start fresh)</button>
          </div>
          <div class="settings-row" style="margin-top:14px;">
            <label for="set_scan_paths">Scan path overrides <span style="color:var(--text3);font-weight:400;">(host_path:container_path, one per line)</span></label>
            <textarea id="set_scan_paths" class="settings-textarea" spellcheck="false"
              placeholder="/opt/appdata:/config&#10;/opt/app:/app&#10;/opt/appdata/sonarr-a/config:/config"></textarea>
            <div class="settings-hint">Used by auto-detect to map host paths to container paths when scanning docker mounts. Add your own if docker inspect returns container-internal paths you want to resolve to host paths.</div>
          </div>
          <div class="settings-actions">
            <button class="ebtn" onclick="saveScanPaths()">Save scan paths</button>
          </div>
        </div>
      </div>
    </div>

    <!-- General System Files — accordion, default closed -->
    <div class="settings-wrap" style="margin-top:12px;">
      <div class="settings-card" style="min-width:100%;flex-basis:100%;">
        <div class="accordion-hdr" onclick="toggleAccordion(this)">
          <span class="acc-title">📁 General System Files</span>
          <span class="acc-arrow">▼</span>
        </div>
        <div class="accordion-body">
          <div class="settings-hint" style="margin-bottom:12px;">
            System-wide configuration files — not tied to any individual service card. Changes take effect after the relevant service is restarted.
          </div>
          <div class="sysfiles-grid" id="sysfiles-grid"></div>
          <div class="sysfiles-browse-row" style="margin-top:10px;">
            <span class="settings-hint">Browse for any other system file:</span>
            <button class="ebtn" style="font-size:11px;" onclick="openBrowserForSysFile()">📁 Browse /etc …</button>
          </div>
        </div>
      </div>
    </div>

  </div><!-- /tab-settings -->

  <div class="footer">
    <span id="fsum">Loading...</span>
    <span id="fupd">...</span>
  </div>
</div>

<!-- Viewer -->
<div class="viewer-overlay" id="viewer">
  <div class="viewer-panel">
    <div class="viewer-bar">
      <span class="viewer-title" id="vtitle"></span>
      <span class="viewer-url" id="vurl"></span>
      <button class="ebtn back" onclick="backToDashboard()">← Dashboard</button>
      <a id="vext" href="#" target="_blank" class="ebtn" style="text-decoration:none">↗ Open</a>
      <button class="viewer-close" onclick="closeViewer()">✕</button>
    </div>
    <iframe class="viewer-frame" id="vframe"></iframe>
    <div id="vblocked" style="display:none; padding:18px; background:var(--bg); color:var(--text); flex:1; overflow:auto;">
      <div style="max-width:820px; margin:0 auto; padding-top:10px;">
        <div style="font-size:14px; font-weight:800; margin-bottom:8px;">This service can’t be embedded</div>
        <div id="vblocked_reason" style="font-family:var(--mono); font-size:12px; color:var(--text2); line-height:1.5; margin-bottom:14px;"></div>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
          <a id="vblocked_open" class="ebtn primary" target="_blank" rel="noreferrer" style="text-decoration:none;">↗ Open in new tab</a>
          <button class="ebtn" onclick="retryViewerEmbed()">Retry embed</button>
        </div>
        <div style="margin-top:14px; font-family:var(--mono); font-size:11px; color:var(--text3);">
          Tip: Some apps (like Calibre-Web) send security headers that block iframes in Firefox/Chrome. Opening in a new tab is normal.
        </div>
      </div>
    </div>

  </div>
</div>

<!-- Editor -->
<div class="editor-overlay" id="editor">
  <div class="editor-panel">
    <div class="editor-bar">
      <span class="editor-title" id="etitle"></span>
      <span class="editor-path" id="epath"></span>
      <div class="editor-btns">
        <button class="ebtn back" onclick="backToDashboard()">← Dashboard</button>
        <button class="ebtn save" onclick="saveFile()">Save</button>
        <button class="ebtn close" onclick="closeEditor()">Close</button>
      </div>
    </div>
    <div class="editor-select" id="efiles"></div>
    <div style="padding:12px 18px; border-bottom:1px solid var(--border); background:var(--bg);">
      <div class="accordion-hdr" id="es_hdr" onclick="toggleEditorSvcSettings()">
        <div class="acc-title">Service Settings</div>
        <div class="acc-arrow">▼</div>
      </div>
      <div class="accordion-body" id="es_body">
        <div class="settings-wrap" style="margin-top:0">
          <div class="settings-card" style="min-width:260px">
            <div class="settings-title">URL & Type</div>
            <div class="settings-row">
              <label>URL Mode</label>
              <select class="settings-input" id="es_url_mode" onchange="editorUpdatePreview()">
                <option value="local">Local (host:port)</option>
                <option value="domain">Domain (no port)</option>
              </select>
              <div class="settings-hint">Domain mode removes the port from preview/open URLs.</div>
            </div>
            <div class="settings-row">
              <label>Scheme</label>
              <select class="settings-input" id="es_scheme" onchange="editorUpdatePreview()">
                <option value="">(Default)</option>
                <option value="http">http</option>
                <option value="https">https</option>
              </select>
            </div>
            <div class="settings-row">
              <label>Domain</label>
              <input class="settings-input" id="es_domain" placeholder="radarr.sidneyshelton.com" oninput="editorUpdatePreview()"/>
            </div>
            <div class="settings-row">
              <label>Full URL Override</label>
              <input class="settings-input" id="es_override" placeholder="https://radarr.sidneyshelton.com" oninput="editorUpdatePreview()"/>
              <div class="settings-hint">If set, this exact URL is used for preview/open.</div>
            </div>
            <div class="settings-row">
              <label>Category / Type</label>
              <select class="settings-input" id="es_category" onchange="editorUpdatePreview()"></select>
            </div>
            <div class="settings-row">
              <label>Preview URL</label>
              <div class="viewer-url" id="es_preview" style="margin:0; text-align:left; display:block;"></div>
            </div>
            <div class="settings-actions">
              <button class="ebtn save" onclick="editorSaveServiceSettings()">Save Service Settings</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="editor-area"><textarea id="etext" spellcheck="false"></textarea></div>
    <div class="editor-status"><span id="estatus"></span><span id="elines"></span></div>
  </div>
</div>

<!-- File Browser -->
<div class="browser-overlay" id="browser">
  <div class="browser-panel">
    <div class="browser-bar">
      <span class="browser-title">Browse for Config File</span>
      <button class="viewer-close" onclick="closeBrowser()">✕</button>
    </div>
    <div class="browser-path" id="bpath">/opt</div>
    <div class="browser-list" id="blist"></div>
    <div class="browser-actions">
      <input type="text" class="browser-input" id="binput" placeholder="Or type full path..." />
      <button class="ebtn" onclick="selectBrowserPath()">Select</button>
      <button class="ebtn close" onclick="closeBrowser()">Cancel</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<!-- Add Service Wizard -->
<div class="wizard-overlay" id="wizard">
  <div class="wizard-panel">
    <div class="wizard-bar">
      <span class="wizard-title" id="wiz-title">Add Service</span>
      <button class="viewer-close" onclick="closeWizard()">✕</button>
    </div>
    <div class="wizard-body" id="wiz-body"></div>
    <div class="wizard-footer" id="wiz-footer"></div>
  </div>
</div>

<script>
const IP = location.hostname;
let countdown = 30, DATA = null, currentEditorUnit = null, currentEditorFile = null;
let browserCallback = null;

let SETTINGS = null; // already used by settings tab; keep global

function toggleEditorSvcSettings(){
  const hdr = document.getElementById('es_hdr');
  const body = document.getElementById('es_body');
  if (!hdr || !body) return;
  const open = body.classList.contains('open');
  if (open){
    body.classList.remove('open');
    hdr.classList.remove('open');
  } else {
    body.classList.add('open');
    hdr.classList.add('open');
  }
}

function _populateEditorCategorySelect(){
  const sel = document.getElementById('es_category');
  if (!sel) return;
  sel.innerHTML = '';
  const cats = (SETTINGS && SETTINGS.categories) ? SETTINGS.categories : ((DATA && DATA.categories) ? DATA.categories : {});
  const keys = Object.keys(cats || {}).sort();
  for (const k of keys){
    const meta = cats[k] || {};
    const o = document.createElement('option');
    o.value = k;
    o.textContent = `${(meta.icon||'').trim()} ${(meta.label||k)}`.trim();
    sel.appendChild(o);
  }
}

function editorLoadServiceSettings(unit){
  if (!unit) return;
  const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
  const ov = (DATA && DATA.settings && DATA.settings.services && DATA.settings.services[unit]) ? DATA.settings.services[unit] : null;

  _populateEditorCategorySelect();

  const urlModeEl = document.getElementById('es_url_mode');
  const schemeEl  = document.getElementById('es_scheme');
  const domEl     = document.getElementById('es_domain');
  const ovEl      = document.getElementById('es_override');
  const catEl     = document.getElementById('es_category');

  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const effUrlMode = ((ov && ov.url_mode) || (s && s.url_mode) || dash.default_url_mode || 'local') + '';
  const effScheme  = ((ov && ov.scheme) || (s && s.scheme) || '') + '';
  const effDomain  = ((ov && ov.domain) || (s && s.domain) || '') + '';
  const effOverride= ((ov && ov.url_override) || (s && s.url_override) || '') + '';
  const effCat     = ((ov && ov.category) || (s && s.category) || 'home') + '';

  if (urlModeEl) urlModeEl.value = effUrlMode;
  if (schemeEl) schemeEl.value = effScheme;
  if (domEl) domEl.value = effDomain;
  if (ovEl) ovEl.value = effOverride;
  if (catEl) catEl.value = effCat;

  editorUpdatePreview();
}

function editorCollectServicePatch(){
  const patch = {};
  const urlModeEl = document.getElementById('es_url_mode');
  const schemeEl  = document.getElementById('es_scheme');
  const domEl     = document.getElementById('es_domain');
  const ovEl      = document.getElementById('es_override');
  const catEl     = document.getElementById('es_category');

  if (urlModeEl) patch.url_mode = (urlModeEl.value || '').trim();
  if (schemeEl)  patch.scheme = (schemeEl.value || '').trim();
  if (domEl)     patch.domain = (domEl.value || '').trim();
  if (ovEl)      patch.url_override = (ovEl.value || '').trim();
  if (catEl)     patch.category = (catEl.value || '').trim();

  if (!patch.scheme) delete patch.scheme;
  if (!patch.domain) delete patch.domain;
  if (!patch.url_override) delete patch.url_override;

  return patch;
}

function editorUpdatePreview(){
  const unit = currentEditorUnit || '';
  if (!unit) return;
  const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
  if (!s) return;

  const patch = editorCollectServicePatch();
  const s2 = Object.assign({}, s, patch, {unit: s.unit, name: s.name});

  const url = buildServiceUrl(s2);
  const el = document.getElementById('es_preview');
  if (el) el.textContent = url;
}

async function editorSaveServiceSettings(){
  const unit = currentEditorUnit || '';
  if (!unit) { toast('No service selected', false); return; }

  // Ensure we have latest SETTINGS object (same one used by Settings tab)
  try{
    if (!SETTINGS) {
      await loadSettings();
    } else {
      _ensureSettingsShape();
    }
  }catch(e){}

  // If loadSettings didn't set it, fall back
  if (!SETTINGS) SETTINGS = (DATA && DATA.settings) ? JSON.parse(JSON.stringify(DATA.settings)) : {};
  if (!SETTINGS.services) SETTINGS.services = {};
  if (!SETTINGS.services[unit] || typeof SETTINGS.services[unit] !== 'object') SETTINGS.services[unit] = {};

  const patch = editorCollectServicePatch();
  Object.assign(SETTINGS.services[unit], patch);

  try{
    const r = await fetch('/api/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({settings: SETTINGS}) });
    const d = await r.json();
    if (!d.ok) { toast(d.message || 'Failed to save settings', false); return; }

    SETTINGS = d.settings || SETTINGS;
    DATA.settings = SETTINGS;

    // Merge into DATA.services list entry so future clicks use updated values immediately
    const i = (DATA && DATA.services) ? DATA.services.findIndex(x => x.unit === unit) : -1;
    if (i >= 0){
      const ov = (SETTINGS.services && SETTINGS.services[unit]) ? SETTINGS.services[unit] : {};
      DATA.services[i] = Object.assign({}, DATA.services[i], ov);
    }

    toast('Service settings saved', true);
    editorUpdatePreview();
  }catch(e){
    console.error(e);
    toast('Failed to save service settings', false);
  }
}

function viewerBase(){
  // Viewer base is still useful for some fallbacks
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const scheme = (dash.viewer_scheme || 'http');
  let host = (dash.viewer_host || 'auto');
  if (!host || host === 'auto') host = IP;
  return `${scheme}://${host}`;
}

function normalizePath(p){
  if (!p) return '';
  return p.startsWith('/') ? p : ('/' + p);
}

function getViewerHost(){
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const vh = (dash.viewer_host || 'auto') + '';
  if (!vh || vh === 'auto') return IP;
  return vh;
}

function buildServiceUrl(s){
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};

  // 1) Full override wins
  const override = (s.url_override || '').trim();
  if (override) return override;

  // 2) Scheme per-service, else dashboard default
  const scheme = ((s.scheme || '') + '').trim() || (dash.viewer_scheme || 'http');

  // 3) Host mode
  const urlMode = ((s.url_mode || '') + '').trim() || (dash.default_url_mode || 'local');

  let host = '';
  if (urlMode === 'domain'){
    const suffix = ((s.domain_suffix || '') + '').trim() || (dash.default_domain_suffix || '');
    const pattern = ((dash.default_domain_pattern || '') + '').trim() || '{unit}.{suffix}';
    host = ((s.domain || '') + '').trim();
    if (!host){
      host = pattern.replace('{unit}', s.unit).replace('{suffix}', suffix);
    }
  } else {
    host = ((s.host || '') + '').trim() || getViewerHost();
  }

  // Port handling: in domain mode, omit :port from URL (reverse proxy / DNS handles it)
  const portRaw = (s.port === null || s.port === undefined || s.port === '') ? '' : ('' + s.port).trim();
  const port = (urlMode === 'domain') ? '' : portRaw;
  const wp = (s.web_path === null || s.web_path === undefined) ? '' : normalizePath((s.web_path || '').trim());

  const hostPort = port ? `${host}:${port}` : host;
  return `${scheme}://${hostPort}${wp}`;
}

function openViewerUnit(unit){
  try{
    const s = (DATA && DATA.services) ? DATA.services.find(x => x.unit === unit) : null;
    if(!s){ toast('Service data not loaded', false); return; }
    // Merge latest saved per-service URL overrides from settings so changes apply immediately
    const ov = (DATA && DATA.settings && DATA.settings.services && DATA.settings.services[unit]) ? DATA.settings.services[unit] : null;
    const s2 = (ov && typeof ov === 'object') ? Object.assign({}, s, ov, {unit: s.unit, name: s.name}) : s;
    openViewer(s.name, buildServiceUrl(s2));
  }catch(e){ console.error(e); toast('Failed to open viewer', false); }
}

// SVG icons
const ICO = {
  play: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
  stop: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="6" y="6" width="12" height="12"/></svg>',
  refresh: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
  eye: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
  edit: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
  book: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  file: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>',
};

function toast(msg, ok=true) {
  const d = document.getElementById('toast');
  const el = document.createElement('div');
  el.className = 'toast-msg ' + (ok ? 'ok' : 'err');
  el.textContent = msg;
  d.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function fmtB(b) { return b > 1073741824 ? (b/1073741824).toFixed(1)+' GB' : b > 1048576 ? (b/1048576).toFixed(0)+' MB' : (b/1024).toFixed(0)+' KB'; }
function pctCls(p) { return p < 60 ? 'fg' : p < 85 ? 'fa' : 'fr'; }

function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(e => e.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  if (btn) btn.classList.add('active');
  if (tab === 'logs') buildLogList();
  if (tab === 'settings') { loadSettings(); renderSystemFiles(); }
}

function backToDashboard() {
  closeViewer();
  closeEditor();
  closeBrowser();
  // Activate dashboard tab
  document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(e => e.classList.remove('active'));
  document.getElementById('tab-dashboard').classList.add('active');
  document.querySelector('.nav-btn[data-tab="dashboard"]').classList.add('active');
}

function renderSys(s) {
  const el = document.getElementById('sys-bar');
  if (!s || !s.mem_total) {
    el.innerHTML = '<div class="sys-card"><div class="sys-val">Loading system info...</div></div>';
    return;
  }
  const mp = ((s.mem_used/s.mem_total)*100).toFixed(1);
  const dp = ((s.disk_used/(s.disk_used+s.disk_avail))*100).toFixed(1);
  const sp = s.swap_total > 0 ? ((s.swap_used/s.swap_total)*100).toFixed(1) : 0;
  el.innerHTML = `
    <div class="sys-card"><div class="sys-lbl">Host / IP</div><div class="sys-val">${s.hostname}</div><div class="sys-sub">${s.ip}</div></div>
    <div class="sys-card"><div class="sys-lbl">Uptime</div><div class="sys-val">${s.uptime||'—'}</div><div class="sys-sub">${s.os||''}</div></div>
    <div class="sys-card"><div class="sys-lbl">Load</div><div class="sys-val">${s.load||'—'}</div><div class="sys-sub">${s.cpu_temp?s.cpu_temp+'°C':''} ${s.kernel||''}</div></div>
    <div class="sys-card"><div class="sys-lbl">Memory</div><div class="sys-val">${mp}%</div><div class="sys-sub">${fmtB(s.mem_used)} / ${fmtB(s.mem_total)}</div><div class="pbar"><div class="pfill ${pctCls(mp)}" style="width:${mp}%"></div></div></div>
    <div class="sys-card"><div class="sys-lbl">Swap</div><div class="sys-val">${sp}%</div><div class="sys-sub">${fmtB(s.swap_used)} / ${fmtB(s.swap_total)}</div><div class="pbar"><div class="pfill ${pctCls(sp)}" style="width:${sp}%"></div></div></div>
    <div class="sys-card"><div class="sys-lbl">Disk</div><div class="sys-val">${dp}%</div><div class="sys-sub">${fmtB(s.disk_used)} / ${fmtB(s.disk_used+s.disk_avail)}</div><div class="pbar"><div class="pfill ${pctCls(dp)}" style="width:${dp}%"></div></div></div>`;
}

function renderSvc(services, cats) {
  const c = document.getElementById('svc-container');
  if (!services || !services.length) {
    c.innerHTML = '<div class="sys-card"><div class="sys-val">Loading services...</div></div>';
    return;
  }
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  const hideStopped = !!dash.hide_stopped_services;
  const protectDash = (dash.protect_dashboard_service !== false);
  const hiddenUnits = Array.isArray(dash.hidden_units) ? dash.hidden_units : [];
  let list = services.filter(s => !hiddenUnits.includes(s.unit));
  if (hideStopped) list = list.filter(s => s.status === 'active');

  const g = {};
  list.forEach(s => { if(!g[s.category]) g[s.category]=[]; g[s.category].push(s); });
  const order = ['media','arr','downloads','tv','home','system'];
  let h = '';
  order.forEach(cat => {
    const items = g[cat]; if(!items) return;
    const m = cats[cat]||{label:cat,icon:'📦'};
    const ac = items.filter(s=>s.status==='active').length;
    h += `<div class="category"><div class="cat-hdr"><span class="cat-icon">${m.icon}</span><span class="cat-title">${m.label}</span><span class="cat-count">${ac}/${items.length}</span></div><div class="sgrid">`;
    items.forEach(s => {
      const cls = s.status==='active'?'on':s.status==='inactive'?'off':'unk';
      const rtBadge = s.runtime === 'docker'   ? '<span class="rt-badge rt-docker">docker</span>'
                    : s.runtime === 'systemd'  ? '<span class="rt-badge rt-systemd">svc</span>'
                    : s.runtime === 'external' ? '<span class="rt-badge rt-external">ext</span>'
                    : '';
      let port = '';
      if (s.port) {
        if (s.web_path !== null && s.web_path !== undefined)
          port = `<span class="sport"><a href="#" onclick="openViewerUnit('${s.unit}');return false">:${s.port}</a></span>`;
        else port = `<span class="sport">:${s.port}</span>`;
      }
      const mem = s.memory_mb ? `<span class="smem">${s.memory_mb}M</span>` : '';
      const cpu = s.cpu_pct != null ? `<span class="scpu">${s.cpu_pct}%</span>` : '';
      const isDash = (s.unit === 'server-dashboard');
      const hasView = (!isDash) && s.port && s.web_path !== null && s.web_path !== undefined;
      const hasEdit = true;
      const showStop = (!isDash);

      h += `<div class="svc ${cls}">
        <div class="sdot"></div>
        <div class="sinfo"><div class="sname">${s.name} ${rtBadge}</div><div class="sdesc">${s.description} · <code>${s.unit}</code></div></div>
        <div class="smeta">${cpu}${mem}${port}</div>
        <div class="sctrl">
          <button class="cbtn start" title="Start" onclick="svcCtrl('${s.unit}','start',this)">${ICO.play}</button>
          ${showStop?`<button class="cbtn stop" title="Stop" onclick="svcCtrl('${s.unit}','stop',this)">${ICO.stop}</button>`:''}
          <button class="cbtn restart" title="Restart" onclick="svcCtrl('${s.unit}','restart',this)">${ICO.refresh}</button>
          ${s.unit==='kiwix'?`<button class="cbtn kiwix" title="Refresh Kiwix Library" onclick="kiwixRefresh(this)">${ICO.book}</button>`:''}
          ${hasView?`<button class="cbtn view" title="Open UI" onclick="openViewerUnit('${s.unit}')">${ICO.eye}</button>`:''}
          ${hasEdit?`<button class="cbtn edit" title="Edit Config" onclick="openEditor('${s.unit}')">${ICO.edit}</button>`:''}
        </div>
      </div>`;
    });
    h += '</div></div>';
  });
  c.innerHTML = h;
}

async function svcCtrl(unit, action, btn) {
  const dash = (DATA && DATA.settings && DATA.settings.dashboard) ? DATA.settings.dashboard : {};
  if (action === 'stop') {
    const protectDash = (dash.protect_dashboard_service !== false);
    if (protectDash && unit === 'server-dashboard') {
      toast('Stop is disabled for Server Dashboard', false);
      return;
    }
  }
  btn.classList.add('spinning');
  try {
    const r = await fetch('/api/control', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({unit,action}) });
    const d = await r.json();
    toast(d.message, d.ok);
    setTimeout(fetchData, 1500);
  } catch(e) { toast('Request failed', false); }
  btn.classList.remove('spinning');
}

async function kiwixRefresh(btn) {
  btn.classList.add('spinning');
  try {
    const r = await fetch('/api/kiwix/refresh', { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' });
    const d = await r.json();
    toast(d.message || 'Kiwix refresh complete', d.ok);
    if (d.details) console.log('[Kiwix refresh]\n' + d.details);
    setTimeout(fetchData, 2500);
  } catch(e) {
    toast('Kiwix refresh request failed', false);
  }
  btn.classList.remove('spinning');
}

// Settings (dashboard-only mappings)
// (SETTINGS is declared near the top of the script)

function _linesToList(v){
  return (v || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(s => !!s);
}

function _listToLines(arr){
  return Array.isArray(arr) ? arr.join('\n') : '';
}

function _svcKey(){
  const el = document.getElementById('svc_pick');
  return el ? (el.value || '') : '';
}

function _ensureSettingsShape(){
  if (!SETTINGS || typeof SETTINGS !== 'object') SETTINGS = {};
  if (!SETTINGS.dashboard || typeof SETTINGS.dashboard !== 'object') SETTINGS.dashboard = {};
  if (!SETTINGS.services || typeof SETTINGS.services !== 'object') SETTINGS.services = {};

  // New: categories + domain defaults
  if (!SETTINGS.categories || typeof SETTINGS.categories !== 'object') SETTINGS.categories = (DATA && DATA.categories) ? JSON.parse(JSON.stringify(DATA.categories)) : {};
  if (SETTINGS.dashboard.default_url_mode === undefined) SETTINGS.dashboard.default_url_mode = 'local';
  if (SETTINGS.dashboard.default_domain_suffix === undefined) SETTINGS.dashboard.default_domain_suffix = 'sidneyshelton.com';
  if (SETTINGS.dashboard.default_domain_pattern === undefined) SETTINGS.dashboard.default_domain_pattern = '{unit}.{suffix}';

  if (SETTINGS.dashboard.hide_stopped_services === undefined) SETTINGS.dashboard.hide_stopped_services = false;
  if (SETTINGS.dashboard.protect_dashboard_service === undefined) SETTINGS.dashboard.protect_dashboard_service = true;
  if (!Array.isArray(SETTINGS.dashboard.hidden_units)) SETTINGS.dashboard.hidden_units = [];
}

function _catKeys(){
  _ensureSettingsShape();
  return Object.keys(SETTINGS.categories || {}).sort();
}

function populateCategorySelect(selectEl, includeBlank){
  if (!selectEl) return;
  const prev = selectEl.value;
  selectEl.innerHTML = '';
  if (includeBlank){
    const o = document.createElement('option');
    o.value = '';
    o.textContent = '(No change / Default)';
    selectEl.appendChild(o);
  }
  for (const k of _catKeys()){
    const meta = SETTINGS.categories[k] || {};
    const o = document.createElement('option');
    o.value = k;
    o.textContent = `${meta.icon || ''} ${meta.label || k}`.trim();
    selectEl.appendChild(o);
  }
  if (prev) selectEl.value = prev;
}

function refreshCategoryPickers(){
  populateCategorySelect(document.getElementById('svc_category'), false);
  populateCategorySelect(document.getElementById('bulk_scope_category'), false);
  populateCategorySelect(document.getElementById('bulk_category'), true);
}
function populateServicePicker(){
  const pick = document.getElementById('svc_pick');
  if (!pick) return;
  const prev = pick.value;
  pick.innerHTML = '';
  const filterEl = document.getElementById('svc_rt_filter');
  const filterVal = filterEl ? filterEl.value : '';
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  let count = 0;
  for (const s of svcs){
    if (filterVal && s.runtime !== filterVal) continue;
    const opt = document.createElement('option');
    opt.value = s.unit;
    const badge = s.runtime === 'docker' ? '🐳' : s.runtime === 'systemd' ? '🐧' : '🌐';
    opt.textContent = `${badge} ${s.name}  (${s.unit})`;
    pick.appendChild(opt);
    count++;
  }
  const countEl = document.getElementById('svc_pick_count');
  if (countEl) countEl.textContent = count;
  if (prev) pick.value = prev;
  onPickService();
}

function onRuntimeChange(){
  const rt = document.getElementById('svc_runtime')?.value || 'docker';
  const dockerRow = document.getElementById('svc_docker_row');
  const hostRow   = document.getElementById('svc_host_row');
  const volRow    = document.getElementById('svc_volmap_row');
  if (dockerRow) dockerRow.style.display = rt === 'docker'   ? 'block' : 'none';
  if (volRow)    volRow.style.display    = rt === 'docker'   ? 'block' : 'none';
  if (hostRow)   hostRow.style.display   = rt === 'external' ? 'block' : 'none';
}

function onPickService(){
  _ensureSettingsShape();
  const unit = _svcKey();
  if (!unit) return;
  // Prefer live DATA for runtime so new dynamically-added services show up correctly
  const liveSvc = (DATA && DATA.services) ? DATA.services.find(s => s.unit === unit) : null;
  const entry = (SETTINGS.services && SETTINGS.services[unit]) ? SETTINGS.services[unit] : (liveSvc || {});

  const rt = entry.runtime || (liveSvc && liveSvc.runtime) || 'docker';
  const rtEl = document.getElementById('svc_runtime');
  if (rtEl) rtEl.value = rt;
  onRuntimeChange();

  const dcEl = document.getElementById('svc_docker_container');
  if (dcEl) dcEl.value = (entry.docker_container || liveSvc?.docker_container || '') + '';

  const hostEl = document.getElementById('svc_host');
  if (hostEl) hostEl.value = (entry.host || liveSvc?.host || 'localhost') + '';

  document.getElementById('svc_port').value = ((entry.port ?? liveSvc?.port) ?? '') + '';
  document.getElementById('svc_web_path').value = (entry.web_path ?? liveSvc?.web_path ?? '') + '';
  // URL + category fields
  const scEl = document.getElementById('svc_scheme');
  if (scEl) scEl.value = (entry.scheme ?? liveSvc?.scheme ?? '') + '';
  const umEl = document.getElementById('svc_url_mode');
  if (umEl) umEl.value = (entry.url_mode ?? liveSvc?.url_mode ?? '') + '';
  const domEl = document.getElementById('svc_domain');
  if (domEl) domEl.value = (entry.domain ?? liveSvc?.domain ?? '') + '';
  const ovEl = document.getElementById('svc_url_override');
  if (ovEl) ovEl.value = (entry.url_override ?? liveSvc?.url_override ?? '') + '';

  refreshCategoryPickers();
  const catEl = document.getElementById('svc_category');
  if (catEl) catEl.value = (entry.category ?? liveSvc?.category ?? 'home') + '';
  document.getElementById('svc_config_files').value = _listToLines(entry.config_files || liveSvc?.config_files || []);
  document.getElementById('svc_data_paths').value   = _listToLines(entry.data_paths   || liveSvc?.data_paths   || []);

  const vmEl = document.getElementById('svc_volume_maps');
  if (vmEl) vmEl.value = _listToLines(entry.volume_maps || liveSvc?.volume_maps || []);

  const isKiwix = unit === 'kiwix';
  document.getElementById('kiwix_extra').style.display = isKiwix ? 'block' : 'none';
  if (isKiwix){
    document.getElementById('svc_kiwix_zim_dir').value    = (entry.kiwix_zim_dir    ?? '') + '';
    document.getElementById('svc_kiwix_library_xml').value = (entry.kiwix_library_xml ?? '') + '';
  }
}

// ── Accordion ───────────────────────────────────────────────────────────
function toggleAccordion(hdr){
  hdr.classList.toggle('open');
  const body = hdr.nextElementSibling;
  if (body) body.classList.toggle('open');
}

// ── Bootstrap / Reset ───────────────────────────────────────────────────
async function doBootstrap(mode){
  const msg = mode === 'blank'
    ? 'This will WIPE all service settings and start fresh. Are you sure?'
    : 'This will rebuild settings from the embedded SERVICES list, discarding manual changes. Continue?';
  if (!confirm(msg)) return;
  try {
    const r = await fetch('/api/bootstrap', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({mode})});
    const d = await r.json();
    toast(d.message || (d.ok ? 'Done' : 'Failed'), !!d.ok);
    if (d.ok){ await fetchData(); await loadSettings(); }
  } catch(e){ toast('Request failed', false); }
}

async function saveScanPaths(){
  _ensureSettingsShape();
  const ta = document.getElementById('set_scan_paths');
  if (!ta) return;
  if (!SETTINGS.bootstrap) SETTINGS.bootstrap = {};
  SETTINGS.bootstrap.scan_paths = _linesToList(ta.value);
  await saveAllSettings();
}

// ── Add Service Wizard ──────────────────────────────────────────────────
let _SCAN_RESULTS = null;
let _SCAN_SEL     = new Map();  // rowId -> {type, data}
let _SCAN_PAYLOAD = new Map(); // rowId -> raw scanned item payload
let _wizMode      = 'scan';     // 'scan' | 'manual'
let _wizRT        = 'systemd';  // runtime tab for manual form

async function openWizard(mode){
  _wizMode = mode || 'scan';
  _SCAN_SEL.clear();
  const overlay = document.getElementById('wizard');
  const body    = document.getElementById('wiz-body');
  const footer  = document.getElementById('wiz-footer');
  const title   = document.getElementById('wiz-title');

  if (_wizMode === 'manual'){
    title.textContent = 'Add Service Manually';
    body.innerHTML    = _buildManualForm('systemd');
    footer.innerHTML  = `<button class="ebtn close" onclick="closeWizard()">Cancel</button>
                         <button class="ebtn primary" onclick="_submitManual()">Add Service</button>`;
    overlay.classList.add('open');
    document.body.classList.add('modal-open');
  } else {
    title.textContent = 'Add Service — Auto Scan';
    body.innerHTML    = `<div style="color:var(--text2);padding:20px;text-align:center;">🔍 Scanning for services…</div>`;
    footer.innerHTML  = `<button class="ebtn close" onclick="closeWizard()">Cancel</button>
                         <button class="ebtn" onclick="openWizard('manual')">Manual entry instead</button>`;
    overlay.classList.add('open');
    document.body.classList.add('modal-open');
    try {
      const r = await fetch('/api/scan');
      const d = await r.json();
      _SCAN_RESULTS = d.results || {};
      _renderScanResults(body, footer);
    } catch(e){
      body.innerHTML = `<div style="padding:20px;color:var(--red);">Scan failed: ${e.message}</div>`;
    }
  }
}

function _catOpts(selectedVal) {
  const CATS = [
    {val:'media',     label:'🎬 Media'},
    {val:'arr',       label:'📡 Arr Stack'},
    {val:'downloads', label:'⬇️ Downloads'},
    {val:'tv',        label:'📺 TV / DVR'},
    {val:'home',      label:'🏠 Home & Apps'},
    {val:'system',    label:'⚙️ System'},
  ];
  return CATS.map(c => `<option value="${c.val}" ${c.val===selectedVal?'selected':''}>${c.label}</option>`).join('');
}

function _buildManualForm(rt){
  return `
  <div class="wiz-tabs">
    <button class="wiz-tab svc ${rt==='systemd'?'active':''}" onclick="_switchWizTab('systemd',this)">🐧 systemd</button>
    <button class="wiz-tab dkr ${rt==='docker'?'active':''}"  onclick="_switchWizTab('docker',this)">🐳 docker</button>
    <button class="wiz-tab ext ${rt==='external'?'active':''}" onclick="_switchWizTab('external',this)">🌐 external</button>
  </div>

  <!-- systemd panel -->
  <div class="wiz-panel ${rt==='systemd'?'active':''}" id="wt-systemd">
    <div class="wiz-row">
      <div class="wiz-field"><label>Display name</label><input id="wm_name" class="wiz-input" placeholder="e.g. My App"/></div>
      <div class="wiz-field"><label>Unit name</label><input id="wm_unit" class="wiz-input" placeholder="e.g. myapp (no .service)"/></div>
    </div>
    <div class="wiz-row">
      <div class="wiz-field"><label>Port</label><input id="wm_port" class="wiz-input" type="number" placeholder="8080"/></div>
      <div class="wiz-field"><label>Web path</label><input id="wm_webpath" class="wiz-input" placeholder="/ or /web"/></div>
    </div>
    <div class="wiz-field">
      <label>Section / Category</label>
      <select id="wm_cat" class="wiz-input">${_catOpts('home')}</select>
    </div>
    <div class="wiz-field"><label>Description</label><input id="wm_desc" class="wiz-input" placeholder="Brief description"/></div>
    <div class="wiz-hint">Controlled via <code>sudo systemctl start/stop/restart &lt;unit&gt;</code>.</div>
  </div>

  <!-- docker panel -->
  <div class="wiz-panel ${rt==='docker'?'active':''}" id="wt-docker">
    <div class="wiz-row">
      <div class="wiz-field"><label>Display name</label><input id="wm_dname" class="wiz-input" placeholder="e.g. Radarr B"/></div>
      <div class="wiz-field"><label>Container name</label><input id="wm_dcontainer" class="wiz-input" placeholder="e.g. radarr-b"/></div>
    </div>
    <div class="wiz-row">
      <div class="wiz-field"><label>Port</label><input id="wm_dport" class="wiz-input" type="number" placeholder="7878"/></div>
      <div class="wiz-field"><label>Web path</label><input id="wm_dwebpath" class="wiz-input" placeholder="/ or /web"/></div>
    </div>
    <div class="wiz-field">
      <label>Section / Category</label>
      <select id="wm_dcat" class="wiz-input">${_catOpts('home')}</select>
    </div>
    <div class="wiz-field"><label>Description</label><input id="wm_ddesc" class="wiz-input" placeholder="Brief description"/></div>
    <div class="wiz-hint">Controlled via <code>docker start/stop/restart &lt;container&gt;</code>.</div>
  </div>

  <!-- external panel -->
  <div class="wiz-panel ${rt==='external'?'active':''}" id="wt-external">
    <div class="wiz-row">
      <div class="wiz-field"><label>Display name</label><input id="wm_ename" class="wiz-input" placeholder="e.g. Windows Plex"/></div>
      <div class="wiz-field"><label>Host / IP</label><input id="wm_ehost" class="wiz-input" placeholder="192.168.0.50"/></div>
    </div>
    <div class="wiz-row">
      <div class="wiz-field"><label>Port</label><input id="wm_eport" class="wiz-input" type="number" placeholder="32400"/></div>
      <div class="wiz-field"><label>Web path</label><input id="wm_ewebpath" class="wiz-input" placeholder="/"/></div>
    </div>
    <div class="wiz-field">
      <label>Section / Category</label>
      <select id="wm_ecat" class="wiz-input">${_catOpts('home')}</select>
    </div>
    <div class="wiz-field"><label>Description</label><input id="wm_edesc" class="wiz-input" placeholder="e.g. Windows VM Plex"/></div>
    <div class="wiz-hint">No start/stop control — View link only. Great for Plex on another VM, NAS, Windows services, etc.</div>
  </div>`;
}

function _switchWizTab(rt, btn){
  document.querySelectorAll('.wiz-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.wiz-panel').forEach(p => p.classList.remove('active'));
  const panel = document.getElementById('wt-' + rt);
  if (panel) panel.classList.add('active');
  _wizRT = rt;
}

async function _submitManual(){
  let srv = {};
  if (_wizRT === 'systemd'){
    const name = (document.getElementById('wm_name')?.value||'').trim();
    const unit = (document.getElementById('wm_unit')?.value||'').trim().replace(/\.service$/,'');
    if (!name||!unit){ toast('Name and unit are required', false); return; }
    srv = {name, unit, runtime:'systemd', host:'localhost',
      port:        parseInt(document.getElementById('wm_port')?.value)||null,
      web_path:    (document.getElementById('wm_webpath')?.value||'').trim(),
      category:    document.getElementById('wm_cat')?.value||'home',
      description: (document.getElementById('wm_desc')?.value||'').trim()};
  } else if (_wizRT === 'docker'){
    const name      = (document.getElementById('wm_dname')?.value||'').trim();
    const container = (document.getElementById('wm_dcontainer')?.value||'').trim();
    if (!name||!container){ toast('Name and container name required', false); return; }
    srv = {name, unit:container, runtime:'docker', docker_container:container, host:'localhost',
      port:        parseInt(document.getElementById('wm_dport')?.value)||null,
      web_path:    (document.getElementById('wm_dwebpath')?.value||'').trim(),
      category:    document.getElementById('wm_dcat')?.value||'home',
      description: (document.getElementById('wm_ddesc')?.value||'').trim()};
  } else {
    const name = (document.getElementById('wm_ename')?.value||'').trim();
    const host = (document.getElementById('wm_ehost')?.value||'').trim();
    if (!name||!host){ toast('Name and host are required', false); return; }
    srv = {name, unit:name.toLowerCase().replace(/\s+/g,'-'), runtime:'external',
      host, port: parseInt(document.getElementById('wm_eport')?.value)||null,
      web_path:    (document.getElementById('wm_ewebpath')?.value||'').trim(),
      category:    document.getElementById('wm_ecat')?.value||'home',
      description: (document.getElementById('wm_edesc')?.value||'').trim()};
  }
  try {
    const r = await fetch('/api/servers/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({servers:[srv]})});
    const d = await r.json();
    toast(d.message||(d.ok?'Added':'Failed'), !!d.ok);
    if (d.ok){ closeWizard(); await fetchData(); await loadSettings(); }
  } catch(e){ toast('Request failed', false); }
}

function _renderScanResults(body, footer){
  _SCAN_PAYLOAD.clear();
  _SCAN_SEL.clear();
  const r   = _SCAN_RESULTS || {};
  const sys = (r.systemd || []).slice().sort((a,b) => a.unit.localeCompare(b.unit));
  const doc = (r.docker  || []).slice().sort((a,b) => a.container.localeCompare(b.container));
  const pts = (r.ports   || []).slice().sort((a,b) => a.port - b.port);

  const total = sys.length + doc.length + pts.length;
  const esc = s => String(s||'').replace(/[<>&"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));

  function catSel(idSuffix, defaultVal){
    return `<select class="wiz-input scan-cat-sel" id="scat_${idSuffix}" style="font-size:10px;padding:3px 6px;min-width:130px;" onclick="event.stopPropagation()">
      <option value="media"     ${defaultVal==='media'    ?'selected':''}>🎬 Media</option>
      <option value="arr"       ${defaultVal==='arr'      ?'selected':''}>📡 Arr Stack</option>
      <option value="downloads" ${defaultVal==='downloads'?'selected':''}>⬇️ Downloads</option>
      <option value="tv"        ${defaultVal==='tv'       ?'selected':''}>📺 TV / DVR</option>
      <option value="home"      ${defaultVal==='home'     ?'selected':''}>🏠 Home & Apps</option>
      <option value="system"    ${defaultVal==='system'   ?'selected':''}>⚙️ System</option>
    </select>`;
  }

  // Guess category from known service names / image names
  function guessCategory(name, image){
    const n = (name + ' ' + (image||'')).toLowerCase();
    if (/plex|jellyfin|emby|kodi|navidrome|airsonic|kiwix/.test(n))    return 'media';
    if (/sonarr|radarr|lidarr|readarr|prowlarr|bazarr|whisparr|arr/.test(n)) return 'arr';
    if (/qbittorrent|deluge|transmission|sabnzbd|nzbget|jdownloader/.test(n)) return 'downloads';
    if (/tvheadend|channels|hdhomerun|dizquetv|xteve/.test(n))          return 'tv';
    if (/homeassistant|home.assistant|ha |node.red|nodered|vaultwarden|bitwarden|uptime|dasherr|homer|flame|organizr/.test(n)) return 'home';
    if (/portainer|grafana|prometheus|netdata|dozzle|watchtower|nginx|traefik|caddy|docker|pihole|unbound/.test(n)) return 'system';
    return 'home';
  }

  let h = '';

  if (sys.length){
    h += `<div class="scan-section"><div class="scan-section-title">🐧 systemd services <span style="color:var(--text3);font-weight:400;">${sys.length} found</span></div>`;
    sys.forEach((item, i) => {
      const id  = `scan_sys_${i}`;
      const cat = guessCategory(item.unit, '');
      _SCAN_PAYLOAD.set(id, { type:'systemd', data:item });
      h += `<div class="scan-item" id="${id}" onclick="_toggleScanItemById('${id}')">
        <div class="scan-check">✓</div>
        <div class="scan-item-info">
          <div class="scan-item-name">${esc(item.unit)}</div>
          <div class="scan-item-sub">${esc(item.description||'')} · ${esc(item.active||'active')}</div>
        </div>
        ${catSel(id, cat)}
        <span class="scan-badge systemd">systemd</span>
      </div>`;
    });
    h += '</div>';
  }

  if (doc.length){
    h += `<div class="scan-section"><div class="scan-section-title">🐳 docker containers <span style="color:var(--text3);font-weight:400;">${doc.length} found</span></div>`;
    doc.forEach((item, i) => {
      const id  = `scan_dkr_${i}`;
      const cat = guessCategory(item.container, item.image);
      _SCAN_PAYLOAD.set(id, { type:'docker', data:item });
      h += `<div class="scan-item" id="${id}" onclick="_toggleScanItemById('${id}')">
        <div class="scan-check">✓</div>
        <div class="scan-item-info">
          <div class="scan-item-name">${esc(item.container)}</div>
          <div class="scan-item-sub">${esc(item.image||'')}${item.suggested_port ? ' · :'+item.suggested_port : ''} · ${esc(item.status||'')}</div>
        </div>
        ${catSel(id, cat)}
        <span class="scan-badge docker">docker</span>
      </div>`;
    });
    h += '</div>';
  }

  if (pts.length){
    h += `<div class="scan-section"><div class="scan-section-title">🔌 open ports <span style="color:var(--text3);font-weight:400;">${pts.length} found</span></div>`;
    pts.forEach((item, i) => {
      const id  = `scan_prt_${i}`;
      const cat = item.category || guessCategory(item.name, '');
      _SCAN_PAYLOAD.set(id, { type:'port', data:item });
      h += `<div class="scan-item" id="${id}" onclick="_toggleScanItemById('${id}')">
        <div class="scan-check">✓</div>
        <div class="scan-item-info">
          <div class="scan-item-name">${esc(item.name)} <span style="color:var(--cyan);font-family:var(--mono);">:${item.port}</span></div>
          <div class="scan-item-sub">${esc(item.description||'')}</div>
        </div>
        ${catSel(id, cat)}
        <span class="scan-badge port">port</span>
      </div>`;
    });
    h += '</div>';
  }

  if (!h) h = `<div class="scan-empty">No new services found. Everything may already be in the dashboard, or docker/systemd returned nothing.<br><br><b>Try Manual entry</b> to add a service by hand.</div>`;

  const selCount = () => _SCAN_SEL.size;
  body.innerHTML = h;
  footer.innerHTML = `<button class="ebtn close" onclick="closeWizard()">Cancel</button>
    <button class="ebtn" onclick="openWizard('manual')">✏️ Manual entry</button>
    <button class="ebtn primary" onclick="_addScanSelected()">Add Selected (<span id="wiz-sel-count">0</span>)</button>`;
}
function _toggleScanItemById(id){
  const payload = _SCAN_PAYLOAD.get(id);
  if (!payload) return;
  _toggleScanItem(id, payload.type, payload.data);
}

function _toggleScanItem(id, type, data){
  const el = document.getElementById(id);
  if (!el) return;
  if (_SCAN_SEL.has(id)){
    _SCAN_SEL.delete(id);
    el.classList.remove('sel');
  } else {
    _SCAN_SEL.set(id, {type, data});
    el.classList.add('sel');
  }
  const cnt = document.getElementById('wiz-sel-count');
  if (cnt) cnt.textContent = _SCAN_SEL.size;
}

async function _addScanSelected(){
  if (!_SCAN_SEL.size){ toast('Select at least one service', false); return; }
  const servers = [];
  _SCAN_SEL.forEach(({type, data}, id) => {
    // Read the per-item category dropdown if present
    const catEl = document.getElementById('scat_' + id);
    const cat   = catEl ? catEl.value : (data.category || 'home');
    if (type === 'systemd')
      servers.push({name:data.unit, unit:data.unit, runtime:'systemd', host:'localhost',
        port:data.suggested_port||null, category:cat, description:data.description||'', web_path:''});
    else if (type === 'docker')
      servers.push({name:data.container, unit:data.container, runtime:'docker',
        docker_container:data.container, host:'localhost',
        port:data.suggested_port||null, web_path:'', category:cat, description:''});
    else if (type === 'port')
      servers.push({name:data.name, unit:data.name.toLowerCase().replace(/\s+/g,'-'),
        runtime:'external', host:'localhost',
        port:data.port, category:cat, description:data.description||'', web_path:data.web_path||''});
  });
  try {
    const r = await fetch('/api/servers/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({servers})});
    const d = await r.json();
    toast(d.message||(d.ok?'Added':'Failed'), !!d.ok);
    if (d.ok){ closeWizard(); await fetchData(); await loadSettings(); }
  } catch(e){ toast('Request failed', false); }
}

function closeWizard(){
  document.getElementById('wizard').classList.remove('open');
  document.body.classList.remove('modal-open');
}

// Browse helper: add a file path to the config_files textarea
function openBrowserForConfigFiles(){
  const unit = _svcKey();
  const svc = DATA ? DATA.services.find(s => s.unit === unit) : null;
  let startPath = svc && svc.data_paths && svc.data_paths.length ? svc.data_paths[0] : '/opt/appdata';
  browserCallback = function(filepath){
    const ta = document.getElementById('svc_config_files');
    if (!ta) return;
    const lines = _linesToList(ta.value);
    if (!lines.includes(filepath)){ lines.push(filepath); }
    ta.value = lines.join('\n');
  };
  openBrowser(startPath);
}

function populateHiddenPicker(){
  const pick = document.getElementById('set_hidden_pick');
  if (!pick) return;
  pick.innerHTML = '';
  const hidden = new Set((SETTINGS && SETTINGS.dashboard && Array.isArray(SETTINGS.dashboard.hidden_units)) ? SETTINGS.dashboard.hidden_units : []);
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  for (const s of svcs){
    const opt = document.createElement('option');
    opt.value = s.unit;
    opt.textContent = `${s.name}  (${s.unit})`;
    if (hidden.has(s.unit)) opt.selected = true;
    pick.appendChild(opt);
  }
}

function _getHiddenSet(){
  const t = document.getElementById('set_hidden_units');
  const lines = (t && t.value != null) ? t.value.split(/\r?\n/) : [];
  const set = new Set();
  for (const raw of lines){
    const u = (raw || '').trim();
    if (u) set.add(u);
  }
  return set;
}

function _writeHiddenSetToUI(hidden){
  const t = document.getElementById('set_hidden_units');
  if (t) t.value = Array.from(hidden).sort().join('\n');
}

function populateHiddenPicker(){
  const visPick = document.getElementById('set_unhidden_pick');
  const hidPick = document.getElementById('set_hidden_pick');
  if (!visPick || !hidPick) return;

  visPick.innerHTML = '';
  hidPick.innerHTML = '';

  const hidden = _getHiddenSet();
  const svcs = (DATA && DATA.services) ? DATA.services : [];
  const sorted = svcs.slice().sort((a,b) => (a.name||'').localeCompare(b.name||''));

  for (const s of sorted){
    const opt = document.createElement('option');
    opt.value = s.unit;
    opt.textContent = `${s.name}  (${s.unit})`;
    if (hidden.has(s.unit)) hidPick.appendChild(opt);
    else visPick.appendChild(opt);
  }
}

function hideSelectedUnits(){
  const visPick = document.getElementById('set_unhidden_pick');
  if (!visPick) return;
  const hidden = _getHiddenSet();
  const selected = Array.from(visPick.selectedOptions || []).map(o => o.value);
  for (const u of selected) hidden.add(u);
  _writeHiddenSetToUI(hidden);
  populateHiddenPicker();
  toast(`Hidden ${selected.length} service(s)`, true);
}

function unhideSelectedUnits(){
  const hidPick = document.getElementById('set_hidden_pick');
  if (!hidPick) return;
  const hidden = _getHiddenSet();
  const selected = Array.from(hidPick.selectedOptions || []).map(o => o.value);
  for (const u of selected) hidden.delete(u);
  _writeHiddenSetToUI(hidden);
  populateHiddenPicker();
  toast(`Unhidden ${selected.length} service(s)`, true);
}

function clearHiddenUnits(){
  if (!confirm('Clear ALL hidden services?')) return;
  _writeHiddenSetToUI(new Set());
  populateHiddenPicker();
  toast('Hidden services cleared', true);
}

async function loadSettings() {
  try {
    const r = await fetch('/api/settings', { method:'GET' });
    const d = await r.json();
    if (!d.ok) { toast(d.error || 'Failed to load settings', false); return; }
    SETTINGS = d.settings || {};
    _ensureSettingsShape();

    document.getElementById('set_viewer_host').value = (SETTINGS.dashboard.viewer_host ?? 'auto') + '';
    document.getElementById('set_viewer_scheme').value = (SETTINGS.dashboard.viewer_scheme ?? 'http') + '';

    document.getElementById('set_default_url_mode').value = (SETTINGS.dashboard.default_url_mode ?? 'local') + '';
    document.getElementById('set_default_domain_suffix').value = (SETTINGS.dashboard.default_domain_suffix ?? 'sidneyshelton.com') + '';
    document.getElementById('set_default_domain_pattern').value = (SETTINGS.dashboard.default_domain_pattern ?? '{unit}.{suffix}') + '';

    refreshCategoryPickers();

    // Dashboard filters & safety
    const hs = document.getElementById('set_hide_stopped');
    const pd = document.getElementById('set_protect_dashboard');
    const hu = document.getElementById('set_hidden_units');
    if (hs) hs.checked = !!SETTINGS.dashboard.hide_stopped_services;
    if (pd) pd.checked = !!SETTINGS.dashboard.protect_dashboard_service;
    if (hu) hu.value = _listToLines(SETTINGS.dashboard.hidden_units);

    populateHiddenPicker();
    populateServicePicker();
    if (DATA && DATA.services && DATA.services.length){
      const pick = document.getElementById('svc_pick');
      if (pick && !pick.value) pick.value = DATA.services[0].unit;
    }
    onPickService();

    // Populate scan paths
    const spEl = document.getElementById('set_scan_paths');
    if (spEl && DATA && DATA.scan_paths){
      spEl.value = DATA.scan_paths.join('\n');
    }
  } catch(e) {
    toast('Settings request failed', false);
  }
}

function _applyUiToSettings(){
  _ensureSettingsShape();

  SETTINGS.dashboard.viewer_host = (document.getElementById('set_viewer_host').value || '').trim() || 'auto';
  SETTINGS.dashboard.viewer_scheme = (document.getElementById('set_viewer_scheme').value || 'http').trim();

  SETTINGS.dashboard.default_url_mode = (document.getElementById('set_default_url_mode')?.value || 'local').trim();
  SETTINGS.dashboard.default_domain_suffix = (document.getElementById('set_default_domain_suffix')?.value || 'sidneyshelton.com').trim();
  SETTINGS.dashboard.default_domain_pattern = (document.getElementById('set_default_domain_pattern')?.value || '{unit}.{suffix}').trim();

  // categories are edited in-memory; keep them in settings
  if (!SETTINGS.categories || typeof SETTINGS.categories !== 'object') SETTINGS.categories = {};

  // Dashboard filters & safety
  const hs = document.getElementById('set_hide_stopped');
  const pd = document.getElementById('set_protect_dashboard');
  const huText = document.getElementById('set_hidden_units');
  SETTINGS.dashboard.hide_stopped_services = hs ? !!hs.checked : false;
  SETTINGS.dashboard.protect_dashboard_service = pd ? !!pd.checked : true;
  // Prefer textarea (manual) if present; fall back to picker selection
  let hu = [];
  if (huText && huText.value != null) {
    hu = _linesToList(huText.value);
  } else {
    const pick = document.getElementById('set_hidden_pick');
    if (pick) hu = Array.from(pick.selectedOptions || []).map(o => o.value);
  }
  SETTINGS.dashboard.hidden_units = hu;


  const unit = _svcKey();
  if (!unit) return;

  if (!SETTINGS.services[unit] || typeof SETTINGS.services[unit] !== 'object') SETTINGS.services[unit] = {};
  const entry = SETTINGS.services[unit];

  entry.runtime          = (document.getElementById('svc_runtime')?.value || 'docker').trim();
  entry.docker_container = (document.getElementById('svc_docker_container')?.value || '').trim() || unit;
  entry.host             = (document.getElementById('svc_host')?.value || 'localhost').trim() || 'localhost';

  const portRaw = (document.getElementById('svc_port').value || '').trim();
  entry.port = portRaw ? parseInt(portRaw, 10) : null;

  const wp = (document.getElementById('svc_web_path').value || '').trim();
  entry.web_path = wp;

  // URL + category per service
  entry.scheme = (document.getElementById('svc_scheme')?.value || '').trim();
  entry.url_mode = (document.getElementById('svc_url_mode')?.value || '').trim();
  entry.domain = (document.getElementById('svc_domain')?.value || '').trim();
  entry.url_override = (document.getElementById('svc_url_override')?.value || '').trim();
  entry.category = (document.getElementById('svc_category')?.value || entry.category || '').trim() || entry.category || 'home';

  entry.config_files = _linesToList(document.getElementById('svc_config_files').value);
  entry.data_paths   = _linesToList(document.getElementById('svc_data_paths').value);
  entry.volume_maps  = _linesToList(document.getElementById('svc_volume_maps')?.value || '');

  if (unit === 'kiwix'){
    entry.kiwix_zim_dir    = (document.getElementById('svc_kiwix_zim_dir').value || '').trim();
    entry.kiwix_library_xml = (document.getElementById('svc_kiwix_library_xml').value || '').trim();
  }
}

async function saveAllSettings() {
  try {
    _applyUiToSettings();
    const payload = { settings: SETTINGS };
    const r = await fetch('/api/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await r.json();
    toast(d.message || (d.ok ? 'Saved' : 'Save failed'), !!d.ok);
    if (d.ok) {
      SETTINGS = d.settings || SETTINGS;
      await loadSettings();
    }
  } catch(e) {
    toast('Save request failed', false);
  }
}

async function autoDetectSelected() {
  try {
    const unit = _svcKey();
    if (!unit) { toast('Select a service first', false); return; }
    const r = await fetch('/api/settings/autodetect', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ unit, apply: true }) });
    const d = await r.json();
    toast(d.ok ? 'Auto-detect applied' : (d.message || 'Auto-detect failed'), !!d.ok);
    if (d.ok) await loadSettings();
  } catch(e) {
    toast('Auto-detect request failed', false);
  }
}

async function autoDetectAll() {
  try {
    const r = await fetch('/api/settings/autodetect', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ all: true, apply: true }) });
    const d = await r.json();
    toast(d.ok ? 'Auto-detect applied to all' : (d.message || 'Auto-detect failed'), !!d.ok);
    if (d.ok) await loadSettings();
  } catch(e) {
    toast('Auto-detect request failed', false);
  }
}

// ── System Files (Settings > General System Files panel) ─────────────────
function renderSystemFiles() {
  const grid = document.getElementById('sysfiles-grid');
  if (!grid) return;
  const files = (DATA && DATA.system_files) ? DATA.system_files : [];
  if (!files.length) {
    grid.innerHTML = '<span style="color:var(--text2);font-size:12px;">No system files configured.</span>';
    return;
  }
  grid.innerHTML = files.map(f => `
    <button class="sysfile-btn" onclick="openSystemFileEditor('${f.path}', '${f.label}')">
      <span class="sysfile-icon">📄</span>
      <span><span class="sysfile-label">${f.label}</span><span class="sysfile-path">${f.path}</span></span>
    </button>`).join('');
}

function openSystemFileEditor(filepath, label) {
  currentEditorUnit = '__system__';
  document.getElementById('etitle').textContent = label || filepath.split('/').pop();
  const filesDiv = document.getElementById('efiles');
  filesDiv.innerHTML = `<button class="file-tab active" onclick="loadFile('${filepath}',this)">${filepath.split('/').pop()}</button>
    <button class="file-tab browse" onclick="openBrowserForSysFile()">📁 Browse /etc…</button>`;
  document.getElementById('editor').classList.add('open');
  _syncModalClass();
  loadFile(filepath, filesDiv.querySelector('.file-tab'));
}

function openBrowserForSysFile() {
  browserCallback = function(filepath) {
    const label = filepath.split('/').pop();
    openSystemFileEditor(filepath, label);
  };
  openBrowser('/etc');
}

// ── End System Files ──────────────────────────────────────────────────────

// Viewer
function _syncModalClass(){
  const v = document.getElementById('viewer');
  const e = document.getElementById('editor');
  const b = document.getElementById('browser');
  const open = (v && v.classList.contains('open')) || (e && e.classList.contains('open')) || (b && b.classList.contains('open'));
  document.body.classList.toggle('modal-open', !!open);
}
function _viewerSetBlocked(isBlocked, reason, url){
  const fr = document.getElementById('vframe');
  const blk = document.getElementById('vblocked');
  const r = document.getElementById('vblocked_reason');
  const o = document.getElementById('vblocked_open');
  if(!fr || !blk) return;
  if(isBlocked){
    try{ fr.src = ''; }catch(e){}
    fr.style.display = 'none';
    blk.style.display = 'block';
    if(r) r.textContent = reason || 'This site blocks iframe embedding (X-Frame-Options / Content-Security-Policy).';
    if(o && url){ o.href = url; }
  }else{
    blk.style.display = 'none';
    fr.style.display = 'block';
  }
}

async function _viewerCheckEmbeddable(url){
  try{
    const res = await fetch('/api/embed_check?url=' + encodeURIComponent(url));
    if(!res.ok) return {embeddable: true};
    return await res.json();
  }catch(e){
    return {embeddable: true};
  }
}

let _lastViewer = {name:'', url:''};

async function openViewer(name, url) {
  _lastViewer = {name, url};

  // IMPORTANT:
  // To avoid popup blockers, pre-open a tab synchronously (user click) and only use it
  // if embedding is blocked. If embedding is allowed, we immediately close it.
  let pop = null;
  try { pop = window.open('about:blank', '_blank'); } catch(e) { pop = null; }
  const popOk = !!pop;

  document.getElementById('vtitle').textContent = name;
  document.getElementById('vurl').textContent = url;
  document.getElementById('vext').href = url;

  // default: try embed
  _viewerSetBlocked(false, '', url);
  const fr = document.getElementById('vframe');
  if(fr){
    fr.src = url;
  }

  document.getElementById('viewer').classList.add('open');
  _syncModalClass();

  // Option A: if server says it can't be embedded, auto-open in a new tab
  const chk = await _viewerCheckEmbeddable(url);
  if(chk && chk.embeddable === false){
    // If we were able to open a pop-up, use it; otherwise show the fallback panel with a manual button.
    if(popOk){
      try { pop.location = url; } catch(e){}
      try { toast('This service blocks embedding — opened in a new tab.', true); } catch(e){}
      closeViewer();
      return;
    } else {
      _viewerSetBlocked(true, chk.reason || 'Embedding blocked by the service.', url);
      return;
    }
  }

  // Embedding is allowed: close the pre-opened tab if it exists
  if(popOk){
    try { pop.close(); } catch(e){}
  }
}

function retryViewerEmbed(){
  if(!_lastViewer || !_lastViewer.url) return;
  // force another attempt
  const url = _lastViewer.url;
  _viewerSetBlocked(false, '', url);
  const fr = document.getElementById('vframe');
  if(fr){ fr.src = url; }
}

function closeViewer() {
  document.getElementById('viewer').classList.remove('open');
  _syncModalClass();
  const fr = document.getElementById('vframe');
  if(fr) fr.src = '';
  _viewerSetBlocked(false, '', '');
}

function closeViewer() {
  document.getElementById('viewer').classList.remove('open');
  _syncModalClass();
  document.getElementById('vframe').src = '';
}

// Editor
async function openEditor(unit) {
  const svc = DATA.services.find(s => s.unit === unit);
  if (!svc) { toast('Service not found', false); return; }
  
  currentEditorUnit = unit;
  document.getElementById('etitle').textContent = svc.name + ' Config';
  try { editorLoadServiceSettings(unit); } catch(e) { console.error(e); }
  try { const b=document.getElementById('es_body'); const h=document.getElementById('es_hdr'); if(b&&h){ b.classList.add('open'); h.classList.add('open'); } } catch(e) {}
  const filesDiv = document.getElementById('efiles');
  
  // Check if we have config files defined
  if (!svc.config_files || svc.config_files.length === 0) {
    // No config files - show browser button
    filesDiv.innerHTML = `
      <span style="color:var(--text2);font-size:11px;">No config files defined.</span>
      <button class="file-tab browse" onclick="openBrowserForEditor('${unit}')">📁 Browse for file...</button>
    `;
    document.getElementById('etext').value = '';
    document.getElementById('epath').textContent = 'No file selected';
    document.getElementById('estatus').textContent = 'Use Browse to find a config file, or add paths in Settings.';
    document.getElementById('editor').classList.add('open');
    _syncModalClass();
    return;
  }
  
  // Build file tabs with browse option
  let tabsHtml = svc.config_files.map((f,i) =>
    `<button class="file-tab ${i===0?'active':''}" onclick="loadFile('${f}',this)">${f.split('/').pop()}</button>`
  ).join('');
  tabsHtml += `<button class="file-tab browse" onclick="openBrowserForEditor('${unit}')">📁 Browse...</button>`;
  filesDiv.innerHTML = tabsHtml;
  
  document.getElementById('editor').classList.add('open');
    _syncModalClass();
  await loadFile(svc.config_files[0], filesDiv.querySelector('.file-tab'));
}

async function loadFile(filepath, tabEl) {
  currentEditorFile = filepath;
  document.querySelectorAll('.file-tab').forEach(e => e.classList.remove('active'));
  if (tabEl) tabEl.classList.add('active');
  document.getElementById('epath').textContent = filepath;
  document.getElementById('estatus').textContent = 'Loading...';
  try {
    const r = await fetch('/api/config?path=' + encodeURIComponent(filepath));
    const d = await r.json();
    if (d.ok) {
      document.getElementById('etext').value = d.content;
      updateLineCount();
      document.getElementById('estatus').textContent = 'Loaded';
    } else {
      document.getElementById('etext').value = '';
      document.getElementById('estatus').innerHTML = `<span class="error">${d.error}</span>`;
    }
  } catch(e) {
    document.getElementById('estatus').innerHTML = '<span class="error">Failed to load</span>';
  }
}

async function saveFile() {
  if (!currentEditorFile) { toast('No file selected', false); return; }
  const content = document.getElementById('etext').value;
  document.getElementById('estatus').textContent = 'Saving...';
  try {
    const r = await fetch('/api/config', { method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({path:currentEditorFile, content}) });
    const d = await r.json();
    if (d.ok) {
      document.getElementById('estatus').innerHTML = '<span class="saved">✓ Saved (backup created)</span>';
      toast('File saved', true);
    } else {
      document.getElementById('estatus').innerHTML = `<span class="error">${d.error}</span>`;
      toast(d.error, false);
    }
  } catch(e) { toast('Save failed', false); }
}

function closeEditor() {
  document.getElementById('editor').classList.remove('open');
  _syncModalClass();
  currentEditorFile = null; currentEditorUnit = null;
}

function updateLineCount() {
  const t = document.getElementById('etext');
  const lines = t.value.split('\n').length;
  document.getElementById('elines').textContent = lines + ' lines';
}

// File Browser
function openBrowserForEditor(unit) {
  // Start browser in the service's own appdata dir if it exists, else /opt/appdata
  const svc = DATA ? DATA.services.find(s => s.unit === unit) : null;
  let startPath = '/opt/appdata';
  if (svc && svc.data_paths && svc.data_paths.length > 0) {
    startPath = svc.data_paths[0];
  }
  browserCallback = function(filepath) {
    // Add the file to the config and load it
    loadFile(filepath, null);
    // Also add a new tab for it
    const filesDiv = document.getElementById('efiles');
    const filename = filepath.split('/').pop();
    const newTab = document.createElement('button');
    newTab.className = 'file-tab active';
    newTab.textContent = filename;
    newTab.onclick = function() { loadFile(filepath, newTab); };
    // Insert before browse button
    const browseBtn = filesDiv.querySelector('.browse');
    filesDiv.insertBefore(newTab, browseBtn);
  };
  openBrowser(startPath);
}

async function openBrowser(startPath) {
  document.getElementById('browser').classList.add('open');
  _syncModalClass();
  document.getElementById('binput').value = startPath || '/opt';
  await loadBrowserDir(startPath || '/opt');
}

async function loadBrowserDir(path) {
  document.getElementById('bpath').textContent = path;
  document.getElementById('binput').value = path;
  document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--text2);">Loading...</div>';
  
  try {
    const r = await fetch('/api/browse?path=' + encodeURIComponent(path));
    const d = await r.json();
    if (!d.ok) {
      document.getElementById('blist').innerHTML = `<div style="padding:20px;color:var(--red);">${d.error}</div>`;
      return;
    }
    
    const items = d.data.items || [];
    if (items.length === 0) {
      document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--text2);">Empty directory</div>';
      return;
    }
    
    let html = '';
    items.forEach(item => {
      if (item.type === 'dir') {
        html += `<div class="browser-item dir" onclick="loadBrowserDir('${item.path}')">${ICO.folder} ${item.name}</div>`;
      } else {
        html += `<div class="browser-item file" onclick="selectBrowserFile('${item.path}')">${ICO.file} ${item.name}</div>`;
      }
    });
    document.getElementById('blist').innerHTML = html;
  } catch(e) {
    document.getElementById('blist').innerHTML = '<div style="padding:20px;color:var(--red);">Failed to load directory</div>';
  }
}

function selectBrowserFile(filepath) {
  document.getElementById('binput').value = filepath;
  selectBrowserPath();
}

function selectBrowserPath() {
  const path = document.getElementById('binput').value.trim();
  if (!path) { toast('Enter a path', false); return; }
  closeBrowser();
  if (browserCallback) {
    browserCallback(path);
    browserCallback = null;
  }
}

function closeBrowser() {
  document.getElementById('browser').classList.remove('open');
  _syncModalClass();
}

// Logs
function buildLogList() {
  if (!DATA) return;
  const el = document.getElementById('jlist');
  const svcs = DATA.services.filter(s => s.status === 'active');
  if (svcs.length === 0) {
    el.innerHTML = '<div style="color:var(--text2);padding:8px;">No active services</div>';
    return;
  }
  el.innerHTML = svcs.map(s => `<button class="jbtn" onclick="fetchLog('${s.unit}',this)">${s.name}</button>`).join('');
}

async function fetchLog(unit, btn) {
  document.querySelectorAll('.jbtn').forEach(e => e.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById('jout').textContent = 'Loading...';
  try {
    const r = await fetch('/api/logs?unit=' + encodeURIComponent(unit));
    const d = await r.json();
    document.getElementById('jout').textContent = d.logs || 'No logs available';
  } catch(e) { document.getElementById('jout').textContent = 'Failed to fetch logs'; }
}

// Data
async function fetchData() {
  try {
    const r = await fetch('/api/status');
    DATA = await r.json();
    renderSys(DATA.system);
    renderSvc(DATA.services, DATA.categories);
    renderSystemFiles();
    if (DATA.app && DATA.app.version) {
      const vEl = document.getElementById('appver');
      if (vEl) vEl.textContent = 'v' + DATA.app.version;
    }
    const total = DATA.services.length, active = DATA.services.filter(s=>s.status==='active').length;
    const tmem = DATA.services.reduce((a,s) => a+(s.memory_mb||0), 0);
    document.getElementById('fsum').textContent = `${active}/${total} services active · ${tmem.toFixed(0)} MB total`;
    document.getElementById('fupd').textContent = 'Updated: ' + new Date(DATA.timestamp).toLocaleTimeString();
  } catch(e) { 
    console.error('Fetch error:', e);
    document.getElementById('fsum').textContent = 'Error loading data';
  }
}

function tick() {
  document.getElementById('clock').textContent = new Date().toLocaleTimeString();
  countdown--;
  if (countdown <= 0) { countdown = 30; fetchData(); }
  document.getElementById('rtimer').textContent = countdown + 's';
}

// Escape key closes overlays
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeViewer(); closeEditor(); closeBrowser(); }
});

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('etext').addEventListener('input', updateLineCount);
  // Tab key support in editor
  document.getElementById('etext').addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = this.selectionStart, end = this.selectionEnd;
      this.value = this.value.substring(0,s) + '    ' + this.value.substring(end);
      this.selectionStart = this.selectionEnd = s + 4;
    }
  });
});

fetchData();
tick();
setInterval(tick, 1000);

async function applyBulkEdits(){
  _ensureSettingsShape();
  refreshCategoryPickers();

  const scope = document.getElementById('bulk_scope')?.value || 'all';
  const scopeCat = document.getElementById('bulk_scope_category')?.value || '';
  const scheme = (document.getElementById('bulk_scheme')?.value || '').trim();
  const urlMode = (document.getElementById('bulk_url_mode')?.value || '').trim();
  const newCat = (document.getElementById('bulk_category')?.value || '').trim();

  // Optional: update dashboard defaults from bulk inputs (common use-case)
  const ds = (document.getElementById('bulk_domain_suffix')?.value || '').trim();
  const dp = (document.getElementById('bulk_domain_pattern')?.value || '').trim();
  if (ds) SETTINGS.dashboard.default_domain_suffix = ds;
  if (dp) SETTINGS.dashboard.default_domain_pattern = dp;

  let changed = 0;
  for (const unit of Object.keys(SETTINGS.services || {})){
    const entry = SETTINGS.services[unit];
    if (!entry || typeof entry !== 'object') continue;
    if (scope === 'category' && scopeCat && (entry.category || '') !== scopeCat) continue;

    if (scheme !== '') entry.scheme = scheme;
    if (urlMode !== '') entry.url_mode = urlMode;
    if (newCat !== '') entry.category = newCat;

    changed++;
  }
  toast(`Bulk edits applied to ${changed} service entries (click Save).`, true);
  onPickService();
}

async function addCategory(){
  _ensureSettingsShape();
  const key = (document.getElementById('cat_key')?.value || '').trim();
  const label = (document.getElementById('cat_label')?.value || '').trim();
  const icon = (document.getElementById('cat_icon')?.value || '').trim();

  if (!key){
    toast('Category key is required (e.g. books)', false);
    return;
  }
  if (!SETTINGS.categories || typeof SETTINGS.categories !== 'object') SETTINGS.categories = {};
  SETTINGS.categories[key] = { label: label || key, icon: icon || '🧩' };
  refreshCategoryPickers();

  toast(`Category '${key}' added/updated (click Save).`, true);
}

</script>
</body>
</html>"""



# ── Embed safety + iframe detection (Option A) ─────────────────────────────
_PRIVATE_IP_RE = re.compile(r'^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)')

def _is_safe_embed_target(url: str) -> bool:
    try:
        u = urllib.parse.urlparse(url)
        if u.scheme not in ("http", "https"):
            return False
        host = (u.hostname or "").strip().lower()
        if not host:
            return False
        if host in ("localhost", "127.0.0.1"):
            return True
        if host.endswith(".sidneyshelton.com") or host == "sidneyshelton.com":
            return True
        if _PRIVATE_IP_RE.match(host):
            return True
        return False
    except Exception:
        return False

def _check_iframe_block_headers(url: str) -> dict:
    """Return {embeddable: bool, reason: str}. Best-effort only."""
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "server-dashboard/iframe-check"})
        with urllib.request.urlopen(req, timeout=4) as resp:
            hdrs = {k.lower(): v for k, v in resp.headers.items()}
    except Exception as e:
        # If we can't check, assume embeddable and let the browser decide.
        return {"embeddable": True, "reason": f"Header check failed: {e}"}

    xfo = (hdrs.get("x-frame-options") or "").strip()
    if xfo:
        low = xfo.lower()
        if "deny" in low:
            return {"embeddable": False, "reason": f"Blocked by X-Frame-Options: {xfo}"}
        if "sameorigin" in low:
            return {"embeddable": False, "reason": f"Blocked by X-Frame-Options: {xfo}"}
        if "allow-from" in low and "sidneyshelton.com" not in low:
            return {"embeddable": False, "reason": f"Blocked by X-Frame-Options: {xfo}"}

    csp = (hdrs.get("content-security-policy") or "").strip()
    if csp and "frame-ancestors" in csp.lower():
        cl = csp.lower()
        # Extract the frame-ancestors directive (simple parse)
        try:
            i = cl.index("frame-ancestors")
            seg = cl[i:]
            seg = seg.split(";")[0]
        except Exception:
            seg = cl
        # If it explicitly allows all, good.
        if "*" in seg:
            return {"embeddable": True, "reason": "frame-ancestors allows *"}
        # If it only allows self, it will fail when embedded from another origin.
        if "'self'" in seg and "sidneyshelton.com" not in seg and "serverdashboard.sidneyshelton.com" not in seg:
            return {"embeddable": False, "reason": "Blocked by Content-Security-Policy frame-ancestors (self only)"}
        # If frame-ancestors is present but doesn't mention our domain, assume blocked.
        if "sidneyshelton.com" not in seg and "serverdashboard.sidneyshelton.com" not in seg:
            return {"embeddable": False, "reason": "Blocked by Content-Security-Policy frame-ancestors"}
    return {"embeddable": True, "reason": ""}

class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)

        if parsed.path == '/api/embed_check':
            url = qs.get('url', [None])[0]
            if not url:
                self._json(400, json.dumps({"ok": False, "error": "Missing url"}))
                return
            if not _is_safe_embed_target(url):
                self._json(400, json.dumps({"ok": False, "error": "Blocked target"}))
                return
            res = _check_iframe_block_headers(url)
            self._json(200, json.dumps({"ok": True, "embeddable": bool(res.get("embeddable", True)), "reason": res.get("reason","")}))
        elif parsed.path == '/api/status':

            self._json(200, build_api_response())
        elif parsed.path == '/api/config':
            path = qs.get('path', [None])[0]
            if not path:
                self._json(400, json.dumps({"ok": False, "error": "No path"}))
                return
            content, err = read_config_file(path)
            if err:
                self._json(200, json.dumps({"ok": False, "error": err}))
            else:
                self._json(200, json.dumps({"ok": True, "content": content}))
        elif parsed.path == '/api/logs':
            unit = qs.get('unit', [None])[0]
            if not unit:
                self._json(400, json.dumps({"logs": "No unit specified"}))
                return
            s = load_settings()
            all_units = set((s.get("services", {}) or {}).keys())
            if unit not in all_units:
                self._json(400, json.dumps({"logs": "Unknown unit"}))
                return
            logs, _ = run_cmd(f"docker logs --tail 100 --timestamps {unit} 2>&1", timeout=10)
            self._json(200, json.dumps({"logs": logs}))
        elif parsed.path == '/api/scan':
            self._json(200, json.dumps({
                "ok": True,
                "results": {
                    "docker":  _scan_docker(),
                    "systemd": _scan_systemd(),
                    "ports":   _scan_ports(),
                }
            }))
        elif parsed.path == '/api/settings':
            s = load_settings()
            self._json(200, json.dumps({"ok": True, "settings": s}))
        elif parsed.path == '/api/browse':
            path = qs.get('path', ['/opt'])[0]
            data, err = browse_directory(path)
            if err:
                self._json(200, json.dumps({"ok": False, "error": err}))
            else:
                self._json(200, json.dumps({"ok": True, "data": data}))
        elif parsed.path == '/' or parsed.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode())
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        if parsed.path == '/api/control':
            unit = body.get('unit', '')
            action = body.get('action', '')
            ok, msg = service_control(unit, action)
            self._json(200, json.dumps({"ok": ok, "message": msg}))
        elif parsed.path == '/api/config':
            path = body.get('path', '')
            content = body.get('content', '')
            ok, msg = write_config_file(path, content)
            self._json(200, json.dumps({"ok": ok, "message": msg, "error": "" if ok else msg}))
        elif parsed.path == '/api/servers/add':
            servers = body.get("servers", [])
            if not isinstance(servers, list) or not servers:
                self._json(400, json.dumps({"ok": False, "message": "No servers provided"}))
                return
            added = add_services_to_settings(servers)
            msg = f"Added {len(added)}: {', '.join(added)}" if added else "Nothing added"
            self._json(200, json.dumps({"ok": bool(added), "message": msg, "added": added}))
        elif parsed.path == '/api/bootstrap':
            mode = str(body.get("mode","embedded")).strip()
            if mode not in ("embedded","blank"):
                self._json(400, json.dumps({"ok":False,"message":"mode must be embedded or blank"}))
                return
            ok, msg = bootstrap_settings(mode)
            self._json(200, json.dumps({"ok": ok, "message": msg}))
        elif parsed.path == '/api/settings':
            if isinstance(body, dict) and isinstance(body.get("settings"), dict):
                new_s = body.get("settings")
            else:
                new_s = load_settings()
                if "viewer_host" in body:
                    new_s["dashboard"]["viewer_host"] = str(body.get("viewer_host", "")).strip()
                if "kiwix_zim_dir" in body:
                    new_s["services"]["kiwix"]["kiwix_zim_dir"] = str(body.get("kiwix_zim_dir", "")).strip()
                if "kiwix_library_xml" in body:
                    new_s["services"]["kiwix"]["kiwix_library_xml"] = str(body.get("kiwix_library_xml", "")).strip()

            ok, msg = save_settings(new_s)
            self._json(200, json.dumps({"ok": ok, "message": msg, "settings": load_settings()}))

        elif parsed.path == '/api/settings/autodetect':
            s = load_settings()
            svc = s.get("services", {})
            detected = {}

            if body.get("all"):
                units = list(svc.keys())
            else:
                unit = str(body.get("unit", "")).strip()
                units = [unit] if unit else []

            units = [u for u in units if u in svc]

            if not units:
                self._json(400, json.dumps({"ok": False, "message": "No valid unit specified"}))
                return

            for u in units:
                detected[u] = _autodetect_service(u, svc.get(u, {}))

            if body.get("apply", True):
                for u, entry in detected.items():
                    if u in s["services"]:
                        s["services"][u].update(entry)
                save_settings(s)

            self._json(200, json.dumps({"ok": True, "detected": detected, "settings": load_settings()}))
        elif parsed.path == '/api/kiwix/refresh':
            ok, msg, details = refresh_kiwix_library()
            self._json(200, json.dumps({"ok": ok, "message": msg, "details": details}))
        else:
            self.send_response(404)
            self.end_headers()

    def _json(self, code, data):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        if isinstance(data, str):
            self.wfile.write(data.encode())
        else:
            self.wfile.write(data)


def main():
    port = 8029
    server = HTTPServer(('0.0.0.0', port), DashboardHandler)
    print(f"SidscriServer Dashboard running at http://0.0.0.0:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.server_close()



# _PERF_PATCH_V1
_DOCKER_STATS_CACHE = {"ts": 0.0, "data": {}}
_API_STATUS_CACHE = {"ts": 0.0, "payload": None}

def _parse_mem_to_mb_perf(mem_used_text):
    try:
        used = str(mem_used_text).strip()
        val = float(''.join(c for c in used if c.isdigit() or c == '.'))
        u = used.upper()
        if "GIB" in u or "GB" in u:
            return val * 1024
        if "KIB" in u or "KB" in u:
            return val / 1024
        return val
    except Exception:
        return None

def _get_docker_stats_snapshot_perf(ttl=4, timeout=4):
    now = time.time()
    if (now - _DOCKER_STATS_CACHE.get("ts", 0.0)) < ttl and isinstance(_DOCKER_STATS_CACHE.get("data"), dict):
        return _DOCKER_STATS_CACHE["data"]

    out, rc = run_cmd("docker stats --no-stream --format '{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}' 2>/dev/null", timeout=timeout)
    stats = {}
    if rc == 0 and out and out.strip():
        for line in out.splitlines():
            parts = line.split("|", 2)
            if len(parts) != 3:
                continue
            name, cpu_txt, mem_txt = [x.strip() for x in parts]
            try:
                cpu_val = float(cpu_txt.replace("%","")) if cpu_txt else None
            except Exception:
                cpu_val = None
            mem_used = mem_txt.split("/", 1)[0].strip()
            mem_mb = _parse_mem_to_mb_perf(mem_used)
            stats[name] = {"cpu_pct": cpu_val, "memory_mb": mem_mb}

    _DOCKER_STATS_CACHE["ts"] = now
    _DOCKER_STATS_CACHE["data"] = stats
    return stats

# Override for speed (preserves docker_container mapping)
def get_service_memory(unit, runtime="docker"):
    if runtime != "docker":
        return None
    target = _docker_target_for_unit(unit)
    item = _get_docker_stats_snapshot_perf().get(target)
    return None if not item else item.get("memory_mb")

def get_service_cpu(unit, runtime="docker"):
    if runtime != "docker":
        return None
    target = _docker_target_for_unit(unit)
    item = _get_docker_stats_snapshot_perf().get(target)
    return None if not item else item.get("cpu_pct")

# Faster status checks (short timeout)
def get_service_status(unit, runtime="docker"):
    if runtime == "systemd":
        out, rc = run_cmd(f"systemctl is-active {unit} 2>/dev/null", timeout=2)
        s = out.strip()
        return "active" if s == "active" else ("inactive" if s in ("inactive","failed") else "unknown")
    elif runtime == "external":
        return "unknown"
    else:
        target = _docker_target_for_unit(unit)
        out, rc = run_cmd(f"docker inspect --format='{{{{.State.Status}}}}' {target} 2>/dev/null", timeout=2)
        status = out.strip().strip("'")
        if status == "running": return "active"
        if status in ("exited","dead","removing"): return "inactive"
        if status in ("paused","restarting","created"): return status
        return "unknown"

# Cache the full API payload briefly so UI polls don't rebuild everything
def build_api_response():
    now = time.time()
    if _API_STATUS_CACHE.get("payload") is not None and (now - _API_STATUS_CACHE.get("ts", 0.0)) < 5:
        return _API_STATUS_CACHE["payload"]

    s = load_settings()
    payload = json.dumps({
        "app": read_app_version() if "read_app_version" in globals() else {"version":"","release_date":"","codename":""},
        "system": get_system_info(),
        "services": get_service_data(s),
        "categories": CATEGORY_META,
        "settings": s,
        "system_files": SYSTEM_FILES if "SYSTEM_FILES" in globals() else [],
        "scan_paths": s.get("bootstrap", {}).get("scan_paths", []),
        "timestamp": datetime.now().isoformat(),
    })
    _API_STATUS_CACHE["ts"] = now
    _API_STATUS_CACHE["payload"] = payload
    return payload


if __name__ == '__main__':
    main()
