#!/usr/bin/env python3
"""
SidscriServer Dashboard v2.2.1
- Real-time system & Docker container monitoring
- Start / Stop / Restart buttons (via docker CLI)
- Built-in iframe service viewer
- Config file editor GUI with browse fallback
- Kiwix library refresh
Runs on port 8029
"""

import subprocess
import json
import os
import re
import urllib.parse
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
import shutil
import time
import mimetypes

# ─── Service Definitions ───
# (name, unit, port, category, description, web_path, config_files)
# web_path=None means no web UI, web_path="" means root
SERVICES = [
    # Media
    # config_files = service-specific app config + its own systemd unit file only.
    # System-wide /etc files (fstab, smb.conf, etc) live in Settings > System Files.
    ("Plex", "plexmediaserver", 32400, "media", "Media Server", "/web", [
        "/etc/systemd/system/plexmediaserver.service",
    ]),
    ("Navidrome", "navidrome", 4533, "media", "Music Streaming", "", [
        "/opt/appdata/navidrome/navidrome.toml",
        "/etc/systemd/system/navidrome.service",
    ]),
    ("Kiwix", "kiwix", 8090, "media", "Offline Wikipedia", "", [
        "/etc/systemd/system/kiwix.service",
    ]),
    ("MPD Local", "mpd", 6600, "media", "Music Player (Local)", None, [
        "/etc/mpd.conf",
        "/etc/systemd/system/mpd.service",
    ]),
    ("MPD Stream", "mpd-stream", 6601, "media", "Music Player (HTTP Stream)", None, [
        "/etc/mpd-stream.conf",
        "/etc/systemd/system/mpd-stream.service",
    ]),
    ("ympd Local", "ympd-local", 8586, "media", "MPD Web UI (Local)", "", [
        "/etc/systemd/system/ympd-local.service",
    ]),
    ("ympd Stream", "ympd-stream", 8587, "media", "MPD Web UI (Stream)", "", [
        "/etc/systemd/system/ympd-stream.service",
    ]),

    # *arr Stack
    ("Sonarr A", "sonarr-a", 8989, "arr", "TV Shows (A)", "", [
        "/opt/appdata/sonarr-a/config/config.xml",
        "/etc/systemd/system/sonarr-a.service",
    ]),
    ("Sonarr B", "sonarr-b", 8990, "arr", "TV Shows (B)", "", [
        "/opt/appdata/sonarr-b/config/config.xml",
        "/etc/systemd/system/sonarr-b.service",
    ]),
    ("Radarr A", "radarr-a", 7878, "arr", "Movies (A)", "", [
        "/opt/appdata/radarr-a/config/config.xml",
        "/etc/systemd/system/radarr-a.service",
    ]),
    ("Radarr B", "radarr-b", 7879, "arr", "Movies (B)", "", [
        "/opt/appdata/radarr-b/config/config.xml",
        "/etc/systemd/system/radarr-b.service",
    ]),
    ("Lidarr B", "lidarr-b", 8687, "arr", "Music (B)", "", [
        "/opt/appdata/lidarr-b/config/config.xml",
        "/etc/systemd/system/lidarr-b.service",
    ]),
    ("Readarr A", "readarr-a", 8787, "arr", "Books (A)", "", [
        "/opt/appdata/readarr-a/config/config.xml",
        "/etc/systemd/system/readarr-a.service",
    ]),
    ("Readarr B", "readarr-b", 8788, "arr", "Books (B)", "", [
        "/opt/appdata/readarr-b/config/config.xml",
        "/etc/systemd/system/readarr-b.service",
    ]),
    ("Readarr Audiobooks A", "readarr-audiobooks-a", 8789, "arr", "Audiobooks (A)", "", [
        "/opt/appdata/readarr-audiobooks-a/config/config.xml",
        "/etc/systemd/system/readarr-audiobooks-a.service",
    ]),
    ("Readarr Audiobooks B", "readarr-audiobooks-b", 8790, "arr", "Audiobooks (B)", "", [
        "/opt/appdata/readarr-audiobooks-b/config/config.xml",
        "/etc/systemd/system/readarr-audiobooks-b.service",
    ]),
    ("Prowlarr A", "prowlarr-a", 9696, "arr", "Indexer Manager (A)", "", [
        "/opt/appdata/prowlarr-a/config/config.xml",
        "/etc/systemd/system/prowlarr-a.service",
    ]),
    ("Prowlarr B", "prowlarr-b", 9697, "arr", "Indexer Manager (B)", "", [
        "/opt/appdata/prowlarr-b/config/config.xml",
        "/etc/systemd/system/prowlarr-b.service",
    ]),

    # Downloads
    ("Deluge Daemon", "deluged", 58846, "downloads", "Torrent Daemon", None, [
        "/etc/systemd/system/deluged.service",
    ]),
    ("Deluge Web", "deluge-web", 8112, "downloads", "Torrent Web UI", "", [
        "/etc/systemd/system/deluge-web.service",
    ]),
    ("SABnzbd", "sabnzbd", 8095, "downloads", "Usenet Downloader", "", [
        "/etc/systemd/system/sabnzbd.service",
    ]),

    # TV / DVR
    ("xTeVe A", "xteve-a", 34400, "tv", "IPTV Proxy (A)", "/web", [
        "/etc/systemd/system/xteve-a.service",
    ]),
    ("xTeVe B", "xteve-b", 34401, "tv", "IPTV Proxy (B)", "/web", [
        "/etc/systemd/system/xteve-b.service",
    ]),

    # Home & Apps
    ("Home Assistant", "homeassistant", 8123, "home", "Home Automation", "", [
        "/opt/appdata/homeassistant/config/configuration.yaml",
        "/etc/systemd/system/homeassistant.service",
    ]),
    ("Adv. Flashcards", "advanced-flashcards", 8009, "home", "Flashcards Web Server", "", [
        "/etc/systemd/system/advanced-flashcards.service",
    ]),

    # System — service-specific configs only; smb.conf is in Settings > System Files
    ("SSH", "ssh", 22, "system", "Secure Shell", None, [
        "/etc/ssh/sshd_config",
        "/etc/systemd/system/ssh.service",
    ]),
    ("Samba", "smbd", 445, "system", "File Sharing", None, [
        # smb.conf is a system-wide file → Settings > System Files
        "/etc/systemd/system/smbd.service",
    ]),
    ("xRDP", "xrdp", 3389, "system", "Remote Desktop", None, [
        "/etc/xrdp/xrdp.ini",
        "/etc/systemd/system/xrdp.service",
    ]),
    ("CUPS", "cups", 631, "system", "Printing", "", [
        "/etc/systemd/system/cups.service",
    ]),
    ("Bluetooth", "bluetooth", None, "system", "Bluetooth Service", None, [
        "/etc/bluetooth/main.conf",
        "/etc/systemd/system/bluetooth.service",
    ]),
    ("Server Dashboard", "server-dashboard", 8029, "system", "This Dashboard", "", [
        "/opt/app/server-dashboard/server.py",
        "/etc/systemd/system/server-dashboard.service",
    ]),
]

CATEGORY_META = {
    "media":     {"label": "Media", "icon": "🎬"},
    "arr":       {"label": "Arr Stack", "icon": "📡"},
    "downloads": {"label": "Downloads", "icon": "⬇️"},
    "tv":        {"label": "TV / DVR", "icon": "📺"},
    "home":      {"label": "Home & Apps", "icon": "🏠"},
    "system":    {"label": "System", "icon": "⚙️"},
}

# Safety: only allow editing files under these paths
ALLOWED_EDIT_PATHS = [
    "/opt/appdata/", "/etc/mpd", "/etc/samba/", "/etc/ssh/",
    "/etc/bluetooth/", "/etc/xrdp/", "/opt/server-dashboard/",
    "/opt/appdata/homeassistant/", "/opt/appdata/navidrome/",
    "/opt/", "/etc/", "/home/",
]

# System-wide files accessible from Settings > System Files panel
# These are intentionally NOT listed in any service's config_files.
SYSTEM_FILES = [
    {"label": "smb.conf",              "path": "/etc/samba/smb.conf"},
    {"label": "fstab",                 "path": "/etc/fstab"},
    {"label": "hosts",                 "path": "/etc/hosts"},
    {"label": "hostname",              "path": "/etc/hostname"},
    {"label": "host.conf",             "path": "/etc/host.conf"},
    {"label": "adduser.conf",          "path": "/etc/adduser.conf"},
    {"label": "deluser.conf",          "path": "/etc/deluser.conf"},
    {"label": "ca-certificates.conf",  "path": "/etc/ca-certificates.conf"},
    {"label": "debconf.conf",          "path": "/etc/debconf.conf"},
    {"label": "gai.conf",              "path": "/etc/gai.conf"},
    {"label": "ld.so.conf",            "path": "/etc/ld.so.conf"},
    {"label": "libaudit.conf",         "path": "/etc/libaudit.conf"},
    {"label": "ssh/sshd_config",       "path": "/etc/ssh/sshd_config"},
    {"label": "crontab",               "path": "/etc/crontab"},
    {"label": "network/interfaces",    "path": "/etc/network/interfaces"},
]


# ─── Dashboard Settings (dashboard-only mappings) ───
SETTINGS_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "settings.json")


def _minimal_settings_template():
    # schema_version bump is safe; older fields are still honored.
    return {
        "schema_version": 3,
        "dashboard": {
            "viewer_host": "auto",
            "viewer_scheme": "http",

            # New: defaults for per-service URLs
            "default_url_mode": "local",               # local | domain
            "default_domain_suffix": "sidneyshelton.com",
            "default_domain_pattern": "{unit}.{suffix}",

            "hide_stopped_services": False,
            "protect_dashboard_service": True,
            "hidden_units": []
        },

        # New: categories are now configurable in settings
        "categories": CATEGORY_META,

        "services": {
            "server-dashboard": {
                "display_name": "Server Dashboard",
                "unit": "server-dashboard",
                "runtime": "docker",
                "docker_container": "server-dashboard",
                "host": "localhost",
                "port": 8029,
                "web_path": "",
                "category": "system",
                "description": "",
                "config_files": [],
                "data_paths": [],
                "volume_maps": [],

                # Optional URL overrides
                "url_mode": "local",
                "scheme": "http",
                "domain": "",
                "url_override": ""
            }
        },
        "auto_detect": {"enabled": False, "write_back_missing": False},
        "bootstrap": {"mode": "blank", "scan_paths": ["/opt/appdata:/config", "/opt/app:/app"]}
    }

def _write_minimal_settings_file(path=SETTINGS_PATH):
    s = _minimal_settings_template()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except Exception:
        pass
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2)
    os.replace(tmp, path)
    return s

SETTINGS_SCHEMA_VERSION = 2

def _default_service_map():
    svc = {}
    for name, unit, port, cat, desc, web_path, configs in SERVICES:
        guessed_data = []
        guessed_data.append(f"/opt/appdata/{unit}")
        for cf in (configs or []):
            try:
                d = os.path.dirname(cf)
                if d and d not in guessed_data:
                    guessed_data.append(d)
            except Exception:
                pass

        entry = {
            "display_name": name,
            "unit": unit,
            "runtime": "docker",        # docker | systemd | external
            "host": "localhost",         # IP or hostname; used for external and view URL
            "docker_container": unit,   # docker container name (may differ from unit)
            "volume_maps": [],           # ["host_path:container_path", ...]
            "port": port,
            "web_path": web_path,
            "category": cat,
            "description": desc,
            "config_files": list(configs or []),
            "data_paths": guessed_data,
        }

        if unit == "kiwix":
            entry["kiwix_zim_dir"] = "/opt/appdata/kiwix/data/zims"
            entry["kiwix_library_xml"] = "/opt/appdata/kiwix/data/library.xml"

        svc[unit] = entry
    return svc

def default_settings():
    return {
        "schema_version": SETTINGS_SCHEMA_VERSION,
        "dashboard": {
            "viewer_host": "auto",
            "viewer_scheme": "http",
            "hide_stopped_services": False,
            "protect_dashboard_service": True,
            "hidden_units": [],
        },
        "services": _default_service_map(),
        "auto_detect": {
            "enabled": True,
            "write_back_missing": True,
        },
        "bootstrap": {
            "mode": "embedded",          # "embedded" = use SERVICES list; "blank" = start fresh
            "scan_paths": [              # host:container path overrides for docker-inspect scan
                "/opt/appdata:/config",
                "/opt/app:/app",
            ],
        },
    }

def _migrate_old_settings(obj):
    """Migrate very old settings.json (kiwix_* keys at root) to schema v2."""
    s = default_settings()
    if isinstance(obj, dict):
        kz = obj.get("kiwix_zim_dir")
        kx = obj.get("kiwix_library_xml")
        if kz:
            s["services"]["kiwix"]["kiwix_zim_dir"] = str(kz)
        if kx:
            s["services"]["kiwix"]["kiwix_library_xml"] = str(kx)
        vh = obj.get("viewer_host") or obj.get("dashboard_host")
        if vh:
            s["dashboard"]["viewer_host"] = str(vh)
    return s

def _autodetect_service(unit, current_entry):
    """Best-effort discovery: docker mounts, config files (.conf/.xml/.db/.json etc)."""
    entry = dict(current_entry or {})
    entry.setdefault("unit", unit)
    runtime = str(entry.get("runtime", "docker")).strip()

    # ── Docker: read actual bind-mount paths ──────────────────────────────
    if runtime in ("docker", ""):
        try:
            mounts_out, rc = run_cmd(
                f"docker inspect --format='{{{{range .Mounts}}}}{{{{.Source}}}}:{{{{.Destination}}}} {{{{end}}}}' {unit} 2>/dev/null",
                timeout=4
            )
            if rc == 0 and mounts_out.strip():
                for pair in mounts_out.strip().split():
                    src = pair.split(":")[0] if ":" in pair else pair
                    if src.startswith("/") and src not in entry.get("data_paths", []):
                        entry.setdefault("data_paths", []).append(src)
                    vm = pair if ":" in pair else None
                    if vm and vm not in entry.get("volume_maps", []):
                        entry.setdefault("volume_maps", []).append(vm)
        except Exception:
            pass

    # ── Candidate directories to scan ─────────────────────────────────────
    common_dirs = [
        f"/opt/appdata/{unit}/config",
        f"/opt/appdata/{unit}",
        f"/opt/app/{unit}",
        f"/etc/{unit}",
        "/etc",
    ]
    for dp in entry.get("data_paths", []):
        if dp not in common_dirs:
            common_dirs.append(dp)

    # ── Config + DB file discovery ─────────────────────────────────────────
    CONFIG_EXTS = (".conf", ".ini", ".toml", ".xml", ".yaml", ".yml", ".json", ".cfg", ".env")
    DB_EXTS     = (".db", ".sqlite", ".sqlite3")
    KNOWN_NAMES = {"config.xml", "config.ini", "settings.json", "app.db", "library.db",
                   "nzbdrone.db", "logs.db", "main.db", "tautulli.db"}

    cfgs = entry.get("config_files") or []
    cfgs_existing = [c for c in cfgs if isinstance(c, str) and c.startswith("/") and os.path.isfile(c)]

    if not cfgs_existing:
        candidates = []
        for d in common_dirs:
            if os.path.isdir(d):
                try:
                    for fn in sorted(os.listdir(d)):
                        fp = os.path.join(d, fn)
                        if not os.path.isfile(fp):
                            continue
                        fl = fn.lower()
                        if (any(fl.endswith(ext) for ext in CONFIG_EXTS + DB_EXTS)
                                or fl in KNOWN_NAMES):
                            candidates.append(fp)
                except Exception:
                    pass
        if candidates:
            entry["config_files"] = sorted(list(dict.fromkeys(candidates)))[:12]

    # ── Clean data_paths ──────────────────────────────────────────────────
    dps = []
    for p in entry.get("data_paths", []):
        p = str(p).strip()
        if p.startswith("/") and p not in dps:
            dps.append(p)
    entry["data_paths"] = dps
    return entry

def load_settings():
    # JSON-only source of truth. If missing/invalid, auto-recover to minimal file.
    try:
        if not os.path.exists(SETTINGS_PATH):
            return _write_minimal_settings_file()

        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)

        if not isinstance(s, dict):
            raise ValueError("settings.json root must be object")

        if not isinstance(s.get("dashboard"), dict):
            s["dashboard"] = _minimal_settings_template()["dashboard"]
        # Ensure new dashboard defaults exist (backwards compatible)
        s["dashboard"].setdefault("default_url_mode", "local")
        s["dashboard"].setdefault("default_domain_suffix", "sidneyshelton.com")
        s["dashboard"].setdefault("default_domain_pattern", "{unit}.{suffix}")

        if not isinstance(s.get("services"), dict):
            s["services"] = {}
        if not isinstance(s.get("categories"), dict):
            s["categories"] = CATEGORY_META

        if not isinstance(s.get("auto_detect"), dict):
            s["auto_detect"] = _minimal_settings_template()["auto_detect"]
        if not isinstance(s.get("bootstrap"), dict):
            s["bootstrap"] = _minimal_settings_template()["bootstrap"]

        if "server-dashboard" not in s["services"]:
            s["services"]["server-dashboard"] = _minimal_settings_template()["services"]["server-dashboard"]

        return s

    except Exception:
        try:
            if os.path.exists(SETTINGS_PATH):
                bad = SETTINGS_PATH + ".bad-" + datetime.now().strftime("%Y%m%d_%H%M%S")
                shutil.copy2(SETTINGS_PATH, bad)
        except Exception:
            pass
        try:
            return _write_minimal_settings_file()
        except Exception:
            return _minimal_settings_template()


def _validate_settings(s):
    """
    Minimal validator fallback for patched builds.
    Returns (ok: bool, msg: str)
    """
    try:
        if not isinstance(s, dict):
            return False, "Settings root must be an object"

        if "dashboard" in s and not isinstance(s.get("dashboard"), dict):
            return False, "dashboard must be an object"

        if "services" in s and not isinstance(s.get("services"), dict):
            return False, "services must be an object"

        # Light per-service checks only (don't block on missing optional fields)
        for unit, svc in (s.get("services") or {}).items():
            if not isinstance(svc, dict):
                return False, f"service '{unit}' must be an object"
            if not unit or not isinstance(unit, str):
                return False, "service key must be a non-empty string"

        return True, ""
    except Exception as e:
        return False, str(e)


def save_settings(s):
    ok, msg = _validate_settings(s)
    if not ok:
        return False, msg

    tmp = SETTINGS_PATH + ".tmp"
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(tmp, "w") as f:
            json.dump(s, f, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True, "Settings saved"
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False, str(e)


def run_cmd(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or '').strip()
        err = (r.stderr or '').strip()
        if r.returncode != 0 and err:
            return ((out + ('\n' if out else '') + err).strip()), r.returncode
        return out, r.returncode
    except Exception as e:
        return str(e), 1


def _docker_target_for_unit(unit):
    try:
        s = load_settings()
        entry = ((s.get('services', {}) or {}).get(unit, {}) if isinstance(s, dict) else {})
        if isinstance(entry, dict):
            target = str(entry.get('docker_container', unit)).strip()
            if target:
                return target
    except Exception:
        pass
    return unit


def get_service_status(unit, runtime="docker"):
    if runtime == "systemd":
        out, rc = run_cmd(f"systemctl is-active {unit} 2>/dev/null")
        s = out.strip()
        return "active" if s == "active" else ("inactive" if s in ("inactive","failed") else "unknown")
    elif runtime == "external":
        return "unknown"
    else:  # docker
        target = _docker_target_for_unit(unit)
        out, rc = run_cmd(f"docker inspect --format='{{{{.State.Status}}}}' {target} 2>/dev/null")
        status = out.strip().strip("'")
        if status == "running": return "active"
        if status in ("exited","dead","removing"): return "inactive"
        if status in ("paused","restarting","created"): return status
        return "unknown"


def get_service_memory(unit, runtime="docker"):
    if runtime != "docker": return None
    target = _docker_target_for_unit(unit)
    out, rc = run_cmd(f"docker stats --no-stream --format '{{{{.MemUsage}}}}' {target} 2>/dev/null")
    try:
        used = out.strip().split("/")[0].strip()
        val = float(''.join(c for c in used if c.isdigit() or c == '.'))
        u = used.upper()
        if "GIB" in u or "GB" in u: return val * 1024
        if "KIB" in u or "KB" in u: return val / 1024
        return val
    except Exception: pass
    return None


def get_service_cpu(unit, runtime="docker"):
    if runtime != "docker": return None
    target = _docker_target_for_unit(unit)
    out, rc = run_cmd(f"docker stats --no-stream --format '{{{{.CPUPerc}}}}' {target} 2>/dev/null")
    try:
        pct = out.strip().replace("%", "")
        return float(pct) if pct else None
    except Exception: pass
    return None


def service_control(unit, action):
    if action not in ('start', 'stop', 'restart'):
        return False, "Invalid action"
    s = load_settings()
    svc_map = s.get("services", {})
    all_units = set(svc_map.keys()) | {sv[1] for sv in SERVICES}
    if unit not in all_units:
        return False, "Unknown service"
    try:
        dash = s.get("dashboard", {})
        if action == "stop" and unit == "server-dashboard":
            if bool(dash.get("protect_dashboard_service", True)):
                return False, "Stop is disabled for Server Dashboard (Settings)"
    except Exception:
        pass
    entry  = svc_map.get(unit, {})
    runtime = str(entry.get("runtime", "docker")).strip()
    if runtime == "systemd":
        out, rc = run_cmd(f"sudo systemctl {action} {unit}", timeout=15)
    elif runtime == "external":
        return False, "External services cannot be controlled from this dashboard"
    else:
        container = str(entry.get("docker_container", unit)).strip() or unit

        # Special case: restarting the dashboard itself or a reverse-proxy (like Caddy) can drop
        # the HTTP connection before the browser receives the JSON response.
        # Do a delayed restart in the background so the request can return cleanly.
        if action == "restart" and unit in ("server-dashboard", "caddy", "caddy-calibre"):
            try:
                subprocess.Popen(["sh", "-c", f"sleep 1; docker restart {container} >/dev/null 2>&1 || true"])
                return True, f"restarting {unit}"
            except Exception:
                pass

        out, rc   = run_cmd(f"docker {action} {container}", timeout=15)
    if rc == 0: return True, f"{action}ed {unit}"
    return False, out or f"Failed to {action} {unit}"


# ── Scan helpers ───────────────────────────────────────────────────────────
def _scan_docker():
    out, rc = run_cmd("docker ps -a --format '{{.Names}}|{{.Image}}|{{.Ports}}|{{.Status}}' 2>/dev/null", timeout=8)
    results = []
    if rc != 0 or not out.strip():
        return results

    s = load_settings()
    svc_map = (s.get("services", {}) or {}) if isinstance(s, dict) else {}
    existing_units = set(svc_map.keys())
    existing_docker_names = set()
    for _, entry in svc_map.items():
        if isinstance(entry, dict) and str(entry.get("runtime", "docker")).strip() == "docker":
            existing_docker_names.add(str(entry.get("docker_container", "")).strip())

    for line in out.strip().splitlines():
        parts = line.split("|")
        if len(parts) < 4:
            continue
        name, image, ports, status = parts[0], parts[1], parts[2], parts[3]

        if name == "services-server-dashboard-service-1":
            continue
        if name in existing_units or name in existing_docker_names:
            continue

        suggested = None
        pm = re.search(r':(\d+)->', ports)
        if pm:
            try:
                suggested = int(pm.group(1))
            except Exception:
                suggested = None

        results.append({
            "container": name,
            "image": image,
            "ports": ports,
            "status": status,
            "suggested_port": suggested
        })
    return results

def _scan_systemd():
    out, rc = run_cmd(
        "systemctl list-units --type=service --state=active --no-pager --no-legend 2>/dev/null", timeout=8)
    results = []
    if rc != 0 or not out.strip(): return results
    known = {s[1] for s in SERVICES}
    for line in out.strip().splitlines():
        parts = line.split(None, 4)
        if not parts: continue
        unit_name = parts[0].replace(".service", "")
        if unit_name in known: continue
        results.append({"unit": unit_name, "active": parts[2] if len(parts) > 2 else "active",
                        "description": parts[4].strip() if len(parts) > 4 else "", "suggested_port": None})
    return results[:30]

def _scan_ports():
    out, rc = run_cmd("ss -tlnp 2>/dev/null | awk 'NR>1 {print $4}' | grep -oP '(?<=:)\\d+' | sort -un", timeout=6)
    results = []
    if rc != 0: return results
    known_ports = {s[2] for s in SERVICES if s[2]}
    WK = {3000:("Grafana","/","home"), 3001:("Web App","/","home"), 5000:("Flask App","/","home"),
          8080:("Web UI","/","home"), 8443:("Secure Web","/","home"), 9000:("Portainer","/","system"),
          9090:("Prometheus","/","system"), 9100:("Node Exporter","/","system")}
    for line in out.strip().splitlines():
        try: port = int(line.strip())
        except: continue
        if port in known_ports or port < 1024: continue
        info = WK.get(port, (f"Service :{port}", "/", "home"))
        results.append({"port": port, "name": info[0], "description": f"Open port {port}",
                        "web_path": info[1], "category": info[2]})
    return results[:20]

def add_services_to_settings(servers_list):
    s = load_settings()
    added = []
    for srv in servers_list:
        unit = str(srv.get("unit","")).strip().lower().replace(" ","-")
        if not unit: continue
        name = str(srv.get("name", unit)).strip()
        runtime = str(srv.get("runtime","docker")).strip()
        host    = str(srv.get("host","localhost")).strip()
        cat     = str(srv.get("category","home")).strip()
        desc    = str(srv.get("description","")).strip()
        wp      = str(srv.get("web_path","")) if srv.get("web_path") is not None else ""
        dc      = str(srv.get("docker_container", unit)).strip() if runtime == "docker" else unit
        port    = None
        try: port = int(srv["port"]) if srv.get("port") else None
        except: pass
        entry = {
            "display_name": name, "unit": unit,
            "runtime": runtime, "host": host, "docker_container": dc,
            "volume_maps": list(srv.get("volume_maps", [])),
            "port": port, "web_path": wp, "category": cat, "description": desc,
            "config_files": [], "data_paths": [],
        }
        s["services"][unit] = entry
        added.append(unit)
    if added:
        ok, msg = save_settings(s)
        if not ok: return []
    return added

def bootstrap_settings(mode):
    """Reset settings.json. mode='embedded' rebuilds from SERVICES; mode='blank' starts empty."""
    if mode == "blank":
        s = {"schema_version": SETTINGS_SCHEMA_VERSION,
             "dashboard": {"viewer_host": "auto", "viewer_scheme": "http",
                           "hide_stopped_services": False, "protect_dashboard_service": True,
                           "hidden_units": []},
             "services": {},
             "auto_detect": {"enabled": False, "write_back_missing": False},
             "bootstrap": {"mode": "blank", "scan_paths": ["/opt/appdata:/config", "/opt/app:/app"]}}
    else:
        s = default_settings()
        s["bootstrap"]["mode"] = "embedded"
    tmp = SETTINGS_PATH + ".tmp"
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(tmp, "w") as f: json.dump(s, f, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True, f"Settings reset to [{mode}] mode"
    except Exception as e:
        return False, str(e)



def get_system_info():
    info = {}
    info["hostname"], _ = run_cmd("hostname")
    ip_out, _ = run_cmd("hostname -I")
    info["ip"] = ip_out.split()[0] if ip_out else "unknown"

    uptime_raw, _ = run_cmd("cat /proc/uptime")
    if uptime_raw:
        secs = float(uptime_raw.split()[0])
        d, h, m = int(secs // 86400), int((secs % 86400) // 3600), int((secs % 3600) // 60)
        info["uptime"] = f"{d}d {h}h {m}m"

    load_out, _ = run_cmd("cat /proc/loadavg")
    if load_out:
        p = load_out.split()
        info["load"] = f"{p[0]} / {p[1]} / {p[2]}"

    temp, _ = run_cmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null")
    if temp:
        try: info["cpu_temp"] = round(int(temp) / 1000, 1)
        except: pass

    mem_out, _ = run_cmd("free -b")
    if mem_out:
        lines = mem_out.split("\n")
        mp = lines[1].split()
        info["mem_total"] = int(mp[1])
        info["mem_used"] = int(mp[2])
        info["mem_available"] = int(mp[6]) if len(mp) > 6 else int(mp[1]) - int(mp[2])
        sp = lines[2].split()
        info["swap_total"] = int(sp[1])
        info["swap_used"] = int(sp[2])

    disk_out, _ = run_cmd("df -B1 /")
    if disk_out:
        dp = disk_out.split("\n")[1].split()
        info["disk_total"] = int(dp[1])
        info["disk_used"] = int(dp[2])
        info["disk_avail"] = int(dp[3])

    info["os"], _ = run_cmd("cat /etc/os-release | grep PRETTY_NAME | cut -d'\"' -f2")
    info["kernel"], _ = run_cmd("uname -r")
    return info


def get_service_data(settings=None):
    if settings is None:
        settings = load_settings()
    svc_map   = (settings or {}).get("services", {}) if isinstance(settings, dict) else {}
    bootstrap = (settings or {}).get("bootstrap", {}) if isinstance(settings, dict) else {}
    mode      = str(bootstrap.get("mode", "embedded")).strip()

    services = []

    if mode == "embedded":
        # Seed from the hardcoded SERVICES list, applying any saved overrides
        seen = set()
        for name, unit, port, cat, desc, web_path, configs in SERVICES:
            seen.add(unit)
            ov       = svc_map.get(unit, {}) if isinstance(svc_map, dict) else {}
            runtime  = str(ov.get("runtime", "docker"))
            host     = str(ov.get("host", "localhost"))
            eff_port = ov.get("port", port)
            eff_wp   = ov.get("web_path", web_path)
            eff_cfg  = ov.get("config_files", configs)
            eff_dp   = ov.get("data_paths", [])
            eff_vm   = ov.get("volume_maps", [])
            status   = get_service_status(unit, runtime)
            mem      = get_service_memory(unit, runtime)
            cpu      = get_service_cpu(unit, runtime)
            svc = {"name": name, "unit": unit, "port": eff_port, "category": ov.get("category", cat) if isinstance(ov, dict) else cat,
                   "description": desc, "status": status,
                   "memory_mb": round(mem,1) if mem else None,
                   "cpu_pct": round(cpu,1) if cpu else None,
                   "web_path": eff_wp, "config_files": eff_cfg,
                   "data_paths": eff_dp, "volume_maps": eff_vm,
                   "runtime": runtime, "host": host, "url_mode": (ov.get("url_mode") if isinstance(ov, dict) else None), "scheme": (ov.get("scheme") if isinstance(ov, dict) else None), "domain": (ov.get("domain") if isinstance(ov, dict) else None), "url_override": (ov.get("url_override") if isinstance(ov, dict) else None)}
            if unit == "kiwix" and isinstance(ov, dict):
                if "kiwix_zim_dir" in ov:    svc["kiwix_zim_dir"] = ov["kiwix_zim_dir"]
                if "kiwix_library_xml" in ov: svc["kiwix_library_xml"] = ov["kiwix_library_xml"]
            services.append(svc)

        # Also include any dynamically-added services saved in settings
        for unit, ov in svc_map.items():
            if unit in seen or not isinstance(ov, dict): continue
            runtime = str(ov.get("runtime","docker"))
            host    = str(ov.get("host","localhost"))
            status  = get_service_status(unit, runtime)
            mem     = get_service_memory(unit, runtime)
            cpu     = get_service_cpu(unit, runtime)
            services.append({
                "name":         ov.get("display_name", unit),
                "unit":         unit,
                "port":         ov.get("port"),
                "category":     ov.get("category","home"),
                "description":  ov.get("description",""),
                "status":       status,
                "memory_mb":    round(mem,1) if mem else None,
                "cpu_pct":      round(cpu,1) if cpu else None,
                "web_path":     ov.get("web_path",""),
                "config_files": ov.get("config_files",[]),
                "data_paths":   ov.get("data_paths",[]),
                "volume_maps":  ov.get("volume_maps",[]),
                "runtime":      runtime,
                "host":         host,
                "url_mode":     ov.get("url_mode"),
                "scheme":       ov.get("scheme"),
                "domain":       ov.get("domain"),
                "url_override": ov.get("url_override"),
            })
    else:
        # Blank mode: ONLY render what is explicitly saved in settings — never touch SERVICES
        for unit, ov in svc_map.items():
            if not isinstance(ov, dict): continue
            runtime = str(ov.get("runtime","docker"))
            host    = str(ov.get("host","localhost"))
            status  = get_service_status(unit, runtime)
            mem     = get_service_memory(unit, runtime)
            cpu     = get_service_cpu(unit, runtime)
            services.append({
                "name":         ov.get("display_name", unit),
                "unit":         unit,
                "port":         ov.get("port"),
                "category":     ov.get("category","home"),
                "description":  ov.get("description",""),
                "status":       status,
                "memory_mb":    round(mem,1) if mem else None,
                "cpu_pct":      round(cpu,1) if cpu else None,
                "web_path":     ov.get("web_path",""),
                "config_files": ov.get("config_files",[]),
                "data_paths":   ov.get("data_paths",[]),
                "volume_maps":  ov.get("volume_maps",[]),
                "runtime":      runtime,
                "host":         host,
            })

    return services


def is_path_allowed(filepath):
    filepath = os.path.realpath(filepath)
    return any(filepath.startswith(p) for p in ALLOWED_EDIT_PATHS)


def read_config_file(filepath):
    filepath = os.path.realpath(filepath)
    if not is_path_allowed(filepath):
        return None, "Path not allowed"
    if not os.path.isfile(filepath):
        return None, "File not found"
    try:
        with open(filepath, 'r') as f:
            return f.read(), None
    except PermissionError:
        out, rc = run_cmd(f"sudo cat '{filepath}'")
        if rc == 0:
            return out, None
        return None, "Permission denied"


def write_config_file(filepath, content):
    filepath = os.path.realpath(filepath)
    if not is_path_allowed(filepath):
        return False, "Path not allowed"
    run_cmd(f"sudo cp '{filepath}' '{filepath}.bak.$(date +%Y%m%d%H%M%S)' 2>/dev/null")
    try:
        with open(filepath, 'w') as f:
            f.write(content)
        return True, "Saved"
    except PermissionError:
        import tempfile
        tmp = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.tmp')
        tmp.write(content)
        tmp.close()
        _, rc = run_cmd(f"sudo cp '{tmp.name}' '{filepath}'")
        os.unlink(tmp.name)
        if rc == 0:
            return True, "Saved (via sudo)"
        return False, "Permission denied"


def browse_directory(path, show_files=True):
    """List contents of a directory for the file browser."""
    try:
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            return None, "Not a directory"
        
        items = []
        # Add parent directory option
        parent = os.path.dirname(path)
        if parent and parent != path:
            items.append({"name": "..", "path": parent, "type": "dir"})
        
        for name in sorted(os.listdir(path)):
            if name.startswith('.'):
                continue
            full_path = os.path.join(path, name)
            try:
                if os.path.isdir(full_path):
                    items.append({"name": name + "/", "path": full_path, "type": "dir"})
                elif show_files and os.path.isfile(full_path):
                    ext = name.lower().split('.')[-1] if '.' in name else ''
                    if ext in ('conf', 'ini', 'toml', 'xml', 'yaml', 'yml', 'json',
                               'cfg', 'config', 'py', 'sh', 'service',
                               'db', 'sqlite', 'sqlite3', 'env', 'properties'):
                        items.append({"name": name, "path": full_path, "type": "file"})
            except PermissionError:
                continue
        
        return {"path": path, "items": items}, None
    except Exception as e:
        return None, str(e)


def refresh_kiwix_library():
    """Rebuild Kiwix library.xml from the dashboard settings and restart Kiwix."""
    s = load_settings()
    svc = (s.get("services", {}) or {}).get("kiwix", {})
    zim_dir = str(svc.get("kiwix_zim_dir", "/opt/appdata/kiwix/data/zims")).strip()
    lib_xml = str(svc.get("kiwix_library_xml", "/opt/appdata/kiwix/data/library.xml")).strip()

    if not zim_dir.startswith("/") or not lib_xml.startswith("/"):
        return False, "Kiwix paths must be absolute in Settings", ""

    try:
        os.makedirs(zim_dir, exist_ok=True)
        os.makedirs(os.path.dirname(lib_xml), exist_ok=True)
    except Exception as e:
        return False, f"Unable to create directories: {e}", ""

    zims = []
    try:
        for fn in sorted(os.listdir(zim_dir)):
            low = fn.lower()
            if low.endswith(".zim") or low.endswith(".zimaa"):
                p = os.path.join(zim_dir, fn)
                if os.path.isfile(p):
                    zims.append(p)
    except Exception as e:
        return False, f"Unable to scan ZIM directory: {e}", ""

    if not zims:
        return False, f"No ZIM files found in {zim_dir}", ""

    if shutil.which("kiwix-manage") is None:
        script = "/usr/local/bin/kiwix-refresh-library.sh"
        if os.path.exists(script):
            out, rc = run_cmd(f"sudo {script}", timeout=180)
            if rc == 0:
                return True, "Kiwix library refreshed (script)", out or ""
            return False, "Kiwix refresh failed (script)", out or ""
        return False, "kiwix-manage not found and helper script missing", ""

    try:
        if os.path.exists(lib_xml):
            os.remove(lib_xml)
    except Exception:
        pass

    details = []
    for f in zims:
        p = subprocess.run(
            ["kiwix-manage", lib_xml, "add", f],
            capture_output=True, text=True
        )
        if p.returncode != 0:
            err = (p.stderr or p.stdout or "").strip()
            return False, f"kiwix-manage failed adding {os.path.basename(f)}", err
        details.append(f"Added: {os.path.basename(f)}")

    out, rc = run_cmd(f"docker restart kiwix 2>/dev/null || true", timeout=20)
    msg = f"Kiwix library refreshed · {len(zims)} file(s)"
    return True, msg, "\n".join(details) + ("\n" + out if out else "")



def read_app_version():
    """Read version.json next to this script (best-effort)."""
    try:
        here = os.path.dirname(os.path.realpath(__file__))
        vp = os.path.join(here, "version.json")
        if os.path.isfile(vp):
            with open(vp, "r", encoding="utf-8") as f:
                v = json.load(f)
            if isinstance(v, dict):
                return {
                    "version": str(v.get("version", "")).strip(),
                    "release_date": str(v.get("release_date", "")).strip(),
                    "codename": str(v.get("codename", "")).strip(),
                }
    except Exception:
        pass
    return {"version": "", "release_date": "", "codename": ""}


def build_api_response():
    s = load_settings()
    categories = s.get("categories") if isinstance(s.get("categories"), dict) else CATEGORY_META
    return json.dumps({
        "app": read_app_version(),
        "system": get_system_info(),
        "services": get_service_data(s),
        "categories": categories,
        "settings": s,
        "system_files": SYSTEM_FILES,
        "scan_paths": s.get("bootstrap", {}).get("scan_paths", []),
        "timestamp": datetime.now().isoformat(),
    })


# ─────────────────────────────────────────────
# HTML
# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
# Static UI files (editable)
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.realpath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

from typing import Optional

def _safe_join_static(rel_path: str) -> Optional[str]:
    # Prevent path traversal (..)
    rel_path = (rel_path or "").lstrip("/")
    if ".." in rel_path.replace("\\", "/").split("/"):
        return None
    full = os.path.realpath(os.path.join(STATIC_DIR, rel_path))
    if not full.startswith(os.path.realpath(STATIC_DIR) + os.sep):
        return None
    return full

def _read_text_file(path: str, fallback: str = "") -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return fallback

def _read_bytes_file(path: str) -> bytes | None:
    try:
        with open(path, "rb") as f:
            return f.read()
    except Exception:
        return None



# ── Embed safety + iframe detection (Option A) ─────────────────────────────
_PRIVATE_IP_RE = re.compile(r'^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)')

def _is_safe_embed_target(url: str) -> bool:
    try:
        u = urllib.parse.urlparse(url)
        if u.scheme not in ("http", "https"):
            return False
        host = (u.hostname or "").strip().lower()
        if not host:
            return False
        if host in ("localhost", "127.0.0.1"):
            return True
        if host.endswith(".sidneyshelton.com") or host == "sidneyshelton.com":
            return True
        if _PRIVATE_IP_RE.match(host):
            return True
        return False
    except Exception:
        return False

def _check_iframe_block_headers(url: str) -> dict:
    """Return {embeddable: bool, reason: str}. Best-effort only."""
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "server-dashboard/iframe-check"})
        with urllib.request.urlopen(req, timeout=4) as resp:
            hdrs = {k.lower(): v for k, v in resp.headers.items()}
    except Exception as e:
        # If we can't check, assume embeddable and let the browser decide.
        return {"embeddable": True, "reason": f"Header check failed: {e}"}

    xfo = (hdrs.get("x-frame-options") or "").strip()
    if xfo:
        low = xfo.lower()
        if "deny" in low:
            return {"embeddable": False, "reason": f"Blocked by X-Frame-Options: {xfo}"}
        if "sameorigin" in low:
            return {"embeddable": False, "reason": f"Blocked by X-Frame-Options: {xfo}"}
        if "allow-from" in low and "sidneyshelton.com" not in low:
            return {"embeddable": False, "reason": f"Blocked by X-Frame-Options: {xfo}"}

    csp = (hdrs.get("content-security-policy") or "").strip()
    if csp and "frame-ancestors" in csp.lower():
        cl = csp.lower()
        # Extract the frame-ancestors directive (simple parse)
        try:
            i = cl.index("frame-ancestors")
            seg = cl[i:]
            seg = seg.split(";")[0]
        except Exception:
            seg = cl
        # If it explicitly allows all, good.
        if "*" in seg:
            return {"embeddable": True, "reason": "frame-ancestors allows *"}
        # If it only allows self, it will fail when embedded from another origin.
        if "'self'" in seg and "sidneyshelton.com" not in seg and "serverdashboard.sidneyshelton.com" not in seg:
            return {"embeddable": False, "reason": "Blocked by Content-Security-Policy frame-ancestors (self only)"}
        # If frame-ancestors is present but doesn't mention our domain, assume blocked.
        if "sidneyshelton.com" not in seg and "serverdashboard.sidneyshelton.com" not in seg:
            return {"embeddable": False, "reason": "Blocked by Content-Security-Policy frame-ancestors"}
    return {"embeddable": True, "reason": ""}

class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)

        # Serve static UI assets (index.html, server.js, styles.css)
        if parsed.path.startswith('/static/'):
            rel = parsed.path[len('/static/'):]
            fp = _safe_join_static(rel)
            if not fp or not os.path.isfile(fp):
                self.send_response(404)
                self.end_headers()
                return
            ctype, _ = mimetypes.guess_type(fp)
            ctype = ctype or ('application/javascript' if fp.endswith('.js') else 'text/plain')
            data = _read_bytes_file(fp)
            if data is None:
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(data)
            return

        if parsed.path == '/api/embed_check':
            url = qs.get('url', [None])[0]
            if not url:
                self._json(400, json.dumps({"ok": False, "error": "Missing url"}))
                return
            if not _is_safe_embed_target(url):
                self._json(400, json.dumps({"ok": False, "error": "Blocked target"}))
                return
            res = _check_iframe_block_headers(url)
            self._json(200, json.dumps({"ok": True, "embeddable": bool(res.get("embeddable", True)), "reason": res.get("reason","")}))
        elif parsed.path == '/api/status':

            self._json(200, build_api_response())
        elif parsed.path == '/api/config':
            path = qs.get('path', [None])[0]
            if not path:
                self._json(400, json.dumps({"ok": False, "error": "No path"}))
                return
            content, err = read_config_file(path)
            if err:
                self._json(200, json.dumps({"ok": False, "error": err}))
            else:
                self._json(200, json.dumps({"ok": True, "content": content}))
        elif parsed.path == '/api/logs':
            unit = qs.get('unit', [None])[0]
            if not unit:
                self._json(400, json.dumps({"logs": "No unit specified"}))
                return
            s = load_settings()
            all_units = set((s.get("services", {}) or {}).keys())
            if unit not in all_units:
                self._json(400, json.dumps({"logs": "Unknown unit"}))
                return
            logs, _ = run_cmd(f"docker logs --tail 100 --timestamps {unit} 2>&1", timeout=10)
            self._json(200, json.dumps({"logs": logs}))
        elif parsed.path == '/api/scan':
            self._json(200, json.dumps({
                "ok": True,
                "results": {
                    "docker":  _scan_docker(),
                    "systemd": _scan_systemd(),
                    "ports":   _scan_ports(),
                }
            }))
        elif parsed.path == '/api/settings':
            s = load_settings()
            self._json(200, json.dumps({"ok": True, "settings": s}))
        elif parsed.path == '/api/browse':
            path = qs.get('path', ['/opt'])[0]
            data, err = browse_directory(path)
            if err:
                self._json(200, json.dumps({"ok": False, "error": err}))
            else:
                self._json(200, json.dumps({"ok": True, "data": data}))
        elif parsed.path == '/' or parsed.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            html = _read_text_file(os.path.join(STATIC_DIR, 'index.html'), fallback='Dashboard UI missing: static/index.html')
            self.wfile.write(html.encode('utf-8', errors='replace'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        if parsed.path == '/api/control':
            unit = body.get('unit', '')
            action = body.get('action', '')
            ok, msg = service_control(unit, action)
            self._json(200, json.dumps({"ok": ok, "message": msg}))
        elif parsed.path == '/api/config':
            path = body.get('path', '')
            content = body.get('content', '')
            ok, msg = write_config_file(path, content)
            self._json(200, json.dumps({"ok": ok, "message": msg, "error": "" if ok else msg}))
        elif parsed.path == '/api/servers/add':
            servers = body.get("servers", [])
            if not isinstance(servers, list) or not servers:
                self._json(400, json.dumps({"ok": False, "message": "No servers provided"}))
                return
            added = add_services_to_settings(servers)
            msg = f"Added {len(added)}: {', '.join(added)}" if added else "Nothing added"
            self._json(200, json.dumps({"ok": bool(added), "message": msg, "added": added}))
        elif parsed.path == '/api/bootstrap':
            mode = str(body.get("mode","embedded")).strip()
            if mode not in ("embedded","blank"):
                self._json(400, json.dumps({"ok":False,"message":"mode must be embedded or blank"}))
                return
            ok, msg = bootstrap_settings(mode)
            self._json(200, json.dumps({"ok": ok, "message": msg}))
        elif parsed.path == '/api/service/remove':
            unit = str(body.get('unit','')).strip()
            if not unit:
                self._json(400, json.dumps({"ok": False, "message": "No unit provided"}))
                return
            if unit == 'server-dashboard':
                self._json(400, json.dumps({"ok": False, "message": "server-dashboard is protected"}))
                return
            s = load_settings()
            if not isinstance(s.get("services"), dict) or unit not in s["services"]:
                self._json(404, json.dumps({"ok": False, "message": f"Service not found in settings: {unit}"}))
                return
            try:
                del s["services"][unit]
            except Exception:
                pass
            # Also unhide if it was hidden
            try:
                hu = s.get("dashboard", {}).get("hidden_units", [])
                if isinstance(hu, list) and unit in hu:
                    hu = [x for x in hu if x != unit]
                    s["dashboard"]["hidden_units"] = hu
            except Exception:
                pass
            ok, msg = save_settings(s)
            self._json(200, json.dumps({"ok": ok, "message": msg}))
        elif parsed.path == '/api/settings':
            if isinstance(body, dict) and isinstance(body.get("settings"), dict):
                new_s = body.get("settings")
            else:
                new_s = load_settings()
                if "viewer_host" in body:
                    new_s["dashboard"]["viewer_host"] = str(body.get("viewer_host", "")).strip()
                if "kiwix_zim_dir" in body:
                    new_s["services"]["kiwix"]["kiwix_zim_dir"] = str(body.get("kiwix_zim_dir", "")).strip()
                if "kiwix_library_xml" in body:
                    new_s["services"]["kiwix"]["kiwix_library_xml"] = str(body.get("kiwix_library_xml", "")).strip()

            ok, msg = save_settings(new_s)
            self._json(200, json.dumps({"ok": ok, "message": msg, "settings": load_settings()}))

        elif parsed.path == '/api/settings/autodetect':
            s = load_settings()
            svc = s.get("services", {})
            detected = {}

            if body.get("all"):
                units = list(svc.keys())
            else:
                unit = str(body.get("unit", "")).strip()
                units = [unit] if unit else []

            units = [u for u in units if u in svc]

            if not units:
                self._json(400, json.dumps({"ok": False, "message": "No valid unit specified"}))
                return

            for u in units:
                detected[u] = _autodetect_service(u, svc.get(u, {}))

            if body.get("apply", True):
                for u, entry in detected.items():
                    if u in s["services"]:
                        s["services"][u].update(entry)
                save_settings(s)

            self._json(200, json.dumps({"ok": True, "detected": detected, "settings": load_settings()}))
        elif parsed.path == '/api/kiwix/refresh':
            ok, msg, details = refresh_kiwix_library()
            self._json(200, json.dumps({"ok": ok, "message": msg, "details": details}))
        else:
            self.send_response(404)
            self.end_headers()

    def _json(self, code, data):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        if isinstance(data, str):
            self.wfile.write(data.encode())
        else:
            self.wfile.write(data)


def main():
    port = 8029
    server = HTTPServer(('0.0.0.0', port), DashboardHandler)
    print(f"SidscriServer Dashboard running at http://0.0.0.0:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.server_close()



# _PERF_PATCH_V1
_DOCKER_STATS_CACHE = {"ts": 0.0, "data": {}}
_API_STATUS_CACHE = {"ts": 0.0, "payload": None}

def _parse_mem_to_mb_perf(mem_used_text):
    try:
        used = str(mem_used_text).strip()
        val = float(''.join(c for c in used if c.isdigit() or c == '.'))
        u = used.upper()
        if "GIB" in u or "GB" in u:
            return val * 1024
        if "KIB" in u or "KB" in u:
            return val / 1024
        return val
    except Exception:
        return None

def _get_docker_stats_snapshot_perf(ttl=4, timeout=4):
    now = time.time()
    if (now - _DOCKER_STATS_CACHE.get("ts", 0.0)) < ttl and isinstance(_DOCKER_STATS_CACHE.get("data"), dict):
        return _DOCKER_STATS_CACHE["data"]

    out, rc = run_cmd("docker stats --no-stream --format '{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}' 2>/dev/null", timeout=timeout)
    stats = {}
    if rc == 0 and out and out.strip():
        for line in out.splitlines():
            parts = line.split("|", 2)
            if len(parts) != 3:
                continue
            name, cpu_txt, mem_txt = [x.strip() for x in parts]
            try:
                cpu_val = float(cpu_txt.replace("%","")) if cpu_txt else None
            except Exception:
                cpu_val = None
            mem_used = mem_txt.split("/", 1)[0].strip()
            mem_mb = _parse_mem_to_mb_perf(mem_used)
            stats[name] = {"cpu_pct": cpu_val, "memory_mb": mem_mb}

    _DOCKER_STATS_CACHE["ts"] = now
    _DOCKER_STATS_CACHE["data"] = stats
    return stats

# Override for speed (preserves docker_container mapping)
def get_service_memory(unit, runtime="docker"):
    if runtime != "docker":
        return None
    target = _docker_target_for_unit(unit)
    item = _get_docker_stats_snapshot_perf().get(target)
    return None if not item else item.get("memory_mb")

def get_service_cpu(unit, runtime="docker"):
    if runtime != "docker":
        return None
    target = _docker_target_for_unit(unit)
    item = _get_docker_stats_snapshot_perf().get(target)
    return None if not item else item.get("cpu_pct")

# Faster status checks (short timeout)
def get_service_status(unit, runtime="docker"):
    if runtime == "systemd":
        out, rc = run_cmd(f"systemctl is-active {unit} 2>/dev/null", timeout=2)
        s = out.strip()
        return "active" if s == "active" else ("inactive" if s in ("inactive","failed") else "unknown")
    elif runtime == "external":
        return "unknown"
    else:
        target = _docker_target_for_unit(unit)
        out, rc = run_cmd(f"docker inspect --format='{{{{.State.Status}}}}' {target} 2>/dev/null", timeout=2)
        status = out.strip().strip("'")
        if status == "running": return "active"
        if status in ("exited","dead","removing"): return "inactive"
        if status in ("paused","restarting","created"): return status
        return "unknown"

# Cache the full API payload briefly so UI polls don't rebuild everything
def build_api_response():
    now = time.time()
    if _API_STATUS_CACHE.get("payload") is not None and (now - _API_STATUS_CACHE.get("ts", 0.0)) < 5:
        return _API_STATUS_CACHE["payload"]

    s = load_settings()
    payload = json.dumps({
        "app": read_app_version() if "read_app_version" in globals() else {"version":"","release_date":"","codename":""},
        "system": get_system_info(),
        "services": get_service_data(s),
        "categories": CATEGORY_META,
        "settings": s,
        "system_files": SYSTEM_FILES if "SYSTEM_FILES" in globals() else [],
        "scan_paths": s.get("bootstrap", {}).get("scan_paths", []),
        "timestamp": datetime.now().isoformat(),
    })
    _API_STATUS_CACHE["ts"] = now
    _API_STATUS_CACHE["payload"] = payload
    return payload


if __name__ == '__main__':
    main()
