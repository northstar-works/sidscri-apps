from pathlib import Path
import json, os, shutil
from datetime import datetime

p = Path("/opt/app/server-dashboard/server.py")
t = p.read_text(encoding="utf-8", errors="replace")
orig = t

# --- Insert helper templates after SETTINGS_PATH line ---
if "def _minimal_settings_template(" not in t:
    key = "SETTINGS_PATH ="
    i = t.find(key)
    if i == -1:
        raise SystemExit("SETTINGS_PATH not found")
    line_end = t.find("\n", i) + 1
    helper = '''

def _minimal_settings_template():
    return {
        "schema_version": 2,
        "dashboard": {
            "viewer_host": "auto",
            "viewer_scheme": "http",
            "hide_stopped_services": False,
            "protect_dashboard_service": True,
            "hidden_units": []
        },
        "services": {
            "server-dashboard": {
                "display_name": "Server Dashboard",
                "unit": "server-dashboard",
                "runtime": "docker",
                "docker_container": "server-dashboard",
                "host": "localhost",
                "port": 8029,
                "web_path": "",
                "category": "system",
                "description": "",
                "config_files": [],
                "data_paths": [],
                "volume_maps": []
            }
        },
        "auto_detect": {"enabled": False, "write_back_missing": False},
        "bootstrap": {"mode": "blank", "scan_paths": ["/opt/appdata:/config", "/opt/app:/app"]}
    }

def _write_minimal_settings_file(path=SETTINGS_PATH):
    s = _minimal_settings_template()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except Exception:
        pass
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2)
    os.replace(tmp, path)
    return s

'''
    t = t[:line_end] + helper + t[line_end:]

# --- Simple safe replacements (no regex replacement strings) ---
if 'all_units = set(s.get("services",{}).keys()) | {sv[1] for sv in SERVICES}' in t:
    t = t.replace(
        'all_units = set(s.get("services",{}).keys()) | {sv[1] for sv in SERVICES}',
        'all_units = set((s.get("services", {}) or {}).keys())'
    )

# --- Replace load_settings by slicing markers ---
a = t.find("def load_settings():")
b = t.find("\ndef save_settings(", a)
if a != -1 and b != -1:
    new_load = '''def load_settings():
    # JSON-only source of truth. If missing/invalid, auto-recover to minimal file.
    try:
        if not os.path.exists(SETTINGS_PATH):
            return _write_minimal_settings_file()

        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)

        if not isinstance(s, dict):
            raise ValueError("settings.json root must be object")

        if not isinstance(s.get("dashboard"), dict):
            s["dashboard"] = _minimal_settings_template()["dashboard"]
        if not isinstance(s.get("services"), dict):
            s["services"] = {}
        if not isinstance(s.get("auto_detect"), dict):
            s["auto_detect"] = _minimal_settings_template()["auto_detect"]
        if not isinstance(s.get("bootstrap"), dict):
            s["bootstrap"] = _minimal_settings_template()["bootstrap"]

        if "server-dashboard" not in s["services"]:
            s["services"]["server-dashboard"] = _minimal_settings_template()["services"]["server-dashboard"]

        return s

    except Exception:
        try:
            if os.path.exists(SETTINGS_PATH):
                bad = SETTINGS_PATH + ".bad-" + datetime.now().strftime("%Y%m%d_%H%M%S")
                shutil.copy2(SETTINGS_PATH, bad)
        except Exception:
            pass
        try:
            return _write_minimal_settings_file()
        except Exception:
            return _minimal_settings_template()
'''
    t = t[:a] + new_load + t[b:]

# --- Replace get_service_data by slicing markers ---
a = t.find("def get_service_data(s):")
b = t.find("\ndef build_api_response(", a)
if a != -1 and b != -1:
    new_gsd = '''def get_service_data(s):
    services = []
    svc_map = (s.get("services", {}) or {}) if isinstance(s, dict) else {}

    for unit, ov in svc_map.items():
        if not isinstance(ov, dict):
            continue

        runtime = str(ov.get("runtime", "docker")).strip()
        host = str(ov.get("host", "localhost")).strip()
        status = get_service_status(unit, runtime)
        mem = get_service_memory(unit, runtime)
        cpu = get_service_cpu(unit, runtime)

        services.append({
            "name": ov.get("display_name", unit),
            "unit": unit,
            "port": ov.get("port"),
            "category": ov.get("category", "home"),
            "description": ov.get("description", ""),
            "status": status,
            "memory_mb": round(mem, 1) if mem is not None else None,
            "cpu_pct": round(cpu, 1) if cpu is not None else None,
            "web_path": ov.get("web_path", ""),
            "config_files": ov.get("config_files", []),
            "data_paths": ov.get("data_paths", []),
            "volume_maps": ov.get("volume_maps", []),
            "runtime": runtime,
            "host": host,
            "docker_container": ov.get("docker_container", unit),
            "kiwix_zim_dir": ov.get("kiwix_zim_dir", ""),
            "kiwix_library_xml": ov.get("kiwix_library_xml", ""),
        })
    return services
'''
    t = t[:a] + new_gsd + t[b:]

# --- Replace _scan_docker by slicing markers ---
a = t.find("def _scan_docker():")
b = t.find("\ndef _scan_systemd(", a)
if a != -1 and b != -1:
    new_scan = r'''def _scan_docker():
    out, rc = run_cmd("docker ps -a --format '{{.Names}}|{{.Image}}|{{.Ports}}|{{.Status}}' 2>/dev/null", timeout=8)
    results = []
    if rc != 0 or not out.strip():
        return results

    s = load_settings()
    svc_map = (s.get("services", {}) or {}) if isinstance(s, dict) else {}
    existing_units = set(svc_map.keys())
    existing_docker_names = set()
    for _, entry in svc_map.items():
        if isinstance(entry, dict) and str(entry.get("runtime", "docker")).strip() == "docker":
            existing_docker_names.add(str(entry.get("docker_container", "")).strip())

    for line in out.strip().splitlines():
        parts = line.split("|")
        if len(parts) < 4:
            continue
        name, image, ports, status = parts[0], parts[1], parts[2], parts[3]

        if name == "services-server-dashboard-service-1":
            continue
        if name in existing_units or name in existing_docker_names:
            continue

        suggested = None
        pm = re.search(r':(\d+)->', ports)
        if pm:
            try:
                suggested = int(pm.group(1))
            except Exception:
                suggested = None

        results.append({
            "container": name,
            "image": image,
            "ports": ports,
            "status": status,
            "suggested_port": suggested
        })
    return results
'''
    t = t[:a] + new_scan + t[b:]

if t == orig:
    print("No changes applied.")
else:
    bak = p.with_name("server.py.bak.json_only_patch_safe")
    bak.write_text(orig, encoding="utf-8")
    p.write_text(t, encoding="utf-8")
    print(f"Patched successfully. Backup: {bak}")
