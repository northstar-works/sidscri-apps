@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM ============================================================
REM  make1_zip_SyncTool-WebServerToPackaged-Zip.bat
REM  - Writes ZIP to: <repo_root>\logs\zips\
REM  - Writes zip + logs to: <repo_root>\logs\zips\
REM  - ZIP contains a versioned root folder:
REM      SyncTool-WebServerToPackaged-vX.X.X_bY\...
REM ============================================================

set "TOOL_DIR=%~dp0"
set "TOOL_DIR=%TOOL_DIR:~0,-1%"

for %%I in ("%TOOL_DIR%\..\..") do set "REPO_ROOT=%%~fI"

set "LOGDIR=%REPO_ROOT%\logs\zips"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1

for /f "usebackq delims=" %%T in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-Date).ToString('yyyyMMdd_HHmmss')"`) do set "TS=%%T"
set "LOGFILE=%LOGDIR%\make1_zip_SyncTool-WebServerToPackaged_%TS%.log"

set "VERSION_JSON=%TOOL_DIR%\version.json"
set "OUTDIR=%REPO_ROOT%\logs\zips"

echo [START] %DATE% %TIME% > "%LOGFILE%"
echo TOOL_DIR=%TOOL_DIR%>>"%LOGFILE%"
echo REPO_ROOT=%REPO_ROOT%>>"%LOGFILE%"
echo VERSION_JSON=%VERSION_JSON%>>"%LOGFILE%"
echo OUTDIR=%OUTDIR%>>"%LOGFILE%"

if not exist "%VERSION_JSON%" (
  echo [ERROR] version.json not found: %VERSION_JSON%
  echo [ERROR] version.json not found: %VERSION_JSON%>>"%LOGFILE%"
  exit /b 1
)

for /f "usebackq delims=" %%V in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$j = Get-Content -Raw '%VERSION_JSON%' | ConvertFrom-Json; Write-Output $j.version"`) do set "VER=%%V"
for /f "usebackq delims=" %%B in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$j = Get-Content -Raw '%VERSION_JSON%' | ConvertFrom-Json; Write-Output $j.build"`) do set "BUILD=%%B"
for /f "usebackq delims=" %%N in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$j = Get-Content -Raw '%VERSION_JSON%' | ConvertFrom-Json; Write-Output $j.name"`) do set "TOOL_NAME=%%N"

if "%TOOL_NAME%"=="" set "TOOL_NAME=SyncTool-WebServerToPackaged"

if "%VER%"=="" (
  echo [ERROR] Could not read version from version.json
  echo [ERROR] Could not read version from version.json>>"%LOGFILE%"
  exit /b 1
)
if "%BUILD%"=="" (
  echo [ERROR] Could not read build from version.json
  echo [ERROR] Could not read build from version.json>>"%LOGFILE%"
  exit /b 1
)

set "ROOT_NAME=%TOOL_NAME%-v%VER%_b%BUILD%"
set "ZIP_NAME=%ROOT_NAME%.zip"
set "ZIP_PATH=%OUTDIR%\%ZIP_NAME%"

REM Staging folder (keeps zip root folder versioned)
set "STAGE_ROOT=%TOOL_DIR%\_zip_staging"
set "STAGE_DIR=%STAGE_ROOT%\%ROOT_NAME%"

if exist "%STAGE_ROOT%" rmdir /s /q "%STAGE_ROOT%" >nul 2>&1
mkdir "%STAGE_DIR%" >nul 2>&1

echo [INFO] Staging to: %STAGE_DIR%
echo [INFO] Creating : %ZIP_PATH%
echo [INFO] Staging to: %STAGE_DIR%>>"%LOGFILE%"
echo [INFO] Creating : %ZIP_PATH%>>"%LOGFILE%"

REM Copy tool into staged versioned folder, excluding junk
robocopy "%TOOL_DIR%" "%STAGE_DIR%" /MIR ^
  /XD "%TOOL_DIR%\output" "%TOOL_DIR%\logs" "%TOOL_DIR%\__pycache__" "%TOOL_DIR%\sync_backups" "%TOOL_DIR%\.git" "%TOOL_DIR%\_zip_staging" ^
  /XF "*.log" "*.zip" > "%LOGFILE%.robocopy.txt"

if errorlevel 8 (
  echo [ERROR] Robocopy failed.
  echo [ERROR] Robocopy failed.>>"%LOGFILE%"
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$zipPath = '%ZIP_PATH%';" ^
  "$src = '%STAGE_DIR%';" ^
  "if (Test-Path $zipPath) { Remove-Item -Force $zipPath };" ^
  "Compress-Archive -Path $src -DestinationPath $zipPath -Force;" ^
  "Write-Host ('[OK] Wrote: ' + $zipPath);" >> "%LOGFILE%" 2>&1

if errorlevel 1 (
  echo [ERROR] Zip failed.
  echo [ERROR] Zip failed.>>"%LOGFILE%"
  exit /b 1
)

REM Cleanup staging
rmdir /s /q "%STAGE_ROOT%" >nul 2>&1

echo [DONE] %ZIP_PATH%
echo [DONE] %ZIP_PATH%>>"%LOGFILE%"
exit /b 0
