# Changelog — SyncTool-WebServerToPackaged

## v3.0.3 (build 13) — 2026-02-03
- Relocated/validated for running from `tools\SyncTool-WebServerToPackaged`.
- Updated `sync_webserver.bat` defaults to point to projects at `..\..\KenpoFlashcardsWebServer` and `..\..\KenpoFlashcardsWebServer_Packaged`.
- Added standard metadata + docs (`version.json`, `README.md`, `CHANGELOG.md`).
- Added `make_zip.bat` to produce a versioned zip into `output\`.

