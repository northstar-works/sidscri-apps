# Cloud Backup Manager UI - merged advanced version

This version starts from the `cloud-backup-manager-ui` package and folds in the main improvements from `cloud-backup-advanced`, then adds a cleaner UI.

## Included features

- Advanced web UI with a cleaner dashboard look
- Live progress bar with percent, transferred size, speed, and ETA
- Run selected job
- Run all enabled jobs
- Run jobs by group (cloud / nas / usb)
- Pause / resume / stop active job
- Per-job cards with quick actions
- Add, edit, enable, disable, and delete job definitions in the UI
- Schedule changes in the UI
- Per-job log viewing and log download
- Danger area for deleting backup destinations
- Support for raw folder backups and Kopia repo backups
- Copy vs sync mode per job
- Backward-compatible endpoints:
  - `/run`
  - `/status`
  - `/logs`
  - `/healthz`
- Dashboard-friendly status endpoint:
  - `/api/status`

## Important backup behavior

### copy
- Only transfers new or changed files
- Does not delete files from destination
- Safer default
- Best default for Kopia repo backups

### sync
- Only transfers new or changed files
- Deletes destination files that no longer exist in source
- Better only when you want a strict mirror

## Suggested mount points

- `/opt/app -> /opt-app`
- `/opt/appdata -> /appdata`
- `/opt/stacks -> /opt-stacks`
- `/opt/appdata/ops/kopia -> /kopia-repo`
- `/mnt/lan -> /backup-nas`
- `/media -> /backup-usb`

Adjust these if your real paths differ.

## Install

Copy files into `/opt/stacks/cloud-backup/` then run:

```bash
cd /opt/stacks/cloud-backup
docker compose down
docker compose up -d --build
```

## Main UI

- `http://YOUR-SERVER-IP:8092/ui`

## Notes

- `jobs.json` remains the main editable job definition file.
- The UI now shows source-path existence per job.
- Log download is available from the UI or via `/logs/download?job_id=YOUR_JOB_ID`.


## New in this patch

- Google Drive jobs automatically use faster defaults for transfers, checkers, chunk size, and buffer size.
- Appdata jobs automatically exclude SQLite WAL/SHM, logs, cache, and tmp paths.
- App/code jobs automatically exclude .venv, __pycache__, .cache, and node_modules.
- Added an **Archive first before upload (.tar.gz)** option in the job editor.
