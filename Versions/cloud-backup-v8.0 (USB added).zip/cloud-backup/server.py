import json
import os
import re
import shlex
import signal
import subprocess
import threading
import time
import tempfile
import tarfile
from collections import deque
from pathlib import Path
from typing import Dict, Any

from flask import Flask, jsonify, request, Response, send_file

app = Flask(__name__)

PORT = int(os.environ.get("PORT", "8088"))
LOG_DIR = Path(os.environ.get("LOG_DIR", "/logs"))
JOBS_FILE = Path(os.environ.get("JOBS_FILE", "/app/jobs.json"))
USB_MOUNT_ROOT = Path(os.environ.get("USB_MOUNT_ROOT", "/backup-usb"))
USB_BACKUP_SUBDIR = os.environ.get("USB_BACKUP_SUBDIR", "service-server-backup").strip("/ ") or "service-server-backup"
USB_BACKUP_ROOT = USB_MOUNT_ROOT / USB_BACKUP_SUBDIR
ARCHIVE_TEMP_DIR = Path(os.environ.get("ARCHIVE_TEMP_DIR", str(USB_BACKUP_ROOT / ".tmp-archives")))
KOPIA_USB_REPO_DIR = Path(os.environ.get("KOPIA_USB_REPO_DIR", str(USB_BACKUP_ROOT / "kopia-repo")))
STATUS_LOCK = threading.Lock()

DEFAULT_JOBS = {}

STARTER_JOBS = {
    "opt_app_gdrive": {
        "name": "Backup /opt/app to Google Drive",
        "src": "/opt/app",
        "dest": "gdrive:server-backups/opt/app",
        "mode": "copy",
        "enabled": True,
        "schedule": "01:00",
        "source_type": "folder",
        "dest_type": "cloud",
        "group": "cloud",
        "extra_flags": "--copy-links"
    },
    "opt_appdata_gdrive": {
        "name": "Backup /opt/appdata to Google Drive",
        "src": "/opt/appdata",
        "dest": "gdrive:server-backups/opt/appdata",
        "mode": "copy",
        "enabled": True,
        "schedule": "02:00",
        "source_type": "appdata",
        "dest_type": "cloud",
        "group": "cloud",
        "extra_flags": "--copy-links"
    },
    "opt_stacks_gdrive": {
        "name": "Backup /opt/stacks to Google Drive",
        "src": "/opt/stacks",
        "dest": "gdrive:server-backups/opt/stacks",
        "mode": "copy",
        "enabled": True,
        "schedule": "03:00",
        "source_type": "folder",
        "dest_type": "cloud",
        "group": "cloud",
        "extra_flags": "--copy-links"
    }
}



GDRIVE_DEFAULT_FLAGS = [
    "--fast-list",
    "--checkers=24",
    "--transfers=12",
    "--drive-chunk-size=128M",
    "--buffer-size=32M",
]

APPDATA_EXCLUDES = [
    "--exclude", "*.db-wal",
    "--exclude", "*.db-shm",
    "--exclude", "logs/**",
    "--exclude", "Cache/**",
    "--exclude", "cache/**",
    "--exclude", "tmp/**",
]

CODE_EXCLUDES = [
    "--exclude", ".venv/**",
    "--exclude", "__pycache__/**",
    "--exclude", ".cache/**",
    "--exclude", "node_modules/**",
]

RCLONE_PROGRESS_RE = re.compile(
    r"^(?:Transferred:\s+)?(?P<xfer>.+?)\s+/\s+(?P<total>.+?),\s+(?P<pct>\d+)%.*?,\s+(?P<speed>[^,]+?)(?:,\s+ETA\s+(?P<eta>[^\(]+?))?(?:\s+\(xfr#.*\))?$"
)

state = {
    "running": False,
    "paused": False,
    "job_id": None,
    "job_name": None,
    "started_at": None,
    "completed_at": None,
    "last_run": None,
    "last_error": None,
    "queue": [],
    "last_lines": deque(maxlen=300),
    "progress": {
        "percent": 0,
        "transferred": "",
        "total": "",
        "speed": "",
        "eta": "",
        "current_file": "",
        "raw": "idle"
    },
    "job_runtime": {}
}

current_process = None
last_schedule_hits = {}

def ensure_storage_paths():
    candidates = [USB_BACKUP_ROOT, ARCHIVE_TEMP_DIR, KOPIA_USB_REPO_DIR]
    for path in candidates:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass



def now_str() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def ensure_jobs_file():
    if not JOBS_FILE.exists():
        save_jobs(json.loads(json.dumps(STARTER_JOBS)))


def _fix_job_defaults(jobs: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    changed = False
    path_map = {
        "/opt-app": "/opt/app",
        "/appdata": "/opt/appdata",
        "/opt-stacks": "/opt/stacks",
    }
    for job in jobs.values():
        src = str(job.get("src", "")).strip()
        if src in path_map:
            job["src"] = path_map[src]
            changed = True
        extra = str(job.get("extra_flags", "")).strip()
        flag_parts = shlex.split(extra) if extra else []
        new_parts = apply_default_job_flags(job, list(flag_parts))
        new_extra = " ".join(new_parts).strip()
        if new_extra != extra:
            job["extra_flags"] = new_extra
            changed = True
        if "archive_first" not in job:
            job["archive_first"] = False
            changed = True
    if changed:
        save_jobs(jobs)
    return jobs


def load_jobs() -> Dict[str, Dict[str, Any]]:
    ensure_jobs_file()
    try:
        with open(JOBS_FILE, "r", encoding="utf-8") as f:
            jobs = json.load(f)
            if isinstance(jobs, dict):
                return _fix_job_defaults(jobs)
    except Exception:
        pass
    jobs = json.loads(json.dumps(STARTER_JOBS))
    save_jobs(jobs)
    return jobs


def save_jobs(jobs: Dict[str, Dict[str, Any]]):
    JOBS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = JOBS_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(jobs, f, indent=2)
        f.write("\n")
    tmp.replace(JOBS_FILE)




def resolve_source_path(src: str) -> str:
    src = str(src or '').strip()
    path_map = {
        '/opt-app': '/opt/app',
        '/appdata': '/opt/appdata',
        '/opt-stacks': '/opt/stacks',
    }
    if src in path_map:
        src = path_map[src]
    return src


def source_exists(src: str) -> bool:
    src = resolve_source_path(src)
    return bool(src) and Path(src).exists()

def normalize_job_id(value: str) -> str:
    value = (value or "").strip().lower().replace(" ", "_")
    value = re.sub(r"[^a-z0-9_\-]+", "", value)
    return value[:80]


def log_path(job_id: str) -> Path:
    return LOG_DIR / f"{job_id}.log"


def append_log(job_id: str, line: str):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with open(log_path(job_id), "a", encoding="utf-8", errors="ignore") as f:
        f.write(line.rstrip("\n") + "\n")
    with STATUS_LOCK:
        state["last_lines"].append(line.rstrip("\n"))


def read_log_tail(job_id: str, max_lines: int = 160):
    path = log_path(job_id)
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return [line.rstrip("\n") for line in f.readlines()[-max_lines:]]


def reset_progress():
    with STATUS_LOCK:
        state["progress"] = {
            "percent": 0,
            "transferred": "",
            "total": "",
            "speed": "",
            "eta": "",
            "current_file": "",
            "raw": "idle"
        }
        state["last_lines"].clear()


def ensure_runtime_records():
    jobs = load_jobs()
    with STATUS_LOCK:
        for jid, job in jobs.items():
            state["job_runtime"].setdefault(jid, {
                "job_name": job.get("name", jid),
                "state": "idle",
                "last_run": None,
                "last_error": None,
                "last_success": None,
                "started_at": None,
                "completed_at": None,
                "percent": 0,
                "speed": "",
                "eta": "",
                "transferred": "",
                "total": "",
                "progress_raw": "idle",
                "paused": False,
            })


def set_state(**kwargs):
    with STATUS_LOCK:
        state.update(kwargs)


def update_job_runtime(job_id: str, **kwargs):
    ensure_runtime_records()
    with STATUS_LOCK:
        state["job_runtime"].setdefault(job_id, {})
        state["job_runtime"][job_id].update(kwargs)


def validate_job(job):
    errors = []
    if not str(job.get("name", "")).strip():
        errors.append("name is required")
    if not str(job.get("src", "")).strip():
        errors.append("src is required")
    if not str(job.get("dest", "")).strip():
        errors.append("dest is required")
    mode = str(job.get("mode", "copy")).strip().lower()
    if mode not in {"copy", "sync"}:
        errors.append("mode must be copy or sync")
    sched = str(job.get("schedule", "")).strip()
    if sched and not re.match(r"^\d{2}:\d{2}$", sched):
        errors.append("schedule must be HH:MM or blank")
    return errors


def parse_progress_line(line: str):
    line = line.strip()
    if not line:
        return
    m = RCLONE_PROGRESS_RE.search(line)
    if m:
        progress = {
            "percent": int(m.group("pct")),
            "transferred": m.group("xfer").strip(),
            "total": m.group("total").strip(),
            "speed": (m.group("speed") or "").strip(),
            "eta": (m.group("eta") or "").strip(),
            "raw": line,
        }
        with STATUS_LOCK:
            state["progress"].update(progress)
            state["job_runtime"].setdefault(state.get("job_id") or "unknown", {}).update(progress)
        return
    if line.startswith("Transferred:") or line.startswith("*"):
        with STATUS_LOCK:
            state["progress"]["current_file"] = line
            state["progress"]["raw"] = line
            jid = state.get("job_id")
            if jid:
                state["job_runtime"].setdefault(jid, {})["progress_raw"] = line


def has_flag(parts, flag: str) -> bool:
    return any(p == flag or p.startswith(flag + "=") for p in parts)


def ensure_flag(parts, flag: str):
    if not has_flag(parts, flag):
        parts.append(flag)


def append_pair_if_missing(parts, key: str, value: str):
    for i, p in enumerate(parts):
        if p == key and i + 1 < len(parts) and parts[i + 1] == value:
            return
    parts.extend([key, value])


def apply_default_job_flags(job, flag_parts):
    source_type = str(job.get("source_type", "")).strip().lower()
    src = str(job.get("src", "")).strip().lower()
    dest = str(job.get("dest", "")).strip()

    if not has_flag(flag_parts, "--copy-links") and "-L" not in flag_parts:
        flag_parts.append("--copy-links")

    if ":" in dest:
        for f in GDRIVE_DEFAULT_FLAGS:
            ensure_flag(flag_parts, f)

    if source_type == "appdata" or src.startswith("/opt/appdata"):
        for i in range(0, len(APPDATA_EXCLUDES), 2):
            append_pair_if_missing(flag_parts, APPDATA_EXCLUDES[i], APPDATA_EXCLUDES[i+1])

    if source_type in {"folder", "code", "app"} or src.startswith("/opt/app") or "advanced-flashcards" in src or src.startswith("/opt/stacks"):
        for i in range(0, len(CODE_EXCLUDES), 2):
            append_pair_if_missing(flag_parts, CODE_EXCLUDES[i], CODE_EXCLUDES[i+1])

    return flag_parts


def create_archive_for_job(job_id: str, src: str) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    safe_name = re.sub(r"[^a-zA-Z0-9_.-]+", "_", f"{job_id}_{stamp}")
    base_dir = ARCHIVE_TEMP_DIR
    try:
        base_dir.mkdir(parents=True, exist_ok=True)
        temp_dir = Path(tempfile.mkdtemp(prefix=f"cb_{job_id}_", dir=str(base_dir)))
    except Exception:
        temp_dir = Path(tempfile.mkdtemp(prefix=f"cb_{job_id}_"))
    archive_path = temp_dir / f"{safe_name}.tar.gz"
    append_log(job_id, f"{now_str()} Creating archive: {archive_path}")
    with tarfile.open(archive_path, "w:gz") as tf:
        tf.add(src, arcname=Path(src).name)
    append_log(job_id, f"{now_str()} Archive ready: {archive_path}")
    return archive_path


def build_archive_rclone_cmd(job, archive_path: Path):
    dest = str(job.get("dest", "")).rstrip("/")
    target = f"{dest}/{archive_path.name}" if dest else archive_path.name
    cmd = [
        "rclone", "copyto", str(archive_path), target,
        "--stats=2s", "--stats-one-line", "--stats-log-level", "NOTICE",
        "--log-level", "NOTICE",
    ]
    flag_parts = shlex.split(str(job.get("extra_flags", "")).strip()) if str(job.get("extra_flags", "")).strip() else []
    flag_parts = apply_default_job_flags(job, flag_parts)
    cmd.extend(flag_parts)
    return cmd


def build_rclone_cmd(job):
    mode = str(job.get("mode", "copy")).lower()
    src = resolve_source_path(job.get("src", ""))
    job["src"] = src
    cmd = [
        "rclone", mode, src, job["dest"],
        "--stats=2s", "--stats-one-line", "--stats-log-level", "NOTICE",
        "--log-level", "NOTICE",
        "--create-empty-src-dirs",
    ]
    extra_flags = str(job.get("extra_flags", "")).strip()
    flag_parts = shlex.split(extra_flags) if extra_flags else []
    flag_parts = apply_default_job_flags(job, flag_parts)
    cmd.extend(flag_parts)
    return cmd


def build_delete_cmd(job, hard_delete):
    if hard_delete:
        return ["rclone", "purge", job["dest"]]
    return ["rclone", "delete", job["dest"]]


def job_snapshot(jid: str, job: Dict[str, Any]) -> Dict[str, Any]:
    ensure_runtime_records()
    with STATUS_LOCK:
        rt = dict(state["job_runtime"].get(jid, {}))
        running = state["running"] and state.get("job_id") == jid
        paused = state["paused"] and running
    return {
        "id": jid,
        "name": job.get("name", jid),
        "src": job.get("src", ""),
        "dest": job.get("dest", ""),
        "mode": job.get("mode", "copy"),
        "enabled": bool(job.get("enabled", True)),
        "schedule": job.get("schedule", ""),
        "source_type": job.get("source_type", ""),
        "dest_type": job.get("dest_type", ""),
        "group": job.get("group", ""),
        "extra_flags": job.get("extra_flags", ""),
        "archive_first": bool(job.get("archive_first", False)),
        "source_exists": source_exists(job.get("src", "")),
        "running": running,
        "paused": paused,
        "runtime": rt,
        "log_file": str(log_path(jid)),
    }


def run_job(job_id: str):
    global current_process
    jobs = load_jobs()
    job = jobs.get(job_id)
    if not job:
        set_state(last_error=f"Unknown job: {job_id}")
        return
    if state["running"]:
        set_state(last_error="Another job is already running.")
        return

    reset_progress()
    set_state(
        running=True,
        paused=False,
        job_id=job_id,
        job_name=job.get("name", job_id),
        started_at=now_str(),
        completed_at=None,
        last_error=None,
    )
    update_job_runtime(
        job_id,
        job_name=job.get("name", job_id),
        state="starting",
        paused=False,
        started_at=now_str(),
        completed_at=None,
        last_error=None,
        percent=0,
        speed="",
        eta="",
        transferred="",
        total="",
        progress_raw="starting",
    )

    append_log(job_id, f"{now_str()} Backup started: {job.get('name', job_id)}")
    append_log(job_id, f"Mode: {job.get('mode', 'copy')}")
    append_log(job_id, f"Source: {job['src']}")
    append_log(job_id, f"Destination: {job['dest']}")

    job['src'] = resolve_source_path(job.get('src', ''))
    if not source_exists(job['src']):
        msg = f"Source path not found: {job['src']}"
        set_state(running=False, paused=False, last_error=msg, last_run=now_str(), completed_at=now_str(), job_id=None, job_name=None)
        update_job_runtime(job_id, state="error", last_error=msg, last_run=now_str(), completed_at=now_str(), paused=False)
        append_log(job_id, f"{now_str()} ERROR: {msg}")
        return

    archive_path = None
    archive_temp_dir = None
    if bool(job.get("archive_first", False)):
        archive_path = create_archive_for_job(job_id, job["src"])
        archive_temp_dir = archive_path.parent
        cmd = build_archive_rclone_cmd(job, archive_path)
    else:
        cmd = build_rclone_cmd(job)
    append_log(job_id, 'Command: ' + ' '.join(shlex.quote(part) for part in cmd))

    try:
        current_process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        assert current_process.stdout is not None
        update_job_runtime(job_id, state="running")
        for raw_line in current_process.stdout:
            line = raw_line.rstrip("\n")
            append_log(job_id, line)
            parse_progress_line(line)
        rc = current_process.wait()
        if rc == 0:
            append_log(job_id, f"{now_str()} Backup completed OK")
            update_job_runtime(job_id, state="completed", last_error=None, last_success=now_str(), last_run=now_str(), completed_at=now_str(), paused=False)
            set_state(last_error=None)
        else:
            msg = f"rclone exited with code {rc}"
            append_log(job_id, f"{now_str()} ERROR: {msg}")
            update_job_runtime(job_id, state="error", last_error=msg, last_run=now_str(), completed_at=now_str(), paused=False)
            set_state(last_error=msg)
    except Exception as e:
        msg = str(e)
        append_log(job_id, f"{now_str()} EXCEPTION: {msg}")
        update_job_runtime(job_id, state="error", last_error=msg, last_run=now_str(), completed_at=now_str(), paused=False)
        set_state(last_error=msg)
    finally:
        if archive_temp_dir:
            try:
                for child in archive_temp_dir.iterdir():
                    child.unlink(missing_ok=True)
                archive_temp_dir.rmdir()
            except Exception:
                pass
        set_state(running=False, paused=False, last_run=now_str(), completed_at=now_str(), job_id=None, job_name=None)
        current_process = None


def queue_worker(job_ids):
    set_state(queue=list(job_ids))
    for jid in list(job_ids):
        jobs = load_jobs()
        if jid not in jobs:
            continue
        run_job(jid)
        with STATUS_LOCK:
            state["queue"] = [x for x in state["queue"] if x != jid]


def start_job(job_id: str):
    threading.Thread(target=run_job, args=(job_id,), daemon=True).start()


def start_queue(job_ids):
    threading.Thread(target=queue_worker, args=(job_ids,), daemon=True).start()


@app.route("/")
@app.route("/ui")
def ui():
    return '''<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Cloud Backup Manager</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    :root {
      --bg: #09111f;
      --panel: #101a2e;
      --panel2: #0e1628;
      --card: rgba(16, 26, 46, 0.92);
      --line: rgba(148, 163, 184, 0.16);
      --text: #e5eefc;
      --muted: #9fb0c9;
      --good: #22c55e;
      --warn: #f59e0b;
      --bad: #ef4444;
      --accent: #60a5fa;
      --accent2: #22d3ee;
      --shadow: 0 20px 45px rgba(0,0,0,.28);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Inter, Arial, sans-serif;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(34,211,238,.14), transparent 24%),
        radial-gradient(circle at top right, rgba(96,165,250,.14), transparent 18%),
        linear-gradient(180deg, #08101d, #0b1323 55%, #09111f 100%);
    }
    .wrap { max-width: 1500px; margin: 0 auto; padding: 22px; }
    .hero {
      display: grid; grid-template-columns: 1.5fr .9fr; gap: 18px; margin-bottom: 18px;
    }
    .panel {
      background: var(--card);
      border: 1px solid var(--line);
      border-radius: 22px;
      box-shadow: var(--shadow);
      backdrop-filter: blur(8px);
    }
    .hero-main { padding: 22px; }
    .hero-side { padding: 18px; }
    h1,h2,h3 { margin: 0 0 10px; }
    .sub { color: var(--muted); font-size: 14px; }
    .toolbar, .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    .toolbar { margin-top: 18px; }
    .btn, input, select, textarea {
      border-radius: 14px; border: 1px solid var(--line); background: rgba(11,19,35,.9); color: var(--text);
      padding: 11px 14px; font-size: 14px;
    }
    .btn { cursor: pointer; font-weight: 600; }
    .btn:hover { transform: translateY(-1px); }
    .primary { background: linear-gradient(90deg, #2563eb, #06b6d4); border-color: rgba(96,165,250,.55); }
    .secondary { background: linear-gradient(90deg, #1f2937, #0f172a); }
    .good { background: linear-gradient(90deg, #166534, #15803d); }
    .warn { background: linear-gradient(90deg, #92400e, #b45309); }
    .danger { background: linear-gradient(90deg, #7f1d1d, #991b1b); }
    input, select, textarea { width: 100%; }
    .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 16px; }
    .stat { padding: 14px; border-radius: 18px; background: rgba(8, 15, 28, .76); border: 1px solid var(--line); }
    .label { color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .08em; }
    .value { font-size: 20px; font-weight: 700; margin-top: 6px; }
    .progress-shell { margin-top: 14px; padding: 14px; border-radius: 18px; background: rgba(8,15,28,.72); border: 1px solid var(--line); }
    .progress { height: 18px; border-radius: 999px; background: #0a1324; overflow: hidden; border: 1px solid rgba(148,163,184,.12); }
    .bar { height: 100%; width: 0%; background: linear-gradient(90deg, #2563eb, #22c55e, #22d3ee); transition: width .35s ease; }
    .small { font-size: 12px; color: var(--muted); }
    .grid { display: grid; grid-template-columns: 1.25fr .95fr; gap: 18px; margin-bottom: 18px; }
    .stack { display: grid; gap: 18px; }
    .section { padding: 18px; }
    .job-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(295px, 1fr)); gap: 14px; }
    .job-card {
      border: 1px solid var(--line); border-radius: 20px; padding: 16px;
      background: linear-gradient(180deg, rgba(14,22,40,.95), rgba(8,15,28,.88));
    }
    .job-title { display: flex; align-items: start; justify-content: space-between; gap: 8px; }
    .pill { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; font-size:12px; border:1px solid var(--line); background: rgba(15,23,42,.8); color: var(--muted); }
    .pill.good { color: #dcfce7; }
    .pill.warn { color: #ffedd5; }
    .pill.bad { color: #fee2e2; }
    .job-meta { display:grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 12px 0; }
    .meta-box { padding: 10px; border-radius: 14px; background: rgba(9,17,31,.72); border: 1px solid var(--line); }
    .actions { display:flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
    .two-col { display:grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .logbox {
      min-height: 350px; max-height: 54vh; overflow: auto; white-space: pre-wrap;
      background: #020817; color: #d6e2ff; border: 1px solid var(--line); border-radius: 18px; padding: 16px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px;
    }
    .danger-panel { border-color: rgba(239,68,68,.28); }
    .danger-panel h3 { color: #fecaca; }
    .muted { color: var(--muted); }
    .ok-dot, .warn-dot, .bad-dot { width: 10px; height: 10px; border-radius: 50%; display:inline-block; }
    .ok-dot { background: var(--good); }
    .warn-dot { background: var(--warn); }
    .bad-dot { background: var(--bad); }
    .job-toolbar { display:flex; gap:8px; flex-wrap: wrap; margin-top: 10px; }
    @media (max-width: 1080px) {
      .hero, .grid { grid-template-columns: 1fr; }
      .stats { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 700px) {
      .stats, .two-col { grid-template-columns: 1fr; }
      .wrap { padding: 14px; }
    }
  </style>
</head>
<body>
<div class="wrap">
  <div class="hero">
    <div class="panel hero-main">
      <div style="display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;align-items:center;">
        <div>
          <h1>Cloud Backup Manager</h1>
          <div class="sub">Advanced multi-job backup UI with live progress, queue controls, per-job management, and log downloads.</div>
        </div>
        <div class="pill"><span class="ok-dot"></span> API ready: /api/status</div>
      </div>

      <div class="toolbar">
        <select id="jobSelect" style="max-width:280px"></select>
        <button class="btn primary" onclick="runSelected()">Run Selected</button>
        <button class="btn secondary" onclick="runAllEnabled()">Run All Enabled</button>
        <button class="btn secondary" onclick="runGroup('cloud')">Run Cloud</button>
        <button class="btn secondary" onclick="runGroup('nas')">Run NAS</button>
        <button class="btn secondary" onclick="runGroup('usb')">Run USB</button>
        <button class="btn warn" onclick="pauseJob()">Pause</button>
        <button class="btn good" onclick="resumeJob()">Resume</button>
        <button class="btn danger" onclick="stopJob()">Stop</button>
        <button class="btn secondary" onclick="refreshAll()">Refresh</button>
      </div>

      <div class="stats">
        <div class="stat"><div class="label">Running</div><div class="value" id="runningValue">No</div></div>
        <div class="stat"><div class="label">Current Job</div><div class="value" id="jobValue">None</div></div>
        <div class="stat"><div class="label">Speed</div><div class="value" id="speedValue">-</div></div>
        <div class="stat"><div class="label">ETA</div><div class="value" id="etaValue">-</div></div>
      </div>

      <div class="progress-shell">
        <div class="row" style="justify-content:space-between;margin-bottom:8px;">
          <div><strong id="pctText">0%</strong></div>
          <div class="small" id="xferText">No transfer yet</div>
        </div>
        <div class="progress"><div class="bar" id="bar"></div></div>
        <div class="row" style="justify-content:space-between;margin-top:10px;">
          <div class="small" id="currentText">Idle</div>
          <div class="small" id="lastRunText">Last run: never</div>
        </div>
        <div class="small" id="errorText" style="margin-top:8px;color:#fca5a5"></div>
      </div>
    </div>

    <div class="panel hero-side">
      <h3>Quick Summary</h3>
      <div class="stack" style="margin-top:12px;">
        <div class="stat"><div class="label">Enabled Jobs</div><div class="value" id="enabledCount">0</div></div>
        <div class="stat"><div class="label">Queue Depth</div><div class="value" id="queueCount">0</div></div>
        <div class="stat"><div class="label">Cloud / NAS / USB</div><div class="value" id="groupCounts">0 / 0 / 0</div></div>
        <div class="stat"><div class="label">Selected Job Log</div><div class="value"><button class="btn secondary" style="width:100%" onclick="downloadLog()">Download Log</button></div></div>
      </div>
    </div>
  </div>

  <div class="grid">
    <div class="stack">
      <div class="panel section">
        <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;">
          <div>
            <h2>Backup Jobs</h2>
            <div class="small">Run, edit, and watch each job individually.</div>
          </div>
        </div>
        <div id="jobsGrid" class="job-grid" style="margin-top:14px;"></div>
      </div>

      <div class="panel section">
        <h2>Live Log Tail</h2>
        <div class="small" style="margin-bottom:12px;">Shows the selected job log, or the active running job when one is in progress.</div>
        <div id="logBox" class="logbox">Loading...</div>
      </div>
    </div>

    <div class="stack">
      <div class="panel section">
        <h2>Add / Edit Job</h2>
        <div class="small" style="margin-bottom:12px;">This version uses guided dropdowns and named fields so building a job is much easier.</div>

        <div class="small" style="margin-bottom:8px;font-weight:700;">Templates</div>
        <div class="job-toolbar" style="margin-top:0;margin-bottom:12px;flex-wrap:wrap;">
          <button class="btn secondary" onclick="applyTemplate('appdata_cloud')">Appdata → Cloud</button>
          <button class="btn secondary" onclick="applyTemplate('optapp_cloud')">/opt/app → Cloud</button>
          <button class="btn secondary" onclick="applyTemplate('flashcards_cloud')">Flashcards → Cloud</button>
        </div>

        <div class="two-col">
          <div>
            <div class="small" style="margin-bottom:6px;">Job ID</div>
            <input id="job_id" placeholder="opt_app_gdrive">
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Job Name</div>
            <input id="name" placeholder="Backup /opt/app to Google Drive">
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Folder To Backup</div>
            <select id="src_picker" onchange="onSourcePickerChange()">
              <option value="/opt/app">/opt/app</option>
              <option value="/opt/appdata">/opt/appdata</option>
              <option value="/home">/home</option>
              <option value="/mnt/media">/mnt/media</option>
              <option value="/mnt/lan">/mnt/lan</option>
              <option value="/opt/app/advanced-flashcards">/opt/app/advanced-flashcards</option>
              <option value="custom">Custom path…</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Custom Source Path</div>
            <input id="src_custom" placeholder="Only used when Custom path is selected">
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Backup Destination</div>
            <select id="dest_kind" onchange="updateDestinationUI()">
              <option value="cloud">Cloud</option>
              <option value="nas">NAS</option>
              <option value="usb">USB Drive</option>
              <option value="samba">Samba Share</option>
              <option value="local">Local Disk</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Cloud Remote</div>
            <select id="cloud_remote" onchange="updateDestinationUI()">
              <option value="gdrive">Google Drive (gdrive)</option>
              <option value="dropbox">Dropbox</option>
              <option value="b2">Backblaze B2</option>
              <option value="s3">S3</option>
              <option value="custom">Custom remote…</option>
            </select>
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Custom Cloud Remote Name</div>
            <input id="cloud_remote_custom" placeholder="Example: myremote">
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Destination Folder</div>
            <input id="dest_subpath" placeholder="Example: server-backups/opt/app">
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Mount / Base Path</div>
            <select id="mount_root" onchange="updateDestinationUI()">
              <option value="/backup-nas">/backup-nas</option>
              <option value="/backup-usb/service-server-backup">/backup-usb/service-server-backup</option>
              <option value="/backup-samba">/backup-samba</option>
              <option value="/backups">/backups</option>
              <option value="custom">Custom base path…</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Custom Base Path</div>
            <input id="mount_root_custom" placeholder="Example: /mnt/my-backups">
          </div>
        </div>

        <div class="row" style="margin-top:10px">
          <div style="width:100%">
            <div class="small" style="margin-bottom:6px;">Resolved Destination</div>
            <input id="dest" placeholder="Destination path" readonly>
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Backup Type</div>
            <select id="mode">
              <option value="copy">Copy (safer, no deletes)</option>
              <option value="sync">Sync (mirror, deletes removed files)</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Backup Mode</div>
            <select id="backup_mode">
              <option value="raw">Raw Files</option>
              <option value="compressed">Compressed Archive</option>
              <option value="encrypted">Encrypted</option>
              <option value="kopia">Kopia Repository</option>
            </select>
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Frequency</div>
            <select id="frequency" onchange="updateScheduleField()">
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="manual">Manual Only</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Run Time</div>
            <input id="schedule_time" type="time" value="01:00">
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Weekly Day</div>
            <select id="weekly_day">
              <option value="Sun">Sunday</option>
              <option value="Mon">Monday</option>
              <option value="Tue">Tuesday</option>
              <option value="Wed">Wednesday</option>
              <option value="Thu">Thursday</option>
              <option value="Fri">Friday</option>
              <option value="Sat">Saturday</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Enabled</div>
            <select id="enabled"><option value="true">Enabled</option><option value="false">Disabled</option></select>
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Source Type</div>
            <select id="source_type">
              <option value="folder">Folder</option>
              <option value="full">Full</option>
              <option value="appdata">Appdata</option>
              <option value="media">Media</option>
              <option value="vm">VM</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Destination Type</div>
            <select id="dest_type">
              <option value="cloud">Cloud</option>
              <option value="nas">NAS</option>
              <option value="usb">USB</option>
              <option value="samba">Samba</option>
              <option value="local">Local</option>
            </select>
          </div>
        </div>

        <div class="two-col" style="margin-top:10px">
          <div>
            <div class="small" style="margin-bottom:6px;">Job Group</div>
            <select id="group">
              <option value="cloud">cloud</option>
              <option value="nas">nas</option>
              <option value="usb">usb</option>
              <option value="samba">samba</option>
              <option value="local">local</option>
            </select>
          </div>
          <div>
            <div class="small" style="margin-bottom:6px;">Extra Flags</div>
            <input id="extra_flags" placeholder="Example: --copy-links --transfers=4">
          </div>
        </div>

        <div class="row" style="margin-top:10px;align-items:center;gap:10px;flex-wrap:wrap">
          <label style="display:flex;align-items:center;gap:10px;cursor:pointer">
            <input type="checkbox" id="archive_first">
            <span>Archive first before upload (.tar.gz)</span>
          </label>
        </div>

        <div class="row" style="margin-top:10px">
          <div class="small" id="schedulePreview">Runs daily at 01:00</div>
        </div>
        <div class="job-toolbar">
          <button class="btn primary" onclick="saveJob()">Save Job</button>
          <button class="btn secondary" onclick="clearForm()">Clear Form</button>
        </div>
        <div class="small" style="margin-top:10px;">Tip: Kopia repo backups are usually better as <strong>copy</strong> rather than <strong>sync</strong>.</div>
      </div>

      <div class="panel section danger-panel">
        <h3>Danger Area</h3>
        <div class="small" style="margin-bottom:12px;">Delete backup data at the destination only when you are sure.</div>
        <div class="row"><select id="dangerJobSelect"></select></div>
        <div class="two-col" style="margin-top:10px">
          <select id="deleteMode"><option value="delete">Delete files only</option><option value="purge">Purge folder and files</option></select>
          <input id="confirmText" placeholder="Type DELETE to enable">
        </div>
        <div class="job-toolbar">
          <button class="btn danger" onclick="deleteRemote()">Delete Backup Destination</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let jobsCache = {};

async function api(path, options={}) {
  const res = await fetch(path, options);
  const text = await res.text();
  try { return JSON.parse(text); } catch { return text; }
}
function escapeHtml(s='') {
  return String(s).replace(/[&<>\"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function statusPill(job) {
  if (job.running) return '<span class="pill warn">Running</span>';
  if (!job.enabled) return '<span class="pill">Disabled</span>';
  if (!job.source_exists) return '<span class="pill bad">Missing Source</span>';
  if ((job.runtime || {}).state === 'error') return '<span class="pill bad">Error</span>';
  if ((job.runtime || {}).state === 'completed') return '<span class="pill good">Ready</span>';
  return '<span class="pill">Idle</span>';
}
const TEMPLATES = {
  appdata_cloud: {job_id:'opt_appdata_gdrive', name:'Backup /opt/appdata to Google Drive', src:'/opt/appdata', dest_kind:'cloud', cloud_remote:'gdrive', dest_subpath:'server-backups/opt/appdata', mode:'copy', backup_mode:'raw', frequency:'daily', schedule_time:'02:00', enabled:true, source_type:'appdata', dest_type:'cloud', group:'cloud', extra_flags:'--copy-links'},
  optapp_cloud: {job_id:'opt_app_gdrive', name:'Backup /opt/app to Google Drive', src:'/opt/app', dest_kind:'cloud', cloud_remote:'gdrive', dest_subpath:'server-backups/opt/app', mode:'copy', backup_mode:'raw', frequency:'daily', schedule_time:'01:00', enabled:true, source_type:'folder', dest_type:'cloud', group:'cloud', extra_flags:'--copy-links'},
  flashcards_cloud: {job_id:'advanced_flashcards_gdrive', name:'Backup advanced-flashcards to Google Drive', src:'/opt/app/advanced-flashcards', dest_kind:'cloud', cloud_remote:'gdrive', dest_subpath:'server-backups/advanced-flashcards', mode:'copy', backup_mode:'raw', frequency:'daily', schedule_time:'01:30', enabled:true, source_type:'folder', dest_type:'cloud', group:'cloud', extra_flags:'--copy-links'}
};

function setValue(id, value, fallback='') {
  const el = document.getElementById(id);
  if (!el) return;
  el.value = value ?? fallback;
}
function onSourcePickerChange() {
  const picker = document.getElementById('src_picker').value;
  const custom = document.getElementById('src_custom');
  custom.disabled = picker !== 'custom';
}
function getSelectedSource() {
  const picker = document.getElementById('src_picker').value;
  return picker === 'custom' ? document.getElementById('src_custom').value.trim() : picker;
}
function getMountRoot() {
  const kind = document.getElementById('dest_kind').value;
  const picker = document.getElementById('mount_root').value;
  const custom = document.getElementById('mount_root_custom').value.trim();
  const selected = picker === 'custom' ? custom : picker;
  if (kind === 'nas' && !selected) return '/backup-nas';
  if (kind === 'usb' && !selected) return '/backup-usb/service-server-backup';
  if (kind === 'samba' && !selected) return '/backup-samba';
  if (kind === 'local' && !selected) return '/backups';
  return selected;
}
function getCloudRemote() {
  const picker = document.getElementById('cloud_remote').value;
  return picker === 'custom' ? document.getElementById('cloud_remote_custom').value.trim() : picker;
}
function buildDestination() {
  const kind = document.getElementById('dest_kind').value;
  const sub = document.getElementById('dest_subpath').value.trim().replace(/^\/+/, '');
  if (kind === 'cloud') {
    const remote = getCloudRemote();
    return remote ? `${remote}:${sub}` : '';
  }
  const root = getMountRoot();
  if (!root) return '';
  return sub ? `${root.replace(/\/$/, '')}/${sub}` : root;
}
function updateDestinationUI() {
  const kind = document.getElementById('dest_kind').value;
  const showCloud = kind === 'cloud';
  document.getElementById('cloud_remote').disabled = !showCloud;
  document.getElementById('cloud_remote_custom').disabled = !(showCloud && document.getElementById('cloud_remote').value === 'custom');
  document.getElementById('mount_root').disabled = showCloud;
  document.getElementById('mount_root_custom').disabled = showCloud || document.getElementById('mount_root').value !== 'custom';
  setValue('dest_type', kind);
  setValue('group', kind);
  setValue('dest', buildDestination());
}
function updateScheduleField() {
  const freq = document.getElementById('frequency').value;
  const time = document.getElementById('schedule_time').value || '01:00';
  const day = document.getElementById('weekly_day').value;
  document.getElementById('weekly_day').disabled = freq !== 'weekly';
  const preview = freq === 'manual' ? 'Manual only, no scheduled time.' : (freq === 'weekly' ? `Runs weekly on ${day} at ${time}` : `Runs daily at ${time}`);
  document.getElementById('schedulePreview').textContent = preview;
}
function composeSchedule() {
  const freq = document.getElementById('frequency').value;
  const time = document.getElementById('schedule_time').value || '';
  const day = document.getElementById('weekly_day').value;
  if (freq === 'manual') return '';
  if (freq === 'weekly') return `${day} ${time}`;
  return time;
}
function parseScheduleIntoUI(schedule='') {
  if (!schedule) {
    setValue('frequency', 'manual');
    setValue('schedule_time', '01:00');
    setValue('weekly_day', 'Sun');
    updateScheduleField();
    return;
  }
  const weekly = schedule.match(/^(Sun|Mon|Tue|Wed|Thu|Fri|Sat)\s+(\d{2}:\d{2})$/i);
  if (weekly) {
    setValue('frequency', 'weekly');
    setValue('weekly_day', weekly[1]);
    setValue('schedule_time', weekly[2]);
  } else {
    setValue('frequency', 'daily');
    setValue('schedule_time', schedule);
    setValue('weekly_day', 'Sun');
  }
  updateScheduleField();
}
function applyTemplate(name) {
  const t = TEMPLATES[name];
  if (!t) return;
  fillForm(t.job_id, t);
}
function formData() {
  const src = getSelectedSource();
  const backupMode = document.getElementById('backup_mode').value;
  let extraFlags = document.getElementById('extra_flags').value.trim();
  if (backupMode === 'compressed' && !extraFlags.includes('--compress')) extraFlags = `${extraFlags} --compress`.trim();
  if (backupMode === 'encrypted' && !extraFlags.includes('--crypt')) extraFlags = `${extraFlags} --crypt`.trim();
  if (backupMode === 'kopia' && !extraFlags.includes('--kopia')) extraFlags = `${extraFlags} --kopia`.trim();
  return {
    job_id: document.getElementById('job_id').value.trim(),
    name: document.getElementById('name').value.trim(),
    src,
    dest: buildDestination(),
    mode: document.getElementById('mode').value,
    schedule: composeSchedule(),
    enabled: document.getElementById('enabled').value === 'true',
    source_type: document.getElementById('source_type').value.trim(),
    dest_type: document.getElementById('dest_type').value.trim(),
    group: document.getElementById('group').value.trim(),
    extra_flags: extraFlags,
    archive_first: !!document.getElementById('archive_first')?.checked
  };
}
function fillForm(id, job) {
  const src = job.src || '/opt/app';
  const srcOptions = Array.from(document.getElementById('src_picker').options).map(o => o.value);
  if (srcOptions.includes(src)) {
    setValue('src_picker', src);
    setValue('src_custom', '');
  } else {
    setValue('src_picker', 'custom');
    setValue('src_custom', src);
  }

  const dest = job.dest || '';
  let kind = (job.dest_type || job.group || '').toLowerCase();
  if (!kind) kind = dest.includes(':') ? 'cloud' : 'local';
  if (!['cloud','nas','usb','samba','local'].includes(kind)) kind = 'local';
  setValue('dest_kind', kind);
  setValue('dest_type', kind);
  setValue('group', job.group || kind);

  if (dest.includes(':')) {
    const parts = dest.split(':');
    const remote = parts.shift();
    const sub = parts.join(':');
    const remoteOptions = Array.from(document.getElementById('cloud_remote').options).map(o => o.value);
    if (remoteOptions.includes(remote)) {
      setValue('cloud_remote', remote);
      setValue('cloud_remote_custom', '');
    } else {
      setValue('cloud_remote', 'custom');
      setValue('cloud_remote_custom', remote);
    }
    setValue('dest_subpath', sub);
  } else {
    const roots = ['/backup-nas','/backup-usb/service-server-backup','/backup-samba','/backups'];
    let matched = roots.find(r => dest === r || dest.startsWith(r + '/'));
    if (matched) {
      setValue('mount_root', matched);
      setValue('mount_root_custom', '');
      setValue('dest_subpath', dest.replace(matched, '').replace(/^\/+/, ''));
    } else {
      setValue('mount_root', 'custom');
      setValue('mount_root_custom', dest.replace(/\/[^/]*$/, '') || '/backups');
      setValue('dest_subpath', dest.split('/').slice(-1)[0] || '');
    }
  }

  setValue('job_id', id || '');
  setValue('name', job.name || '');
  setValue('mode', job.mode || 'copy');
  setValue('enabled', String(job.enabled ?? true));
  setValue('source_type', job.source_type || 'folder');
  setValue('extra_flags', job.extra_flags || '--copy-links');
  const archiveFirstEl = document.getElementById('archive_first');
  if (archiveFirstEl) archiveFirstEl.checked = !!job.archive_first;

  const ef = job.extra_flags || '';
  let bm = 'raw';
  if (ef.includes('--kopia')) bm = 'kopia';
  else if (ef.includes('--crypt')) bm = 'encrypted';
  else if (ef.includes('--compress')) bm = 'compressed';
  setValue('backup_mode', job.backup_mode || bm);

  onSourcePickerChange();
  updateDestinationUI();
  parseScheduleIntoUI(job.schedule || '');
}
function clearForm() { fillForm('', {}); }
async function refreshJobs() {
  jobsCache = await api('/jobs');
  const sel = document.getElementById('jobSelect');
  const dangerSel = document.getElementById('dangerJobSelect');
  const grid = document.getElementById('jobsGrid');
  const current = sel.value;
  sel.innerHTML = '';
  dangerSel.innerHTML = '';
  grid.innerHTML = '';

  let enabled = 0, cloud = 0, nas = 0, usb = 0;

  Object.entries(jobsCache).forEach(([id, job]) => {
    if (job.enabled) enabled++;
    if ((job.group || '').toLowerCase() === 'cloud') cloud++;
    if ((job.group || '').toLowerCase() === 'nas') nas++;
    if ((job.group || '').toLowerCase() === 'usb') usb++;

    let opt = document.createElement('option'); opt.value = id; opt.textContent = `${job.name} (${id})`; sel.appendChild(opt);
    let opt2 = document.createElement('option'); opt2.value = id; opt2.textContent = `${job.name} (${id})`; dangerSel.appendChild(opt2);

    const rt = job.runtime || {};
    const pct = Number(rt.percent || 0);
    const card = document.createElement('div');
    card.className = 'job-card';
    card.innerHTML = `
      <div class="job-title">
        <div>
          <div style="font-size:18px;font-weight:700">${escapeHtml(job.name)}</div>
          <div class="small">${escapeHtml(id)}</div>
        </div>
        <div>${statusPill(job)}</div>
      </div>
      <div class="job-meta">
        <div class="meta-box"><div class="label">Group</div><div>${escapeHtml(job.group || '-')}</div></div>
        <div class="meta-box"><div class="label">Mode</div><div>${escapeHtml(job.mode || 'copy')}</div></div>
        <div class="meta-box"><div class="label">Schedule</div><div>${escapeHtml(job.schedule || '-')}</div></div>
        <div class="meta-box"><div class="label">Destination</div><div>${escapeHtml(job.dest_type || '-')}</div></div>
      </div>
      <div class="small"><strong>Source:</strong> ${escapeHtml(job.src)}</div>
      <div class="small" style="margin-top:6px"><strong>Dest:</strong> ${escapeHtml(job.dest)}</div>
      <div class="progress-shell" style="margin-top:12px;padding:10px 12px;">
        <div class="row" style="justify-content:space-between;margin-bottom:6px;">
          <div><strong>${pct}%</strong></div>
          <div class="small">${escapeHtml(rt.speed || '-')}</div>
        </div>
        <div class="progress"><div class="bar" style="width:${pct}%"></div></div>
        <div class="small" style="margin-top:8px">${escapeHtml(rt.transferred || '')}${rt.total ? ' / ' + escapeHtml(rt.total) : ''}</div>
        <div class="small" style="margin-top:4px">${escapeHtml(rt.last_error || rt.progress_raw || 'idle')}</div>
      </div>
      <div class="actions">
        <button class="btn primary" onclick='runJobId(${JSON.stringify(id)})'>Run</button>
        <button class="btn secondary" onclick='editJob(${JSON.stringify(id)})'>Edit</button>
        <button class="btn secondary" onclick='viewLog(${JSON.stringify(id)})'>View Log</button>
        <button class="btn secondary" onclick='downloadLogFor(${JSON.stringify(id)})'>Download</button>
        <button class="btn danger" onclick='deleteJobMeta(${JSON.stringify(id)})'>Delete Job</button>
      </div>
    `;
    grid.appendChild(card);
  });

  if ([...sel.options].some(o => o.value === current)) sel.value = current;
  document.getElementById('enabledCount').textContent = enabled;
  document.getElementById('groupCounts').textContent = `${cloud} / ${nas} / ${usb}`;
}
function editJob(id) {
  const job = jobsCache[id] || {};
  fillForm(id, job);
  window.scrollTo({top: document.body.scrollHeight * 0.25, behavior: 'smooth'});
}
async function deleteJobMeta(id) {
  if (!confirm(`Delete job definition ${id}? This does not delete backup data.`)) return;
  const r = await api('/jobs/' + encodeURIComponent(id), {method:'DELETE'});
  if (r && r.message) alert(r.message);
  await refreshAll();
}
async function refreshStatus() {
  const s = await api('/status');
  document.getElementById('runningValue').textContent = s.running ? (s.paused ? 'Paused' : 'Yes') : 'No';
  document.getElementById('jobValue').textContent = s.job_name || s.job_id || 'None';
  document.getElementById('speedValue').textContent = (s.progress && s.progress.speed) || '-';
  document.getElementById('etaValue').textContent = (s.progress && s.progress.eta) || '-';
  document.getElementById('pctText').textContent = ((s.progress && s.progress.percent) || 0) + '%';
  document.getElementById('xferText').textContent = [(s.progress && s.progress.transferred) || '', (s.progress && s.progress.total) || ''].filter(Boolean).join(' / ') || 'No transfer yet';
  document.getElementById('currentText').textContent = (s.progress && (s.progress.current_file || s.progress.raw)) || 'Idle';
  document.getElementById('lastRunText').textContent = 'Last run: ' + (s.last_run || 'never');
  document.getElementById('errorText').textContent = s.last_error ? ('Error: ' + s.last_error) : '';
  document.getElementById('bar').style.width = (((s.progress && s.progress.percent) || 0)) + '%';
  document.getElementById('queueCount').textContent = (s.queue || []).length;

  const targetJob = s.job_id || document.getElementById('jobSelect').value || Object.keys(jobsCache)[0] || '';
  if (targetJob) {
    const logs = await fetch('/logs?job_id=' + encodeURIComponent(targetJob)).then(r => r.text());
    document.getElementById('logBox').textContent = logs || 'No logs yet';
  }
}
async function refreshAll() { await refreshJobs(); await refreshStatus(); }
async function runSelected() { await runJobId(document.getElementById('jobSelect').value); }
async function runJobId(job_id) {
  const r = await api('/run', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({job_id})});
  if (r && r.message) alert(r.message);
  setTimeout(refreshAll, 700);
}
async function runAllEnabled() {
  const r = await api('/run_all', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({enabled_only:true})});
  if (r && r.message) alert(r.message);
  setTimeout(refreshAll, 700);
}
async function runGroup(group) {
  const r = await api('/run_group', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({group})});
  if (r && r.message) alert(r.message);
  setTimeout(refreshAll, 700);
}
async function saveJob() {
  const body = formData();
  const path = '/jobs' + (body.job_id ? '/' + encodeURIComponent(body.job_id) : '');
  const method = body.job_id ? 'PUT' : 'POST';
  const r = await api(path, {method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  if (r && r.message) alert(r.message);
  await refreshAll();
}
async function pauseJob() { const r = await api('/pause', {method:'POST'}); if (r && r.message) console.log(r.message); setTimeout(refreshAll, 300); }
async function resumeJob() { const r = await api('/resume', {method:'POST'}); if (r && r.message) console.log(r.message); setTimeout(refreshAll, 300); }
async function stopJob() { const r = await api('/stop', {method:'POST'}); if (r && r.message) console.log(r.message); setTimeout(refreshAll, 300); }
function viewLog(job_id) {
  document.getElementById('jobSelect').value = job_id;
  refreshStatus();
  window.scrollTo({top: document.body.scrollHeight, behavior: 'smooth'});
}
function downloadLog() {
  const job_id = document.getElementById('jobSelect').value;
  if (!job_id) return;
  window.open('/logs/download?job_id=' + encodeURIComponent(job_id), '_blank');
}
function downloadLogFor(job_id) {
  window.open('/logs/download?job_id=' + encodeURIComponent(job_id), '_blank');
}
async function deleteRemote() {
  const confirmText = document.getElementById('confirmText').value.trim();
  if (confirmText !== 'DELETE') { alert('Type DELETE first.'); return; }
  const job_id = document.getElementById('dangerJobSelect').value;
  const mode = document.getElementById('deleteMode').value;
  const hard_delete = mode === 'purge';
  if (!confirm(`Really delete destination for ${job_id}?`)) return;
  const r = await api('/danger/delete_destination', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({job_id, confirm_text: confirmText, hard_delete})
  });
  if (r && r.message) alert(r.message);
  setTimeout(refreshAll, 700);
}
onSourcePickerChange(); updateDestinationUI(); updateScheduleField(); clearForm(); setInterval(refreshStatus, 2500); refreshAll();
</script>
</body>
</html>'''


@app.route("/jobs", methods=["GET"])
def jobs():
    all_jobs = load_jobs()
    payload = {jid: job_snapshot(jid, job) for jid, job in all_jobs.items()}
    return jsonify(payload)


@app.route("/jobs", methods=["POST"])
def create_job():
    jobs = load_jobs()
    body = request.get_json(silent=True) or {}
    jid = normalize_job_id(body.get("job_id") or body.get("name") or "")
    if not jid:
        return jsonify({"ok": False, "message": "job_id or name is required"}), 400
    if jid in jobs:
        return jsonify({"ok": False, "message": f"job_id already exists: {jid}"}), 409
    job = {
        "name": body.get("name", jid),
        "src": body.get("src", ""),
        "dest": body.get("dest", ""),
        "mode": body.get("mode", "copy"),
        "enabled": bool(body.get("enabled", True)),
        "schedule": body.get("schedule", ""),
        "source_type": body.get("source_type", ""),
        "dest_type": body.get("dest_type", ""),
        "group": body.get("group", ""),
        "extra_flags": body.get("extra_flags", "--copy-links") or "--copy-links",
        "archive_first": bool(body.get("archive_first", False)),
    }
    job["extra_flags"] = " ".join(apply_default_job_flags(job, shlex.split(str(job.get("extra_flags", "")).strip()) if str(job.get("extra_flags", "")).strip() else [])).strip()
    errors = validate_job(job)
    if errors:
        return jsonify({"ok": False, "message": "; ".join(errors)}), 400
    jobs[jid] = job
    save_jobs(jobs)
    update_job_runtime(jid, state="idle", job_name=job.get("name", jid))
    return jsonify({"ok": True, "message": f"Created job {jid}", "job_id": jid})


@app.route("/jobs/<job_id>", methods=["PUT"])
def update_job(job_id):
    jobs = load_jobs()
    if job_id not in jobs:
        return jsonify({"ok": False, "message": f"Unknown job: {job_id}"}), 404
    body = request.get_json(silent=True) or {}
    job = jobs[job_id]
    for k in ["name", "src", "dest", "mode", "schedule", "source_type", "dest_type", "group", "extra_flags", "archive_first"]:
        if k in body:
            job[k] = body[k]
    if not str(job.get("extra_flags", "")).strip():
        job["extra_flags"] = "--copy-links"
    job["extra_flags"] = " ".join(apply_default_job_flags(job, shlex.split(str(job.get("extra_flags", "")).strip()) if str(job.get("extra_flags", "")).strip() else [])).strip()
    if "enabled" in body:
        job["enabled"] = bool(body["enabled"])
    errors = validate_job(job)
    if errors:
        return jsonify({"ok": False, "message": "; ".join(errors)}), 400
    jobs[job_id] = job
    save_jobs(jobs)
    update_job_runtime(job_id, job_name=job.get("name", job_id))
    return jsonify({"ok": True, "message": f"Updated job {job_id}", "job_id": job_id})


@app.route("/jobs/<job_id>", methods=["DELETE"])
def delete_job_definition(job_id):
    jobs = load_jobs()
    if job_id not in jobs:
        return jsonify({"ok": False, "message": f"Unknown job: {job_id}"}), 404
    if state["running"] and state.get("job_id") == job_id:
        return jsonify({"ok": False, "message": "Cannot delete the currently running job definition."}), 409
    del jobs[job_id]
    save_jobs(jobs)
    with STATUS_LOCK:
        state["job_runtime"].pop(job_id, None)
    return jsonify({"ok": True, "message": f"Deleted job definition {job_id}"})


@app.route("/status", methods=["GET"])
@app.route("/api/status", methods=["GET"])
def status_endpoint():
    ensure_runtime_records()
    with STATUS_LOCK:
        payload = {
            "running": state["running"],
            "paused": state["paused"],
            "job_id": state["job_id"],
            "job_name": state["job_name"],
            "started_at": state["started_at"],
            "completed_at": state["completed_at"],
            "last_run": state["last_run"],
            "last_error": state["last_error"],
            "queue": list(state["queue"]),
            "progress": dict(state["progress"]),
            "job_runtime": dict(state["job_runtime"]),
        }
    return jsonify(payload)


@app.route("/logs", methods=["GET"])
def logs():
    job_id = request.args.get("job_id") or state.get("job_id") or next(iter(load_jobs().keys()), "")
    return "\n".join(read_log_tail(job_id))


@app.route("/logs/download", methods=["GET"])
def logs_download():
    job_id = request.args.get("job_id") or state.get("job_id") or next(iter(load_jobs().keys()), "")
    path = log_path(job_id)
    if not path.exists():
        return Response("No log file yet\n", mimetype="text/plain", headers={"Content-Disposition": f"attachment; filename={job_id}.log"})
    return send_file(path, as_attachment=True, download_name=f"{job_id}.log", mimetype="text/plain")


@app.route("/run", methods=["POST"])
def run():
    body = request.get_json(silent=True) or {}
    job_id = body.get("job_id") or request.args.get("job_id")
    if not job_id:
        return jsonify({"ok": False, "message": "job_id is required"}), 400
    if state["running"]:
        return jsonify({"ok": False, "message": "A backup job is already running."}), 409
    if job_id not in load_jobs():
        return jsonify({"ok": False, "message": f"Unknown job: {job_id}"}), 404
    start_job(job_id)
    return jsonify({"ok": True, "message": f"Started job {job_id}", "job_id": job_id})


@app.route("/run_all", methods=["POST"])
def run_all():
    body = request.get_json(silent=True) or {}
    jobs = load_jobs()
    enabled_only = bool(body.get("enabled_only", True))
    job_ids = [jid for jid, job in jobs.items() if (job.get("enabled", True) or not enabled_only)]
    if not job_ids:
        return jsonify({"ok": False, "message": "No jobs matched."}), 400
    if state["running"]:
        return jsonify({"ok": False, "message": "A backup job is already running."}), 409
    start_queue(job_ids)
    return jsonify({"ok": True, "message": f"Queued {len(job_ids)} job(s).", "job_ids": job_ids})


@app.route("/run_group", methods=["POST"])
def run_group():
    body = request.get_json(silent=True) or {}
    group = str(body.get("group", "")).strip().lower()
    if not group:
        return jsonify({"ok": False, "message": "group is required"}), 400
    jobs = load_jobs()
    job_ids = [jid for jid, job in jobs.items() if str(job.get("group", "")).lower() == group and job.get("enabled", True)]
    if not job_ids:
        return jsonify({"ok": False, "message": f"No enabled jobs found for group {group}."}), 404
    if state["running"]:
        return jsonify({"ok": False, "message": "A backup job is already running."}), 409
    start_queue(job_ids)
    return jsonify({"ok": True, "message": f"Queued {len(job_ids)} job(s) for group {group}.", "job_ids": job_ids})


@app.route("/pause", methods=["POST"])
def pause():
    global current_process
    if not current_process or not state["running"]:
        return jsonify({"ok": False, "message": "No running job."}), 409
    try:
        os.kill(current_process.pid, signal.SIGSTOP)
        set_state(paused=True)
        update_job_runtime(state["job_id"], paused=True, state="paused")
        append_log(state["job_id"], f"{now_str()} Job paused")
        return jsonify({"ok": True, "message": "Paused running job."})
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)}), 500


@app.route("/resume", methods=["POST"])
def resume():
    global current_process
    if not current_process or not state["running"]:
        return jsonify({"ok": False, "message": "No running job."}), 409
    try:
        os.kill(current_process.pid, signal.SIGCONT)
        set_state(paused=False)
        update_job_runtime(state["job_id"], paused=False, state="running")
        append_log(state["job_id"], f"{now_str()} Job resumed")
        return jsonify({"ok": True, "message": "Resumed running job."})
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)}), 500


@app.route("/stop", methods=["POST"])
def stop():
    global current_process
    if not current_process or not state["running"]:
        return jsonify({"ok": False, "message": "No running job."}), 409
    try:
        current_process.terminate()
        append_log(state["job_id"], f"{now_str()} Stop requested")
        return jsonify({"ok": True, "message": "Stop requested."})
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)}), 500


@app.route("/danger/delete_destination", methods=["POST"])
def delete_destination():
    if state["running"]:
        return jsonify({"ok": False, "message": "Cannot delete while a job is running."}), 409
    body = request.get_json(silent=True) or {}
    job_id = body.get("job_id")
    confirm_text = str(body.get("confirm_text", "")).strip()
    hard_delete = bool(body.get("hard_delete", False))
    if confirm_text != "DELETE":
        return jsonify({"ok": False, "message": "Type DELETE exactly to confirm."}), 400
    jobs = load_jobs()
    job = jobs.get(job_id)
    if not job:
        return jsonify({"ok": False, "message": f"Unknown job: {job_id}"}), 404
    cmd = build_delete_cmd(job, hard_delete)
    append_log(job_id, f"{now_str()} DANGER delete requested for destination: {job['dest']}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
        output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
        for line in output.splitlines():
            append_log(job_id, line)
        if proc.returncode == 0:
            msg = f"Deleted destination for {job_id}"
            append_log(job_id, f"{now_str()} {msg}")
            return jsonify({"ok": True, "message": msg})
        return jsonify({"ok": False, "message": f"Delete failed with code {proc.returncode}"}), 500
    except Exception as e:
        append_log(job_id, f"{now_str()} Delete exception: {e}")
        return jsonify({"ok": False, "message": str(e)}), 500


@app.route("/healthz", methods=["GET"])
def health():
    return "ok"


def scheduler_loop():
    while True:
        jobs = load_jobs()
        ensure_runtime_records()
        now_hm = time.strftime("%H:%M")
        today = time.strftime("%Y-%m-%d")
        today_wday = time.strftime("%a")
        for job_id, job in jobs.items():
            if not job.get("enabled", True):
                continue
            sched = str(job.get("schedule", "")).strip()
            if not sched:
                continue
            should_run = False
            if now_hm == sched:
                should_run = True
            else:
                parts = sched.split()
                if len(parts) == 2 and parts[0] in {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}:
                    should_run = (today_wday == parts[0] and now_hm == parts[1])
            hit_key = f"{today}:{job_id}:{sched}"
            if should_run and last_schedule_hits.get(hit_key) is not True:
                if not state["running"]:
                    start_job(job_id)
                last_schedule_hits[hit_key] = True
        if now_hm == "00:05":
            old_keys = [k for k in list(last_schedule_hits.keys()) if not k.startswith(today)]
            for k in old_keys:
                last_schedule_hits.pop(k, None)
        time.sleep(20)


threading.Thread(target=scheduler_loop, daemon=True).start()

if __name__ == "__main__":
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    ensure_jobs_file()
    ensure_runtime_records()
    app.run(host="0.0.0.0", port=PORT)
