# SidscriPi Dashboard — Docker Deployment

## Quick Start

```bash
# 1. Put these files in a folder together:
#    Dockerfile, docker-compose.yml, server.py, version.json

# 2. Build and start
docker compose up -d --build

# 3. Open the dashboard
http://<your-host-ip>:8029
```

---

## File Layout

```
your-folder/
├── docker-compose.yml
├── Dockerfile
├── server.py
└── version.json
```

---

## Why `privileged` + `pid: host`?

The dashboard is a **host monitor** — it needs to:

| Feature | What it needs |
|---|---|
| `systemctl start/stop/restart` | D-Bus socket at `/run/systemd` + `/run/dbus` |
| `journalctl` logs | Host PID namespace (`pid: host`) |
| CPU temp, load, uptime | `/proc` and `/sys` |
| Docker container management | `/var/run/docker.sock` |
| Edit `/etc/fstab`, smb.conf etc. | `/etc` volume mount |
| `*arr` config files | `/opt/appdata` volume mount |

---

## Settings Persistence

Settings are saved to `/opt/pi-dashboard/settings.json` on the **host** via the volume mount:

```yaml
- /opt/pi-dashboard:/opt/pi-dashboard
```

If that directory doesn't exist yet:
```bash
sudo mkdir -p /opt/pi-dashboard
```

---

## Live Code Editing (Optional)

Because `/opt/pi-dashboard` is mounted, you can edit `server.py` on the host and restart the container to pick up changes — no rebuild needed:

```bash
sudo cp server.py /opt/pi-dashboard/server.py
docker compose restart pi-dashboard
```

---

## Sudoers (Not Needed in Docker)

The container runs as root, so the `sudo systemctl` calls in `server.py` work without any sudoers configuration. If you previously had sudoers set up on the bare-metal install, you can leave it — it won't interfere.

---

## Updating

```bash
# Pull new server.py into build context, then:
docker compose up -d --build
```

---

## Logs

```bash
docker compose logs -f pi-dashboard
```

---

## Stop / Remove

```bash
docker compose down          # stop and remove container
docker compose down --rmi local  # also remove the built image
```
