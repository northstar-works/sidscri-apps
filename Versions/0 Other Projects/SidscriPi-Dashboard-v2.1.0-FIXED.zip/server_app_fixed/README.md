# SidscriPi Server Dashboard v2.1.0

A powerful, real-time web dashboard for monitoring and controlling services on your Raspberry Pi (or any Linux server).

![Dashboard Preview](https://via.placeholder.com/800x400?text=SidscriPi+Dashboard)

## Features

### 📊 Real-Time Monitoring
- System stats: hostname, IP, uptime, load, temperature
- Memory, swap, and disk usage with visual progress bars
- Per-service CPU and memory usage
- Auto-refresh every 30 seconds

### 🎛️ Service Control
- **Start/Stop/Restart** any configured service with one click
- Visual status indicators (green=active, red=stopped, amber=unknown)
- Organized by category: Media, Arr Stack, Downloads, TV/DVR, Home, System

### 👁️ Built-in Service Viewer
- Open any service's web UI in an embedded iframe
- "Back to Dashboard" button for easy navigation
- External link to open in new tab

### ✏️ Config File Editor
- Edit service configuration files directly from the dashboard
- Syntax highlighting (monospace font)
- Auto-backup before saving
- Tab support for indentation
- **NEW**: File browser when config path unknown

### 📚 Kiwix Library Management
- One-click refresh of Kiwix ZIM library
- Automatically scans ZIM directory and rebuilds library.xml
- Restarts Kiwix service after refresh

### 📋 Log Viewer
- View journalctl logs for active services
- Last 100 lines, auto-formatted

### ⚙️ Flexible Settings
- Configure ports, web paths, config file locations
- Auto-detect service configurations
- Dashboard-only mappings (doesn't modify services)

## Installation

### Quick Install
```bash
curl -sSL https://raw.githubusercontent.com/yourusername/sidscripi/main/install.sh | sudo bash
```

### Manual Install
```bash
# Create directory
sudo mkdir -p /opt/pi-dashboard

# Copy files
sudo cp server.py /opt/pi-dashboard/
sudo cp pi-dashboard.service /etc/systemd/system/

# Install and start
sudo systemctl daemon-reload
sudo systemctl enable pi-dashboard
sudo systemctl start pi-dashboard

# Optional: Install Kiwix refresh script
sudo cp kiwix-refresh-library.sh /usr/local/bin/
sudo chmod +x /usr/local/bin/kiwix-refresh-library.sh
```

## Access

Open in your browser:
```
http://YOUR-PI-IP:8029
```

## Preconfigured Services

The dashboard comes preconfigured for these services:

| Category | Services |
|----------|----------|
| **Media** | Plex, Navidrome, Kiwix, MPD Local/Stream, ympd |
| **Arr Stack** | Sonarr A/B, Radarr A/B, Lidarr B, Readarr A/B, Readarr Audiobooks A/B, Prowlarr A/B |
| **Downloads** | Deluge (daemon + web), SABnzbd |
| **TV/DVR** | xTeVe A/B |
| **Home** | Home Assistant, Advanced Flashcards |
| **System** | SSH, Samba, xRDP, CUPS, Bluetooth, Pi Dashboard |

## Configuration

### Adding Custom Services

Edit `server.py` and add to the `SERVICES` list:
```python
("My Service", "my-service-unit", 8080, "home", "Description", "/", ["/etc/myservice/config.yml"]),
```

Format: `(display_name, systemd_unit, port, category, description, web_path, [config_files])`

### Settings JSON

Dashboard settings are stored in `/opt/pi-dashboard/settings.json`:
```json
{
  "schema_version": 2,
  "dashboard": {
    "viewer_host": "auto",
    "viewer_scheme": "http"
  },
  "services": {
    "kiwix": {
      "kiwix_zim_dir": "/opt/appdata/kiwix/data/zims",
      "kiwix_library_xml": "/opt/appdata/kiwix/data/library.xml"
    }
  }
}
```

## Troubleshooting

### Dashboard is Empty
1. Check the browser console (F12) for JavaScript errors
2. Ensure the server is running: `sudo systemctl status pi-dashboard`
3. Check server logs: `journalctl -u pi-dashboard -f`

### Buttons Not Working
1. Refresh the page (Ctrl+F5)
2. Check browser console for errors
3. Ensure you're running v2.1.0+ (check CHANGELOG.md)

### Service Control Fails
1. Ensure the dashboard runs as root or has sudo permissions
2. Check that the service unit name matches systemd

### Config Editor Permission Denied
1. The dashboard needs read/write access to config files
2. Add paths to `ALLOWED_EDIT_PATHS` in server.py if needed

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/status` | GET | System and service status |
| `/api/control` | POST | Control service (start/stop/restart) |
| `/api/config` | GET/POST | Read/write config files |
| `/api/logs` | GET | Fetch service logs |
| `/api/settings` | GET/POST | Dashboard settings |
| `/api/settings/autodetect` | POST | Auto-detect service paths |
| `/api/kiwix/refresh` | POST | Refresh Kiwix library |
| `/api/browse` | GET | Browse directory contents |

## Requirements

- Python 3.7+
- systemd
- sudo access for service control

## License

MIT License - Feel free to modify and distribute.

## Version History

- **v2.1.0** - Major bug fixes, file browser, back-to-dashboard button
- **v2.0.0** - Initial v2 release with new UI
